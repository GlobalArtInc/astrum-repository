import React from 'react';
import './Close.scss';
declare const Close: () => React.JSX.Element;
export default Close;
//# sourceMappingURL=Close.d.ts.map