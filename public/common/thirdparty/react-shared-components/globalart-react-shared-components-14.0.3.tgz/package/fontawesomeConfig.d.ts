export {};
//# sourceMappingURL=fontawesomeConfig.d.ts.map