var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import Fuse from 'fuse.js';
import { map, prop } from 'ramda';
export default function fuzzyFilter(input, term, options) {
    // fuse.js defaults "shouldSort" option to true, which is counter intuitive and contradicts their usage example
    // fix it by setting shouldSort to false by default
    // fuse.js is biased to matching terms at the beggining of the string and will sometimes not match terms
    // at the tail unless `ignoreLocation` is set to true.
    var normalizedOptions = __assign({ shouldSort: false, ignoreLocation: true }, options);
    term = term.trim();
    if (!term) {
        return input;
    }
    return map(prop('item'), new Fuse(input, normalizedOptions).search(term));
}
//# sourceMappingURL=fuzzyFilter.js.map