import './selectableColors.scss';
export declare const selectableColors: readonly ["purple", "pink", "blue", "red", "turquoise", "orange", "yellow", "kiwi", "sky", "indigo"];
export declare const selectableColorClasses: readonly string[];
type DeprecatedSelectableColor = 'light-blue' | 'green' | 'lime';
export type SelectableColor = (typeof selectableColors)[number] | DeprecatedSelectableColor;
export {};
//# sourceMappingURL=selectableColors.d.ts.map