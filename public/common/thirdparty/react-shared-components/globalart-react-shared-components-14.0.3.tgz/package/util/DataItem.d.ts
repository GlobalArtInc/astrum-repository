import RequiredReactNode from './RequiredReactNode';
export default interface DataItem<I extends string | number = string, D extends RequiredReactNode = RequiredReactNode> {
    id: I;
    displayName: D;
}
//# sourceMappingURL=DataItem.d.ts.map