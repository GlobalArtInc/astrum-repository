/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import { map } from 'ramda';
import './selectableColors.scss';
export var selectableColors = ['purple', 'pink', 'blue', 'red', 'turquoise', 'orange', 'yellow', 'kiwi', 'sky', 'indigo'];
export var selectableColorClasses = map(function (color) { return "as-selectable-color--".concat(color); }, selectableColors);
//# sourceMappingURL=selectableColors.js.map