var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
import { ResizeObserver as polyfill } from '@juggle/resize-observer';
import _useResizeObserver from '@react-hook/resize-observer';
/**
 * Wrapper around @react-hook/resize-observer that uses the juggle/resize-observer polyfill if the real implementation
 * is not available. This is necessary for next.js support, where server-side rendering attempts to use
 * `window.ResizeObserver` (and fails) when there is no polyfill specified.
 */
export default function useResizeObserver(target, callback, options) {
    var win = typeof window !== 'undefined' ? window : undefined, optionsWithPolyfill = __assign({}, options);
    // if the polyfill is not specified and the real implementation is not available, use the juggle polyfill
    if (!(options === null || options === void 0 ? void 0 : options.polyfill) && !(win === null || win === void 0 ? void 0 : win.ResizeObserver)) {
        optionsWithPolyfill.polyfill = polyfill;
    }
    return _useResizeObserver(target, callback, optionsWithPolyfill);
}
//# sourceMappingURL=useResizeObserver.js.map