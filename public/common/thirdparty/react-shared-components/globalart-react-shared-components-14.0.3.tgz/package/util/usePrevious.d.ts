export default function usePrevious<T>(currentValue: T): T | undefined;
//# sourceMappingURL=usePrevious.d.ts.map