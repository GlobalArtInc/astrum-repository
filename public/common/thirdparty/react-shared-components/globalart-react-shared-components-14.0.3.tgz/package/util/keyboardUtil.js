export var MODIFIER_KEYS = ['Alt', 'AltGraph', 'Control', 'Meta', 'Shift'];
export function modifierKeyIsPressed(event) {
    return MODIFIER_KEYS.some(function (key) { return event.getModifierState(key); });
}
//# sourceMappingURL=keyboardUtil.js.map