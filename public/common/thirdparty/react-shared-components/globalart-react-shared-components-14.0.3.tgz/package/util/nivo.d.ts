export declare const NIVO_COLORS: string[];
export declare const NIVO_THEME: {
    background: string;
    textColor: string;
    axis: {
        domain: {
            line: {
                stroke: string;
            };
        };
        ticks: {
            line: {
                stroke: string;
            };
        };
    };
    grid: {
        line: {
            stroke: string;
        };
    };
    tooltip: {
        container: {
            background: string;
            color: string;
        };
    };
};
//# sourceMappingURL=nivo.d.ts.map