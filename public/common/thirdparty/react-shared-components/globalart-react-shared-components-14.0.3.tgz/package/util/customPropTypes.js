/* eslint-enable @typescript-eslint/no-explicit-any */
export var requiredNullableString = function requiredNullableStringValidator(props, propName, componentName) {
    if (props[propName] === null || typeof props[propName] === 'string') {
        return null;
    }
    var err = "".concat(componentName, ": prop \"").concat(propName, "\" must be null or string; received ").concat(typeof props[propName]);
    return new TypeError(err);
};
function requiredPercentNumberValidator(props, propName, componentName) {
    var value = props[propName];
    if (typeof value === 'number' && value >= 0 && value <= 100) {
        return null;
    }
    var err = "".concat(componentName, ": prop \"").concat(propName, "\" must be a number between 0 and 100 inclusive; received ").concat(value);
    return new TypeError(err);
}
export var requiredPercentNumber = requiredPercentNumberValidator;
export var optionalPercentNumber = function optionalPercentNumberValidator(props, propName, componentName) {
    var value = props[propName];
    if (value === undefined || value === null) {
        return null;
    }
    return requiredPercentNumberValidator(props, propName, componentName);
};
//# sourceMappingURL=customPropTypes.js.map