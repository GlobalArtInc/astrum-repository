import * as PropTypes from 'prop-types';
import { Props as TooltipProps } from '../components/NxTooltip/types';
export type TooltipConfigProps = Omit<TooltipProps, 'children'>;
export declare const tooltipPropTypesShape: PropTypes.Requireable<TooltipProps>;
export declare function wrapTooltipProps(tooltipProp: string | TooltipConfigProps): TooltipConfigProps;
//# sourceMappingURL=tooltipUtils.d.ts.map