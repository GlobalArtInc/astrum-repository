/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import { findIndex, findLastIndex, includes } from 'ramda';
function isReactText(content) {
    return typeof content === 'string' || typeof content === 'number';
}
var isPrintable = function (node) { return !includes(node, [true, false, null, undefined]); };
var getFirstPrintableIndex = findIndex(isPrintable);
var getLastPrintableIndex = findLastIndex(isPrintable);
/**
 * Ensure that if this ReactNode is something renderable, that it renders as an element, by wrapping in a <span> if
 * necessary. If `content` is already an element, or is something that doesn't render, like null or undefined, then
 * it is passed through.
 *
 * WARNING: this function does not dive into fragments, it assumes they will ultimately render an element
 */
export function ensureElement(content) {
    if (content == null) {
        return content;
    }
    else if (Array.isArray(content) && content.length) {
        return React.createElement("span", null, content);
    }
    else if (isReactText(content)) {
        return React.createElement("span", null, content);
    }
    else {
        return content;
    }
}
/**
 * Ensure that if this ReactNode is something renderable, that the first and last things that it renders are elements.
 * by wrapping the whole thing in a <span> if necessary. If `content` is already an element, or is something that
 * doesn't render, like null or undefined, then it is passed through.
 *
 * WARNING: this function does not dive into fragments, it assumes they will ultimately render an element
 */
export function ensureStartEndElements(content) {
    if (Array.isArray(content)) {
        var firstPrintableIndex = getFirstPrintableIndex(content), lastPrintableIndex = getLastPrintableIndex(content);
        if (isReactText(content[firstPrintableIndex]) || isReactText(content[lastPrintableIndex])) {
            return ensureElement(content);
        }
        else {
            return content;
        }
    }
    else {
        return ensureElement(content);
    }
}
/**
 * Takes an optional `ref` and returns a definite `ref` that will not be `undefined`. Helps with type sginature
 * compatibility with useMergedRef.
 */
export function ensureRef(ref) {
    return ref !== null && ref !== void 0 ? ref : (function () { });
}
//# sourceMappingURL=reactUtil.js.map