import React, { ModifierKey } from 'react';
export declare const MODIFIER_KEYS: ModifierKey[];
export declare function modifierKeyIsPressed(event: React.KeyboardEvent | KeyboardEvent): boolean;
//# sourceMappingURL=keyboardUtil.d.ts.map