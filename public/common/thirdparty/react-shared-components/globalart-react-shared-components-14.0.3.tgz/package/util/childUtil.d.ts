import { ComponentType, ReactElement, ReactNode } from 'react';
/**
 * Splits out the first child that matches the type from the rest of the children.
 * @param type the component type to find
 * @param children the children to search
 * @returns A pair containing the first matching child (or null if there are none), followed by the list
 * of remaining children in the same order they were originally.
 */
export declare function splitOutFirst(type: ComponentType, children: ReactNode): [ReactElement | null, ReactNode];
/**
 * @param children to search
 * @param type the component type to find
 * @returns the first child that matches the type (or null if none are found).
 */
export declare function only(children: ReactNode, type: ComponentType): ReactElement | null;
/**
 * @param children to search
 * @returns the concatenated string contents of thie children
 */
export declare function textContent(children: ReactNode): string;
//# sourceMappingURL=childUtil.d.ts.map