import { HTMLAttributes, ReactElement, ReactNode, Ref, RefAttributes } from 'react';
type ReactText = string | number;
export type OptionalReactElement<T = HTMLAttributes<HTMLElement> & RefAttributes<HTMLElement>> = ReactElement<T> | null | undefined | boolean;
/**
 * Ensure that if this ReactNode is something renderable, that it renders as an element, by wrapping in a <span> if
 * necessary. If `content` is already an element, or is something that doesn't render, like null or undefined, then
 * it is passed through.
 *
 * WARNING: this function does not dive into fragments, it assumes they will ultimately render an element
 */
export declare function ensureElement(content: ReactNode): Exclude<ReactNode, ReactText>;
/**
 * Ensure that if this ReactNode is something renderable, that the first and last things that it renders are elements.
 * by wrapping the whole thing in a <span> if necessary. If `content` is already an element, or is something that
 * doesn't render, like null or undefined, then it is passed through.
 *
 * WARNING: this function does not dive into fragments, it assumes they will ultimately render an element
 */
export declare function ensureStartEndElements(content: ReactNode): Exclude<ReactNode, ReactText>;
/**
 * Takes an optional `ref` and returns a definite `ref` that will not be `undefined`. Helps with type sginature
 * compatibility with useMergedRef.
 */
export declare function ensureRef<T>(ref: Ref<T> | undefined): Ref<T>;
export {};
//# sourceMappingURL=reactUtil.d.ts.map