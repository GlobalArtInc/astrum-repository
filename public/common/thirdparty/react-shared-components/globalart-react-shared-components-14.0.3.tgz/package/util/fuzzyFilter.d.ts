import { IFuseOptions } from 'fuse.js';
export default function fuzzyFilter<T>(input: T[], term: string, options: IFuseOptions<T>): T[];
//# sourceMappingURL=fuzzyFilter.d.ts.map