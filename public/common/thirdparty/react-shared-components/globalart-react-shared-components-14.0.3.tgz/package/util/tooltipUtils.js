/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import * as PropTypes from 'prop-types';
import { propTypes as tooltipPropTypes } from '../components/AsTooltip/types';
// PropType's typescript magic that infers the Props types from the ValidationMap doesn't seem to work right,
// which is why this cast is here
export var tooltipPropTypesShape = PropTypes.shape(tooltipPropTypes);
export function wrapTooltipProps(tooltipProp) {
    return typeof tooltipProp === 'string' ? { title: tooltipProp } : tooltipProp;
}
//# sourceMappingURL=tooltipUtils.js.map