import { IFuseOptions } from 'fuse.js';
declare function useFuzzyFilter<T>(input: T[], options: IFuseOptions<T>): [T[], string, ((s: string) => void)];
export default useFuzzyFilter;
//# sourceMappingURL=useFuzzyFilter.d.ts.map