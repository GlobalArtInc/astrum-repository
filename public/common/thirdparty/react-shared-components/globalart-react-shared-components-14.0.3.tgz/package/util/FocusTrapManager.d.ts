import { RefObject } from 'react';
/**
 * A React hook that sets up a focus trap on the element found within ref. At any given time, only the most-recently
 * created still-existing focus trap is active
 */
export declare function useFocusTrap<T extends HTMLElement>(ref: RefObject<T | null>): void;
/**
 * Register an element as a focus trap, ensuring that other elements on the page (aside from the <body>) are
 * never the active element. At any given time, only the most-recently registered, not-yet-unregistered focus trap
 * is active
 */
export declare function register(el: HTMLElement): void;
/**
 * Unregister an element as a focus trap. Focus will no longer be trapped within this element and if there are any
 * other registered focus traps focus will be moved to the most recently added one
 */
export declare function unregister(el: HTMLElement): void;
//# sourceMappingURL=FocusTrapManager.d.ts.map