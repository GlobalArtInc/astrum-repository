export declare const isProduction: boolean;
//# sourceMappingURL=envUtil.d.ts.map