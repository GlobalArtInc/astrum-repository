/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
export var NIVO_COLORS = [
    'var(--as-color-chart-data-1)',
    'var(--as-color-chart-data-2)',
    'var(--as-color-chart-data-3)',
    'var(--as-color-chart-data-4)',
    'var(--as-color-chart-data-5)',
    'var(--as-color-chart-data-6)',
    'var(--as-color-chart-data-7)',
    'var(--as-color-chart-data-8)'
];
export var NIVO_THEME = {
    background: 'var(--as-color-component-background)',
    textColor: 'var(--as-color-chart-text)',
    axis: {
        domain: {
            line: { stroke: 'var(--as-color-chart-line)' }
        },
        ticks: {
            line: { stroke: 'var(--as-color-chart-line)' }
        }
    },
    grid: {
        line: { stroke: 'var(--as-color-chart-line)' }
    },
    tooltip: {
        container: {
            background: 'var(--as-color-tooltip-background)',
            color: 'var(--as-color-tooltip-text)'
        }
    }
};
//# sourceMappingURL=nivo.js.map