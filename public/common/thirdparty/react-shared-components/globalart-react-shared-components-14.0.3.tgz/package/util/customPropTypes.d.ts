import * as PropTypes from 'prop-types';
export declare const requiredNullableString: PropTypes.Validator<string>;
export declare const requiredPercentNumber: PropTypes.Validator<number>;
export declare const optionalPercentNumber: PropTypes.Validator<number>;
//# sourceMappingURL=customPropTypes.d.ts.map