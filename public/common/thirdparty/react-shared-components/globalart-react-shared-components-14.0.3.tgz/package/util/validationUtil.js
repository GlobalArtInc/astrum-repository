import { reject, isNil, flatten, map, applyTo } from 'ramda';
/**
 * @return whether this ValidationErrors object contains an error
 */
export var hasValidationErrors = function () {
    var validationErrors = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        validationErrors[_i] = arguments[_i];
    }
    var combinedValidation = combineValidationErrors.apply(void 0, validationErrors);
    if (combinedValidation == null) {
        return false;
    }
    else if (Array.isArray(combinedValidation)) {
        return combinedValidation.length !== 0;
    }
    else {
        return true;
    }
};
/**
 * @return The first error string contained within this ValidationErrors object, or null if there isn't one
 */
export function getFirstValidationError(validationErrors) {
    if (validationErrors == null) {
        return null;
    }
    else if (Array.isArray(validationErrors)) {
        if (validationErrors.length) {
            return validationErrors[0];
        }
        else {
            return null;
        }
    }
    else {
        return validationErrors;
    }
}
export function combineValidationErrors() {
    var validationErrors = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        validationErrors[_i] = arguments[_i];
    }
    return reject(isNil, flatten(validationErrors));
}
export function combineValidators() {
    var validators = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        validators[_i] = arguments[_i];
    }
    var definedValidators = reject(isNil, validators);
    return function (val) { return combineValidationErrors.apply(void 0, map(applyTo(val), definedValidators)); };
}
//# sourceMappingURL=validationUtil.js.map