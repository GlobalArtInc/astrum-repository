/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import { useMemo, useState } from 'react';
import fuzzyFilter from './fuzzyFilter';
function useFuzzyFilter(input, options) {
    var _a = useState(''), filterTerm = _a[0], setFilterTerm = _a[1];
    var output = useMemo(function () { return filterTerm ? fuzzyFilter(input, filterTerm, options) : input; }, [filterTerm, input, options]);
    return [output, filterTerm, setFilterTerm];
}
export default useFuzzyFilter;
//# sourceMappingURL=useFuzzyFilter.js.map