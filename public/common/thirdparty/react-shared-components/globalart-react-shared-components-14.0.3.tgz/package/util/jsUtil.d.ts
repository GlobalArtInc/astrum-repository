/**
 * [String] -> a -> b -> b
 * Set nested property using path
 */
export declare const pathSet: import("ts-toolbelt/out/Function/Curry").Curry<(path: any, value: any, target: any) => any>;
//# sourceMappingURL=jsUtil.d.ts.map