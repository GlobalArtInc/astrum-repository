/**
 * All Possible Policy Threat Level Categories
 */
export declare const allThreatLevelCategories: readonly ["unspecified", "none", "low", "moderate", "severe", "critical"];
/**
 * All Possible Policy Threat Levels
 */
export declare const allThreatLevelNumbers: readonly [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
/**
 * The type containing only the possible ThreatLevelCategory values
 */
export type ThreatLevelCategory = (typeof allThreatLevelCategories)[number];
/**
 * The type containing only the possible ThreatLevelNumber values
 */
export type ThreatLevelNumber = (typeof allThreatLevelNumbers)[number];
type ThreatLevelCategoryLookup = {
    readonly [idx in ThreatLevelNumber]: ThreatLevelCategory;
};
/**
 * A lookup array used for mapping ThreatLevelNumbers to ThreatLevelCategories. Indexing into this array using a
 * given ThreatLevelNumber will result in the ThreatLevelCategory to which that number belongs.
 */
export declare const categoryByPolicyThreatLevel: ThreatLevelCategoryLookup;
export {};
//# sourceMappingURL=threatLevels.d.ts.map