/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import { curry, lensPath, set } from 'ramda';
/**
 * [String] -> a -> b -> b
 * Set nested property using path
 */
export var pathSet = curry(function (path, value, target) { return set(lensPath(path), value, target); });
//# sourceMappingURL=jsUtil.js.map