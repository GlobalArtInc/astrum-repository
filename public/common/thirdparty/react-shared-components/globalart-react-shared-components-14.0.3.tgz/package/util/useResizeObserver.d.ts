import { RefObject, ForwardedRef } from 'react';
import { UseResizeObserverCallback, UseResizeObserverOptions } from '@react-hook/resize-observer';
/**
 * Wrapper around @react-hook/resize-observer that uses the juggle/resize-observer polyfill if the real implementation
 * is not available. This is necessary for next.js support, where server-side rendering attempts to use
 * `window.ResizeObserver` (and fails) when there is no polyfill specified.
 */
export default function useResizeObserver<T extends Element>(target: RefObject<T> | ForwardedRef<T> | T | null, callback: UseResizeObserverCallback, options?: UseResizeObserverOptions): ResizeObserver;
//# sourceMappingURL=useResizeObserver.d.ts.map