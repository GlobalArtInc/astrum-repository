import { ValidationErrors, Validator } from '../components/NxTextInput/types';
export { ValidationErrors };
/**
 * @return whether this ValidationErrors object contains an error
 */
export declare const hasValidationErrors: (...validationErrors: (ValidationErrors | undefined)[]) => boolean;
/**
 * @return The first error string contained within this ValidationErrors object, or null if there isn't one
 */
export declare function getFirstValidationError(validationErrors: ValidationErrors | undefined): string | null;
export declare function combineValidationErrors(...validationErrors: (ValidationErrors | undefined)[]): ValidationErrors;
export declare function combineValidators(...validators: Validator[]): Exclude<Validator, null>;
//# sourceMappingURL=validationUtil.d.ts.map