/**
 * @return whether the space-separated className string (fullClassName) includes the specified class
 */
export declare const includesClass: ((cls: string) => (className?: string) => boolean) & ((cls: string, className?: string) => boolean);
export declare const includesDisabledClass: (className?: string) => boolean;
//# sourceMappingURL=classUtil.d.ts.map