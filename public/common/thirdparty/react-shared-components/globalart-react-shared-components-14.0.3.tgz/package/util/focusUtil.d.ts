/**
 * A CSS selector which matches all focusable elements
 */
export declare const FOCUSABLE_ELEMENTS_SELECTOR: string;
export declare const isVisible: (element: HTMLElement | null) => boolean;
/**
 * @return the first (in DOM order) child of element that is both visible and focusable
 */
export declare const getFirstVisibleFocusableElement: (element: HTMLElement) => HTMLElement;
/**
 * @return the last (in DOM order) child of element that is both visible and focusable
 */
export declare const getLastVisibleFocusableElement: (element: HTMLElement) => HTMLElement;
//# sourceMappingURL=focusUtil.d.ts.map