import { ReactNode } from 'react';
type RequiredReactNode = Exclude<ReactNode, null | undefined | false>;
export default RequiredReactNode;
//# sourceMappingURL=RequiredReactNode.d.ts.map