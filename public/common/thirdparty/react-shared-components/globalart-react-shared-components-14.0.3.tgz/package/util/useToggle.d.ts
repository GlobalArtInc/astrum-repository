type ReturnType = [boolean, () => boolean, (b: boolean) => void];
/**
 * Convenience hook for boolean pieces of react state that are primarily interacted with via
 * "toggling". Using this hook in place of `useState` directly saves the caller from having to
 * implement toggleState themselves.
 * @return an array containing the following:
 * 0: the current boolean state value
 * 1: a parameterless function that toggles the value of the state boolean
 * 2: a function which sets the value of the state boolean based on its value
 */
export default function useToggle(initialValue: boolean): ReturnType;
export {};
//# sourceMappingURL=useToggle.d.ts.map