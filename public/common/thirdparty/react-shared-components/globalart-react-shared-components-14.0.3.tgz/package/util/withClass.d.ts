import React, { JSX } from 'react';
export default function withClass<E extends keyof JSX.IntrinsicElements>(El: E, withClassName: string, withRole?: string): (props: JSX.IntrinsicElements[E]) => React.ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<JSX.IntrinsicElements[E], "className">, string | React.JSXElementConstructor<any>>;
//# sourceMappingURL=withClass.d.ts.map