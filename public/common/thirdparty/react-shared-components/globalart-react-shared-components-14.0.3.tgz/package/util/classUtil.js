var __makeTemplateObject = (this && this.__makeTemplateObject) || function (cooked, raw) {
    if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
    return cooked;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import { curryN } from 'ramda';
// given a class name, create a regex that will match HTML class attrs that have that class name
var classMatchRegex = function (cls) { return new RegExp(String.raw(templateObject_1 || (templateObject_1 = __makeTemplateObject(["(s|^)", "(s|$)"], ["(\\s|^)", "(\\s|$)"])), cls)); };
/**
 * @return whether the space-separated className string (fullClassName) includes the specified class
 */
export var includesClass = curryN(2, function (cls, fullClassName) { return !!(fullClassName && fullClassName.match(classMatchRegex(cls))); });
export var includesDisabledClass = includesClass('disabled');
var templateObject_1;
//# sourceMappingURL=classUtil.js.map