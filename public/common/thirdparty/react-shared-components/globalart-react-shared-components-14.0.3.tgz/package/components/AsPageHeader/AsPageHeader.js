var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import AbstractAsPageHeader from '../AbstractAsPageHeader/AbstractAsPageHeader';
import { propTypes } from './types';
import importImage from '../../util/importImage';
var defaultLogoImg = importImage('logo-with-hexagon.png'), defaultDarkLogoImg = importImage('logo-with-hexagon-dark-mode.png'), defaultLogoProps = {
    path: defaultLogoImg,
    darkModePath: defaultDarkLogoImg,
    alt: 'Astrum'
};
function HeaderProductInfo(_a) {
    var name = _a.name, version = _a.version;
    return (React.createElement(React.Fragment, null,
        React.createElement("div", { role: "presentation", className: "as-product__divider" }, "|"),
        React.createElement("div", { className: "as-product__name" }, name),
        version && React.createElement("div", { className: "as-product__version" },
            "Version: ",
            version)));
}
function LogoImg(_a) {
    var path = _a.path, alt = _a.alt, darkModePath = _a.darkModePath;
    return (React.createElement(React.Fragment, null,
        React.createElement("img", { src: path, className: "as-product__logo-image as-product__logo-image--light", alt: alt }),
        React.createElement("img", { src: darkModePath !== null && darkModePath !== void 0 ? darkModePath : defaultLogoProps.darkModePath, className: "as-product__logo-image as-product__logo-image--dark", alt: alt })));
}
export default function AsPageHeader(_a) {
    var logo = _a.logo, productInfo = _a.productInfo, otherProps = __rest(_a, ["logo", "productInfo"]);
    var logoEl = React.createElement(LogoImg, __assign({}, logo !== null && logo !== void 0 ? logo : defaultLogoProps)), productInfoContent = productInfo ? React.createElement(HeaderProductInfo, __assign({}, productInfo)) : null;
    return React.createElement(AbstractAsPageHeader, __assign({}, otherProps, { productInfoContent: productInfoContent, logo: logoEl }));
}
AsPageHeader.propTypes = propTypes;
//# sourceMappingURL=AsPageHeader.js.map