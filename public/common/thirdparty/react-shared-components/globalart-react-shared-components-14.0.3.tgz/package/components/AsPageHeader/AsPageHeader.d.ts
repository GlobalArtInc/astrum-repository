import React from 'react';
import { Props } from './types';
export { Props };
declare function AsPageHeader({ logo, productInfo, ...otherProps }: Props): React.JSX.Element;
declare namespace AsPageHeader {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default AsPageHeader;
//# sourceMappingURL=AsPageHeader.d.ts.map