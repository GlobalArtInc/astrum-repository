import * as PropTypes from 'prop-types';
import { Props as AbstractAsPageHeaderProps } from '../AbstractAsPageHeader/types';
export interface ProductInfo {
    name: string;
    version?: string | null;
}
export interface LogoProps {
    path: string;
    alt: string;
    darkModePath?: string | null;
}
export interface Props extends Omit<AbstractAsPageHeaderProps, 'logo' | 'productInfoContent'> {
    productInfo?: ProductInfo | null;
    logo?: LogoProps | null;
}
export declare const propTypes: PropTypes.ValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map