import { MouseEvent, ComponentPropsWithRef } from 'react';
import * as PropTypes from 'prop-types';
export interface Props extends ComponentPropsWithRef<'div'> {
    isFirstPage?: boolean | null;
    isLastPage?: boolean | null;
    onPrevPageSelect: ((evt: MouseEvent) => void);
    onNextPageSelect: ((evt: MouseEvent) => void);
}
export declare const propTypes: PropTypes.ValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map