import React from 'react';
import { Props, propTypes } from './types';
export { Props, propTypes };
declare function NxIndeterminatePagination(props: Props): React.JSX.Element;
declare namespace NxIndeterminatePagination {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default NxIndeterminatePagination;
//# sourceMappingURL=NxIndeterminatePagination.d.ts.map