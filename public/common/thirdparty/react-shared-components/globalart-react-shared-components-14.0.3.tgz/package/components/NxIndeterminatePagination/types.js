import * as PropTypes from 'prop-types';
export var propTypes = {
    isFirstPage: PropTypes.bool,
    isLastPage: PropTypes.bool,
    onPrevPageSelect: PropTypes.func.isRequired,
    onNextPageSelect: PropTypes.func.isRequired
};
//# sourceMappingURL=types.js.map