import * as PropTypes from 'prop-types';
import { omit } from 'ramda';
var tooltipPlacements = [
    'top', 'bottom',
    'left', 'right',
    'top-middle', 'bottom-middle',
    'top-end', 'bottom-end'
];
export var propTypes = {
    className: PropTypes.string,
    onOpen: PropTypes.func,
    onClose: PropTypes.func,
    open: PropTypes.bool,
    isName: PropTypes.bool,
    placement: PropTypes.oneOf(tooltipPlacements),
    title: PropTypes.node
};
export var overflowTooltipPropTypes = omit(['open'], propTypes);
//# sourceMappingURL=types.js.map