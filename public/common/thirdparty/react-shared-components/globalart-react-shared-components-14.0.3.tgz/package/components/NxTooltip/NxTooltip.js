var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { createContext, useContext, useEffect, useRef, useState } from 'react';
import classnames from 'classnames';
import Tooltip from '@mui/material/Tooltip';
import { DialogContext } from '../AbstractDialog/AbstractDialog';
import { propTypes } from './types';
export { propTypes } from './types';
import './NxToolTip.scss';
import batch from './updateBatcher';
function convertPlacement(placement) {
    switch (placement) {
        case 'top':
        case null:
        case undefined:
            return 'top-start';
        case 'bottom':
            return 'bottom-start';
        case 'top-middle':
            return 'top';
        case 'bottom-middle':
            return 'bottom';
        default:
            return placement;
    }
}
// thanks to PropTypes, we have to accept null in addition to undefined for all optional properties. MUI doesn't
// seem to follow that convention, so this function converts all null-valued props to undefined-valued props
function fixOptional(props) {
    return __assign(__assign({}, props), { className: props.className || undefined, onOpen: props.onOpen || undefined, onClose: props.onClose || undefined, open: props.open === null ? undefined : props.open, placement: convertPlacement(props.placement) });
}
/*
 * This context tells components whether they are already wrapped within an NxTooltip, which can prevent them
 * from rendering an NxTooltip themselves. This is particularly important for components such as NxButton that
 * conditionally render a tooltip depending on whether they have received a `title` prop. If the NxButton is wrapped
 * in an NxTooltip, it gets a title passed to it but only when the actual tooltip is not displayed. If NxButton
 * needs to know whether to render its own tooltip internally based on the title prop, that can get screwed up.
 */
export var TooltipContext = createContext(false);
var NxTooltip = function NxTooltip(_a) {
    var className = _a.className, title = _a.title, isName = _a.isName, otherProps = __rest(_a, ["className", "title", "isName"]);
    var _b = useState(false), initialized = _b[0], setInitialized = _b[1], tooltipClassName = classnames('nx-tooltip', className), parentModalContextValue = useContext(DialogContext), isUnmounted = useRef(false);
    useEffect(function () {
        batch(function () {
            if (!isUnmounted.current) {
                setInitialized(true);
            }
        });
        return function () { isUnmounted.current = true; };
    }, []);
    return (React.createElement(TooltipContext.Provider, { value: true },
        React.createElement(Tooltip, __assign({}, fixOptional(otherProps), { title: initialized && title || '', classes: { tooltip: tooltipClassName }, describeChild: !isName, PopperProps: { container: parentModalContextValue === null || parentModalContextValue === void 0 ? void 0 : parentModalContextValue.dialog } }))));
};
NxTooltip.propTypes = propTypes;
export default NxTooltip;
//# sourceMappingURL=NxTooltip.js.map