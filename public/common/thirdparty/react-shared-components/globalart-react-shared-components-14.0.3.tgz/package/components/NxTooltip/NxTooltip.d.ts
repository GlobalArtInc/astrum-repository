import React, { FunctionComponent } from 'react';
import { Props } from './types';
export { Props, propTypes, TooltipPlacement } from './types';
import './NxToolTip.scss';
export declare const TooltipContext: React.Context<boolean>;
declare const NxTooltip: FunctionComponent<Props>;
export default NxTooltip;
//# sourceMappingURL=NxTooltip.d.ts.map