import { ReactElement, ReactNode, RefAttributes } from 'react';
import * as PropTypes from 'prop-types';
declare const tooltipPlacements: readonly ["top", "bottom", "left", "right", "top-middle", "bottom-middle", "top-end", "bottom-end"];
export type TooltipPlacement = (typeof tooltipPlacements)[number];
export interface Props<C extends HTMLElement = HTMLElement> {
    className?: string | null;
    onOpen?: (() => void) | null;
    onClose?: (() => void) | null;
    open?: boolean | null;
    placement?: TooltipPlacement | null;
    isName?: boolean | null;
    title?: ReactNode;
    children: ReactElement<RefAttributes<C>>;
}
export type OverflowTooltipProps<C extends HTMLElement = HTMLElement> = Omit<Props<C>, 'open'>;
export declare const propTypes: PropTypes.ValidationMap<Props>;
export declare const overflowTooltipPropTypes: Omit<PropTypes.ValidationMap<Props<HTMLElement>>, "open">;
export {};
//# sourceMappingURL=types.d.ts.map