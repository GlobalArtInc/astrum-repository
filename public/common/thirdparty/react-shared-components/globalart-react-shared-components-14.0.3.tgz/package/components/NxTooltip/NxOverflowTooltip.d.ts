import React from 'react';
import { OverflowTooltipProps } from './types';
export { OverflowTooltipProps };
declare function NxOverflowTooltip<C extends HTMLElement = HTMLElement>(props: OverflowTooltipProps<C>): React.JSX.Element;
declare namespace NxOverflowTooltip {
    var propTypes: Omit<import("prop-types").ValidationMap<import("./types").Props<HTMLElement>>, "open">;
}
export default NxOverflowTooltip;
//# sourceMappingURL=NxOverflowTooltip.d.ts.map