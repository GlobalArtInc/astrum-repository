import React from 'react';
import { Props } from '../AsIconDropdown/AsIconDropdown';
export { Props };
import './AsNavigationDropdown.scss';
declare function AsNavigationDropdown({ className, ...otherProps }: Props): React.JSX.Element;
declare namespace AsNavigationDropdown {
    var propTypes: import("prop-types").WeakValidationMap<Props>;
    var MenuHeader: (props: React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement>) => React.ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement>, "className">, string | React.JSXElementConstructor<any>>;
}
export default AsNavigationDropdown;
//# sourceMappingURL=AsNavigationDropdown.d.ts.map