import React from 'react';
import { Props } from './types';
export { Props };
declare function AsStatefulNavigationDropdown(props: Props): React.JSX.Element;
declare namespace AsStatefulNavigationDropdown {
    var propTypes: Omit<import("prop-types").WeakValidationMap<import("../AsNavigationDropdown").Props>, "isOpen" | "onToggleCollapse">;
}
export default AsStatefulNavigationDropdown;
//# sourceMappingURL=AsStatefulNavigationDropdown.d.ts.map