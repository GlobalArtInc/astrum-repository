import { ComponentPropsWithRef } from 'react';
import { IconDefinition } from '@fortawesome/free-solid-svg-icons';
import * as PropTypes from 'prop-types';
export interface Props extends ComponentPropsWithRef<'div'> {
    onClose?: (() => void) | null;
}
export declare const propTypes: PropTypes.ValidationMap<Props>;
export type AsAlertProps = Props & {
    icon: IconDefinition;
    iconLabel?: string | null;
};
export declare const asAlertPropTypes: PropTypes.ValidationMap<AsAlertProps>;
//# sourceMappingURL=types.d.ts.map