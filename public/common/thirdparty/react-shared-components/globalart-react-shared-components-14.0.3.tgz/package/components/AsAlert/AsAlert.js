var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import classnames from 'classnames';
import { faCheckCircle, faExclamationTriangle, faExclamationCircle, faInfoCircle } from '@fortawesome/free-solid-svg-icons';
import AsCloseButton from '../AsCloseButton/AsCloseButton';
import AsFontAwesomeIcon from '../AsFontAwesomeIcon/AsFontAwesomeIcon';
import { propTypes, asAlertPropTypes } from './types';
export { propTypes, asAlertPropTypes } from './types';
/**
 * Base component that renders a standardized alert.
 * @param children VDOM nodes to be included after the icon.
 * @param className CSS class names to apply to the rendered component.
 * @param icon FontAwesome icon data to render
 */
function AsAlert(props) {
    var className = props.className, icon = props.icon, iconLabel = props.iconLabel, children = props.children, onClose = props.onClose, otherProps = __rest(props, ["className", "icon", "iconLabel", "children", "onClose"]), classes = classnames('as-alert', className);
    return (React.createElement("div", __assign({}, otherProps, { className: classes, "aria-atomic": true }),
        React.createElement(AsFontAwesomeIcon, { "aria-label": iconLabel || undefined, "aria-hidden": !iconLabel, icon: icon }),
        React.createElement("div", { className: "as-alert__content-wrap" },
            React.createElement("div", { className: "as-alert__content" }, children)),
        onClose && React.createElement(AsCloseButton, { onClick: onClose })));
}
AsAlert.propTypes = asAlertPropTypes;
export default AsAlert;
/**
 * Component that renders a standardized error alert.
 * @param children VDOM nodes to be included after the icon.
 */
export function AsErrorAlert(props) {
    var classes = classnames('as-alert--error', props.className);
    return React.createElement(AsAlert, __assign({ role: "alert" }, props, { className: classes, icon: faExclamationCircle, iconLabel: "Error" }));
}
AsErrorAlert.propTypes = propTypes;
/**
 * Component that renders a standardized information alert.
 * @param children VDOM nodes to be included after the icon.
 */
export function AsInfoAlert(props) {
    var classes = classnames('as-alert--info', props.className);
    return React.createElement(AsAlert, __assign({}, props, { className: classes, icon: faInfoCircle, iconLabel: "Info" }));
}
AsInfoAlert.propTypes = propTypes;
/**
 * Component that renders a standardized warning alert.
 * @param children VDOM nodes to be included after the icon.
 */
export function AsWarningAlert(props) {
    var classes = classnames('as-alert--warning', props.className);
    return React.createElement(AsAlert, __assign({}, props, { className: classes, icon: faExclamationTriangle, iconLabel: "Warning" }));
}
AsWarningAlert.propTypes = propTypes;
/**
 * Component that renders a standardized success alert.
 * @param children VDOM nodes to be included after the icon.
 */
export function AsSuccessAlert(props) {
    var classes = classnames('as-alert--success', props.className);
    return React.createElement(AsAlert, __assign({ role: "status" }, props, { className: classes, icon: faCheckCircle, iconLabel: "Success" }));
}
AsSuccessAlert.propTypes = propTypes;
//# sourceMappingURL=AsAlert.js.map