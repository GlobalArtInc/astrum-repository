import * as PropTypes from 'prop-types';
;
// Casting to hack around flaws in react's typings: the typings for HTMLAttributes.className don't claim to accept null,
// but non-required proptypes do, and the actual implementation does
export var propTypes = {
    className: PropTypes.string,
    onClose: PropTypes.func
};
export var asAlertPropTypes = {
    icon: PropTypes.any,
    iconLabel: PropTypes.string,
    onClose: PropTypes.func
};
//# sourceMappingURL=types.js.map