import React from 'react';
import { Props } from '../types';
declare const AsStatefulAlert: React.FunctionComponent<import("../types").AsAlertProps>;
export default AsStatefulAlert;
export declare const AsStatefulErrorAlert: React.FunctionComponent<Props>;
export declare const AsStatefulInfoAlert: React.FunctionComponent<Props>;
export declare const AsStatefulWarningAlert: React.FunctionComponent<Props>;
export declare const AsStatefulSuccessAlert: React.FunctionComponent<Props>;
//# sourceMappingURL=AsStatefulAlert.d.ts.map