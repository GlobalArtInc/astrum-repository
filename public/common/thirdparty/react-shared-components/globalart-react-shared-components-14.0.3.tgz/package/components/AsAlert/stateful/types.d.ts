export declare const propTypes: Omit<import("prop-types").ValidationMap<import("../types").Props>, "onClose">;
export declare const asStatefulAlertPropTypes: Omit<import("prop-types").ValidationMap<import("../types").AsAlertProps>, "onClose">;
//# sourceMappingURL=types.d.ts.map