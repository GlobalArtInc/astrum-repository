import React from 'react';
import { Props, AsAlertProps } from './types';
export { Props, propTypes, AsAlertProps, asAlertPropTypes } from './types';
/**
 * Base component that renders a standardized alert.
 * @param children VDOM nodes to be included after the icon.
 * @param className CSS class names to apply to the rendered component.
 * @param icon FontAwesome icon data to render
 */
declare function AsAlert(props: AsAlertProps): React.JSX.Element;
declare namespace AsAlert {
    var propTypes: import("prop-types").ValidationMap<AsAlertProps>;
}
export default AsAlert;
/**
 * Component that renders a standardized error alert.
 * @param children VDOM nodes to be included after the icon.
 */
export declare function AsErrorAlert(props: Props): React.JSX.Element;
export declare namespace AsErrorAlert {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
/**
 * Component that renders a standardized information alert.
 * @param children VDOM nodes to be included after the icon.
 */
export declare function AsInfoAlert(props: Props): React.JSX.Element;
export declare namespace AsInfoAlert {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
/**
 * Component that renders a standardized warning alert.
 * @param children VDOM nodes to be included after the icon.
 */
export declare function AsWarningAlert(props: Props): React.JSX.Element;
export declare namespace AsWarningAlert {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
/**
 * Component that renders a standardized success alert.
 * @param children VDOM nodes to be included after the icon.
 */
export declare function AsSuccessAlert(props: Props): React.JSX.Element;
export declare namespace AsSuccessAlert {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
//# sourceMappingURL=AsAlert.d.ts.map