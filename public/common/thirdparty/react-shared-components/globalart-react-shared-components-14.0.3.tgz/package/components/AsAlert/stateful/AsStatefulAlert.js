var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import AsAlert, { AsSuccessAlert, AsWarningAlert, AsInfoAlert, AsErrorAlert } from '../AsAlert';
import { asStatefulAlertPropTypes, propTypes } from './types';
import useToggle from '../../../util/useToggle';
function mkStatefulAlertComponent(StatelessAlert) {
    return function AsStatefulAlertBase(props) {
        var _a = useToggle(true), isOpen = _a[0], onClose = _a[1];
        return isOpen ? React.createElement(StatelessAlert, __assign({}, __assign(__assign({}, props), { onClose: onClose }))) : null;
    };
}
var AsStatefulAlert = mkStatefulAlertComponent(AsAlert);
AsStatefulAlert.propTypes = asStatefulAlertPropTypes;
export default AsStatefulAlert;
export var AsStatefulErrorAlert = mkStatefulAlertComponent(AsErrorAlert);
export var AsStatefulInfoAlert = mkStatefulAlertComponent(AsInfoAlert);
export var AsStatefulWarningAlert = mkStatefulAlertComponent(AsWarningAlert);
export var AsStatefulSuccessAlert = mkStatefulAlertComponent(AsSuccessAlert);
AsStatefulErrorAlert.propTypes = AsStatefulWarningAlert.propTypes = AsStatefulInfoAlert.propTypes =
    AsStatefulSuccessAlert.propTypes = propTypes;
//# sourceMappingURL=AsStatefulAlert.js.map