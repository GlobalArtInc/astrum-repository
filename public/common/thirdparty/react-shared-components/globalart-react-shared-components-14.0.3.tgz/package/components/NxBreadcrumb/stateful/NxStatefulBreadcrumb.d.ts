import React from 'react';
import { StatefulProps } from '../types';
export { StatefulProps as Props };
export default function NxStatefulBreadcrumb(props: StatefulProps): React.JSX.Element;
//# sourceMappingURL=NxStatefulBreadcrumb.d.ts.map