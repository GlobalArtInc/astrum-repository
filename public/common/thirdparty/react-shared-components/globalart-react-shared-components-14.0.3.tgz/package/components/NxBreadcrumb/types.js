var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
import * as PropTypes from 'prop-types';
export var statefulPropTypes = {
    crumbs: PropTypes.arrayOf(PropTypes.shape({
        name: PropTypes.string.isRequired,
        href: PropTypes.string.isRequired
    }).isRequired).isRequired
};
export var propTypes = __assign(__assign({}, statefulPropTypes), { isDropdownOpen: PropTypes.bool.isRequired, onToggleDropdown: PropTypes.func.isRequired });
//# sourceMappingURL=types.js.map