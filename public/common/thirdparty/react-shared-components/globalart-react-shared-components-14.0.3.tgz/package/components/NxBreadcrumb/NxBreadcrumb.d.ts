import React from 'react';
import { Props, Crumb } from './types';
import './NxBreadcrumb.scss';
export { Props, Crumb };
declare function NxBreadcrumb(props: Props): React.JSX.Element | null;
declare namespace NxBreadcrumb {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default NxBreadcrumb;
//# sourceMappingURL=NxBreadcrumb.d.ts.map