import { ComponentPropsWithRef } from 'react';
import * as PropTypes from 'prop-types';
export interface Crumb {
    name: string;
    href: string;
}
export interface DropdownProps {
    crumbs: Crumb[];
    isOpen: boolean;
    onToggleCollapse: () => void;
}
export interface StatefulProps extends ComponentPropsWithRef<'nav'> {
    crumbs: Crumb[];
}
export interface Props extends StatefulProps {
    isDropdownOpen: boolean;
    onToggleDropdown: () => void;
}
export declare const statefulPropTypes: PropTypes.ValidationMap<StatefulProps>;
export declare const propTypes: PropTypes.ValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map