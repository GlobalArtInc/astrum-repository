import * as PropTypes from 'prop-types';
import { requiredNullableString } from '../../util/customPropTypes';
// In a strictly typescript environment, PropTypes are mostly redundant.  However, they still provide safety when this
// project is consumed by javascript projects
export var propTypes = {
    name: PropTypes.string.isRequired,
    value: requiredNullableString,
    onChange: PropTypes.func,
    isChecked: PropTypes.bool.isRequired,
    disabled: PropTypes.bool,
    radioId: PropTypes.string,
    overflowTooltip: PropTypes.bool,
    inputAttributes: PropTypes.object
};
//# sourceMappingURL=types.js.map