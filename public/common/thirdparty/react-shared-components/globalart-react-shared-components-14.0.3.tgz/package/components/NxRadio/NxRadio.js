var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import classnames from 'classnames';
import { omit } from 'ramda';
import './NxRadio.scss';
import { propTypes } from './types';
import NxOverflowTooltip from '../NxTooltip/NxOverflowTooltip';
export default function NxRadio(props) {
    var className = props.className, name = props.name, value = props.value, onChange = props.onChange, isChecked = props.isChecked, disabled = props.disabled, children = props.children, radioId = props.radioId, overflowTooltip = props.overflowTooltip, _a = props.inputAttributes, inputAttributes = _a === void 0 ? {} : _a, otherProps = __rest(props, ["className", "name", "value", "onChange", "isChecked", "disabled", "children", "radioId", "overflowTooltip", "inputAttributes"]), labelClasses = classnames('nx-radio-checkbox', 'nx-radio', className, {
        'nx-radio-checkbox--disabled': disabled,
        'tm-checked': isChecked,
        'tm-unchecked': !isChecked
    }), content = children && React.createElement("span", { className: "nx-radio-checkbox__content nx-radio__content" }, children);
    var _b = inputAttributes, radioClassName = _b.className, unfilteredInputAttributes = __rest(_b, ["className"]);
    var otherInputAttributes = omit(['name', 'disabled', 'checked', 'onChange', 'readOnly'], unfilteredInputAttributes);
    return (React.createElement("label", __assign({}, otherProps, { className: labelClasses }),
        React.createElement("input", __assign({ className: classnames('nx-radio-checkbox__input', 'nx-radio__input', radioClassName), id: otherInputAttributes.id || radioId || undefined, type: "radio", name: name, disabled: !!disabled, checked: isChecked, onChange: function () { return onChange && onChange(value); }, readOnly: !onChange }, otherInputAttributes)),
        React.createElement("span", { className: "nx-radio-checkbox__control nx-radio__circle" }),
        React.createElement("span", { className: "nx-radio__focus" }),
        content &&
            (overflowTooltip !== false ? React.createElement(NxOverflowTooltip, null, content) : content)));
}
NxRadio.propTypes = propTypes;
//# sourceMappingURL=NxRadio.js.map