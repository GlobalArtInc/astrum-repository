import React from 'react';
import './NxRadio.scss';
import { Props } from './types';
export { Props } from './types';
declare function NxRadio(props: Props): React.JSX.Element;
declare namespace NxRadio {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default NxRadio;
//# sourceMappingURL=NxRadio.d.ts.map