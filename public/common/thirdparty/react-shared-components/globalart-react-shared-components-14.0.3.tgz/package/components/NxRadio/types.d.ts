import { ComponentPropsWithoutRef, ComponentPropsWithRef } from 'react';
import * as PropTypes from 'prop-types';
type InputAttributesProp = Omit<ComponentPropsWithoutRef<'input'>, 'name' | 'disabled' | 'checked' | 'onChange' | 'readonly'>;
export type Props = Omit<ComponentPropsWithRef<'label'>, 'onChange'> & {
    name: string;
    value: string | null;
    onChange?: ((currentValue: string | null) => void) | null;
    isChecked: boolean;
    disabled?: boolean | null;
    radioId?: string | null;
    overflowTooltip?: boolean | null;
    inputAttributes?: InputAttributesProp;
};
export declare const propTypes: PropTypes.ValidationMap<Props>;
export {};
//# sourceMappingURL=types.d.ts.map