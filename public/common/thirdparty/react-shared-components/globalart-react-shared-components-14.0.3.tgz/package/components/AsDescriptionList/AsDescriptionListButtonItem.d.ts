import React from 'react';
import { ButtonItemProps } from './types';
declare function AsDescriptionListButtonItem(props: ButtonItemProps): React.JSX.Element;
declare namespace AsDescriptionListButtonItem {
    var propTypes: import("prop-types").ValidationMap<ButtonItemProps>;
}
export default AsDescriptionListButtonItem;
//# sourceMappingURL=AsDescriptionListButtonItem.d.ts.map