import React from 'react';
import AsDescriptionListButtonItem from './AsDescriptionListButtonItem';
import AsDescriptionListLinkItem from './AsDescriptionListLinkItem';
import { Props } from './types';
export { Props, ButtonItemProps, LinkItemProps } from './types';
declare function AsDescriptionList({ ref: externalRef, emptyMessage, className, ...otherProps }: Props): React.JSX.Element;
declare namespace AsDescriptionList {
    var propTypes: import("prop-types").ValidationMap<Props>;
    var Item: (props: React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => React.ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | React.JSXElementConstructor<any>>;
    var Term: (props: React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement>) => React.ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement>, "className">, string | React.JSXElementConstructor<any>>;
    var Description: (props: React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement>) => React.ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement>, "className">, string | React.JSXElementConstructor<any>>;
    var ButtonItem: typeof AsDescriptionListButtonItem;
    var LinkItem: typeof AsDescriptionListLinkItem;
}
export default AsDescriptionList;
//# sourceMappingURL=AsDescriptionList.d.ts.map