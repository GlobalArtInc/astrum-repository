import React from 'react';
import { LinkItemProps } from './types';
declare function AsDescriptionListLinkItem(props: LinkItemProps): React.JSX.Element;
declare namespace AsDescriptionListLinkItem {
    var propTypes: import("prop-types").ValidationMap<LinkItemProps>;
}
export default AsDescriptionListLinkItem;
//# sourceMappingURL=AsDescriptionListLinkItem.d.ts.map