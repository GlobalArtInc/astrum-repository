var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import classnames from 'classnames';
import { faEllipsisV } from '@fortawesome/free-solid-svg-icons';
import { propTypes } from './types';
import AsButton from '../AsButton/AsButton';
import AsFontAwesomeIcon from '../AsFontAwesomeIcon/AsFontAwesomeIcon';
import './AsIconDropdown.scss';
import AsOverflowTooltip from '../AsTooltip/AsOverflowTooltip';
import AbstractDropdown from '../AsDropdown/AbstractDropdown';
var AsIconDropdown = function AsIconDropdown(props) {
    var icon = props.icon, className = props.className, isOpen = props.isOpen, disabled = props.disabled, children = props.children, title = props.title, otherProps = __rest(props, ["icon", "className", "isOpen", "disabled", "children", "title"]);
    var buttonClasses = classnames('as-icon-dropdown__toggle', { disabled: disabled, open: isOpen });
    var classes = classnames('as-dropdown as-icon-dropdown', className);
    // Wrap .as-dropdown-button and .as-dropdown-link children in overflow tooltips
    var wrappedChildren = children && React.Children.map(children, function (child) { return (child && typeof child !== 'boolean' && child.props.className &&
        /(\s|^)as-dropdown-(button|link)(\s|$)/.test(child.props.className) ?
        React.createElement(AsOverflowTooltip, null, child) :
        child); });
    var renderToggleElement = function (toggleRef, onToggleCollapse) { return (React.createElement(AsButton, { ref: toggleRef, type: "button", variant: "icon-only", className: buttonClasses, onClick: !disabled && onToggleCollapse || undefined, "aria-haspopup": "true", "aria-expanded": isOpen, title: title },
        React.createElement(AsFontAwesomeIcon, { icon: icon || faEllipsisV }))); };
    return (React.createElement(AbstractDropdown, __assign({ className: classes, renderToggleElement: renderToggleElement, isOpen: isOpen, disabled: disabled }, otherProps), wrappedChildren));
};
AsIconDropdown.propTypes = propTypes;
export default AsIconDropdown;
export { propTypes } from './types';
//# sourceMappingURL=AsIconDropdown.js.map