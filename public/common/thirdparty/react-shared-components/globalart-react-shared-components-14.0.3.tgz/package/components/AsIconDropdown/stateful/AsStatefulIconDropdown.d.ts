import { FunctionComponent } from 'react';
import { Props } from './types';
declare const AsStatefulIconDropdown: FunctionComponent<Props>;
export default AsStatefulIconDropdown;
export { Props, propTypes } from './types';
//# sourceMappingURL=AsStatefulIconDropdown.d.ts.map