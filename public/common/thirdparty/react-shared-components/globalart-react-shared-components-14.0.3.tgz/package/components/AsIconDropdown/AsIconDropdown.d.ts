import { FunctionComponent } from 'react';
import { Props } from './types';
import './AsIconDropdown.scss';
declare const AsIconDropdown: FunctionComponent<Props>;
export default AsIconDropdown;
export { Props, propTypes } from './types';
//# sourceMappingURL=AsIconDropdown.d.ts.map