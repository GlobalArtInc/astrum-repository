import * as PropTypes from 'prop-types';
import { childrenPropTypes } from '../../AsDropdown/types';
;
export var propTypes = {
    children: childrenPropTypes,
    disabled: PropTypes.bool,
    icon: PropTypes.any
};
//# sourceMappingURL=types.js.map