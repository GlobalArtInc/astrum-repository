import React from 'react';
import { NxDrawerHeaderProps, NxDrawerHeaderTitleProps, Props } from './types';
import './NxDrawer.scss';
declare function NxDrawerHeaderTitle(props: NxDrawerHeaderTitleProps): React.JSX.Element;
declare namespace NxDrawerHeaderTitle {
    var propTypes: import("prop-types").WeakValidationMap<React.DetailedHTMLProps<React.HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>>;
}
declare function NxDrawer(props: Props): React.JSX.Element;
declare const _default: typeof NxDrawer & {
    propTypes: import("prop-types").ValidationMap<Props>;
    Header: (props: NxDrawerHeaderProps) => React.JSX.Element;
    Content: (props: React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => React.ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | React.JSXElementConstructor<any>>;
    HeaderTitle: typeof NxDrawerHeaderTitle;
    HeaderSubtitle: (props: React.DetailedHTMLProps<React.HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>) => React.ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>, "className">, string | React.JSXElementConstructor<any>>;
    HeaderDescription: (props: React.DetailedHTMLProps<React.HTMLAttributes<HTMLParagraphElement>, HTMLParagraphElement>) => React.ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLParagraphElement>, HTMLParagraphElement>, "className">, string | React.JSXElementConstructor<any>>;
};
export default _default;
export { Props } from './types';
//# sourceMappingURL=NxDrawer.d.ts.map