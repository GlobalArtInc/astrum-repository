import * as PropTypes from 'prop-types';
export var NX_DRAWER_VARIANTS = ['normal', 'narrow'];
export var propTypes = {
    open: PropTypes.bool.isRequired,
    onClose: PropTypes.func.isRequired,
    onCancel: PropTypes.func,
    variant: PropTypes.oneOf(NX_DRAWER_VARIANTS),
    closeDisabled: PropTypes.bool,
    closeBtnTooltip: PropTypes.string
};
export var nxDrawerHeaderTitlePropTypes = {
    className: PropTypes.string,
    children: PropTypes.node
};
//# sourceMappingURL=types.js.map