import { ComponentPropsWithRef, ReactNode } from 'react';
import * as PropTypes from 'prop-types';
export declare const NX_DRAWER_VARIANTS: readonly ["normal", "narrow"];
export type NX_DRAWER_VARIANT_TYPE = (typeof NX_DRAWER_VARIANTS)[number];
export type OpenState = 'open' | 'closed' | 'opening' | 'closing';
export interface Props extends Omit<ComponentPropsWithRef<'dialog'>, 'onCancel'> {
    open: boolean;
    onClose: () => void;
    onCancel?: (() => void) | null;
    children?: ReactNode;
    variant?: NX_DRAWER_VARIANT_TYPE | null;
    closeDisabled?: boolean | null;
    closeBtnTooltip?: string | null;
}
export type NxDrawerHeaderProps = ComponentPropsWithRef<'header'>;
export type NxDrawerHeaderTitleProps = ComponentPropsWithRef<'h2'>;
export interface NxDrawerContextValue {
    closeDrawer: () => void;
    closeDisabled?: boolean | null;
    closeBtnTooltip?: string | null;
}
export declare const propTypes: PropTypes.ValidationMap<Props>;
export declare const nxDrawerHeaderTitlePropTypes: PropTypes.WeakValidationMap<NxDrawerHeaderTitleProps>;
//# sourceMappingURL=types.d.ts.map