import * as PropTypes from 'prop-types';
export var propTypes = {
    logo: PropTypes.node.isRequired,
    links: PropTypes.arrayOf(PropTypes.shape({
        name: PropTypes.string.isRequired,
        href: PropTypes.string.isRequired,
        current: PropTypes.bool
    }).isRequired),
    homeLink: PropTypes.string,
    productInfoContent: PropTypes.node,
    className: PropTypes.string
};
//# sourceMappingURL=types.js.map