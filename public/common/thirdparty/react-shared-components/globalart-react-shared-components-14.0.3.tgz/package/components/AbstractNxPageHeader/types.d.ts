import { ReactNode } from 'react';
import * as PropTypes from 'prop-types';
export interface HeaderLinkProps {
    name: string;
    href: string;
    current?: boolean | null;
}
export interface Props {
    logo: ReactNode;
    links?: HeaderLinkProps[] | null;
    homeLink?: string | null;
    productInfoContent?: ReactNode | null;
    className?: string | null;
    children?: ReactNode | null;
}
export declare const propTypes: PropTypes.ValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map