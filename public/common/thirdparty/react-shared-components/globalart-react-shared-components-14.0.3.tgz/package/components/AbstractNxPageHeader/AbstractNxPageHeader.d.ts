import React from 'react';
import { HeaderLinkProps, Props } from './types';
export { Props };
declare function HeaderLink({ name, href, current }: HeaderLinkProps): React.JSX.Element;
export { HeaderLinkProps, HeaderLink };
declare function NxPageHeader({ className, links, homeLink, productInfoContent, logo, children }: Props): React.JSX.Element;
declare namespace NxPageHeader {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default NxPageHeader;
//# sourceMappingURL=AbstractNxPageHeader.d.ts.map