var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import classnames from 'classnames';
import { propTypes } from './types';
function HeaderLink(_a) {
    var name = _a.name, href = _a.href, current = _a.current;
    var classes = classnames('nx-page-header__link', {
        'nx-page-header__link--current': current
    });
    return (React.createElement("a", { className: classes, href: href, "data-text": name, "aria-current": current ? 'page' : undefined }, name));
}
// visible for testing
export { HeaderLink };
export default function NxPageHeader(_a) {
    var className = _a.className, links = _a.links, homeLink = _a.homeLink, productInfoContent = _a.productInfoContent, logo = _a.logo, children = _a.children;
    var linkEls = links && links.map(function (link) { return React.createElement(HeaderLink, __assign({ key: link.name }, link)); }), classes = classnames('nx-page-header', className);
    return (React.createElement("header", { className: classes },
        React.createElement("div", { className: "nx-page-header__inner" },
            React.createElement("div", { className: "nx-product" },
                React.createElement("div", { className: "nx-product__logo" }, homeLink ? React.createElement("a", { className: "nx-product__home-link", href: homeLink, "aria-label": "Home" }, logo) : logo),
                productInfoContent),
            linkEls && React.createElement("div", { className: "nx-page-header__links" }, linkEls),
            children && React.createElement("div", { className: "nx-page-header__extra-content" }, children))));
}
NxPageHeader.propTypes = propTypes;
//# sourceMappingURL=AbstractNxPageHeader.js.map