var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import { propEq, find } from 'ramda';
import { propTypes } from './types';
import Counter from '../../Counter/Counter';
import NxRadio from '../../NxRadio/NxRadio';
import AbstractCollapsibleItemsSelect, { generateId } from '../AbstractCollapsibleItemsSelect';
function NxCollapsibleRadioSelect(props) {
    var selectedId = props.selectedId, onChange = props.onChange, optionTooltipGenerator = props.optionTooltipGenerator, otherProps = __rest(props, ["selectedId", "onChange", "optionTooltipGenerator"]), name = otherProps.name, options = otherProps.options, disabled = !!props.disabled, selectedItem = find(propEq(selectedId, 'id'), options);
    var renderOption = function (_a) {
        var id = _a.id, optionName = _a.name;
        return (
        // NxCollapsibleItemsChild takes empty role to mean no role and normalizes it correctly
        React.createElement(NxRadio, { radioId: generateId(name, id), name: name, value: id, isChecked: id === selectedId, onChange: onChange, overflowTooltip: !optionTooltipGenerator, disabled: disabled, inputAttributes: { role: 'menuitemradio' }, role: "" }, optionName));
    };
    var renderCounter = function () {
        return selectedItem
            && selectedItem.name ? React.createElement(Counter, null, selectedItem.name) : null;
    };
    return React.createElement(AbstractCollapsibleItemsSelect, __assign({}, props, { optionTooltipGenerator: optionTooltipGenerator, renderOption: renderOption, renderCounter: renderCounter }));
}
NxCollapsibleRadioSelect.propTypes = propTypes;
export default NxCollapsibleRadioSelect;
//# sourceMappingURL=NxCollapsibleRadioSelect.js.map