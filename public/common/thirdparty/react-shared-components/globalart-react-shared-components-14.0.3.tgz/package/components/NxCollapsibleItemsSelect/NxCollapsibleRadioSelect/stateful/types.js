import * as PropTypes from 'prop-types';
import { optionPropType } from '../../commonTypes';
export var propTypes = {
    options: PropTypes.arrayOf(optionPropType).isRequired,
    name: PropTypes.string.isRequired,
    children: PropTypes.oneOfType([
        PropTypes.arrayOf(PropTypes.node),
        PropTypes.node
    ]),
    id: PropTypes.string,
    onChange: PropTypes.func.isRequired,
    selectedId: PropTypes.string,
    isOpen: PropTypes.bool,
    disabled: PropTypes.bool,
    disabledTooltip: PropTypes.string,
    optionTooltipGenerator: PropTypes.func,
    tooltipModifierClass: PropTypes.string,
    filterPlaceholder: PropTypes.string,
    filterThreshold: PropTypes.number
};
//# sourceMappingURL=types.js.map