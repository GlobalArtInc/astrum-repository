var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import { all, propEq, any } from 'ramda';
import { propTypes } from './types';
import NxCheckbox from '../../NxCheckbox/NxCheckbox';
import MultiSelectCounter from '../../Counter/MultiSelectCounter';
import AbstractCollapsibleItemsSelect, { generateId } from '../AbstractCollapsibleItemsSelect';
import { isProduction } from '../../../util/envUtil';
function NxCollapsibleMultiSelect(props) {
    // exclude onChange and selectedIds from the props we pass to AbstractCollapsibleItemsSelect
    var onChange = props.onChange, selectedIds = props.selectedIds, optionTooltipGenerator = props.optionTooltipGenerator, otherProps = __rest(props, ["onChange", "selectedIds", "optionTooltipGenerator"]);
    var options = props.options, name = props.name, filteredOptions = props.filteredOptions || options, normalizedSelectedIds = selectedIds || new Set(), disabled = !!props.disabled, allFilteredSelected = all(function (item) { return normalizedSelectedIds.has(item.id); }, filteredOptions);
    if (!isProduction) {
        // Throw an error if one of the selectedIds is not part of the available options
        normalizedSelectedIds.forEach(function (itemId) {
            if (!any(propEq(itemId, 'id'), options)) {
                throw new Error("You are attempting to select \"".concat(itemId, "\", but it is not part of the available options"));
            }
        });
    }
    function toggle(id) {
        var newSelected = new Set(normalizedSelectedIds);
        if (newSelected.has(id)) {
            newSelected.delete(id);
        }
        else {
            newSelected.add(id);
        }
        onChange(newSelected, id);
    }
    function toggleSelectAll() {
        var isFiltered = options.length > filteredOptions.length;
        if (isFiltered) {
            var newSelected_1 = new Set(normalizedSelectedIds);
            if (allFilteredSelected) {
                filteredOptions.forEach(function (option) { return newSelected_1.delete(option.id); });
            }
            else {
                filteredOptions.forEach(function (option) { return newSelected_1.add(option.id); });
            }
            onChange(newSelected_1);
        }
        else {
            // logically same as above but optimized since we don't need to iterate over filteredOptions
            var allAvailableSelected = options.length === normalizedSelectedIds.size;
            if (allAvailableSelected) {
                onChange(new Set());
            }
            else {
                var allIds = options.map(function (option) { return option.id; });
                onChange(new Set(allIds));
            }
        }
    }
    var renderOption = function (_a) {
        var id = _a.id, optionName = _a.name;
        return (React.createElement(NxCheckbox, { checkboxId: generateId(name, id), onChange: function () { return toggle(id); }, isChecked: normalizedSelectedIds.has(id), overflowTooltip: !optionTooltipGenerator, disabled: disabled, inputAttributes: { role: 'menuitemcheckbox' }, role: "" }, optionName));
    };
    var renderToggleAllOption = function () { return filteredOptions.length > 0 ? (React.createElement(NxCheckbox, { checkboxId: generateId(name, 'all/none'), onChange: toggleSelectAll, isChecked: allFilteredSelected, disabled: disabled, inputAttributes: { role: 'menuitemcheckbox' }, role: "" }, "all/none")) : null; };
    var renderCounter = function () { return React.createElement(MultiSelectCounter, { options: options, selectedIds: normalizedSelectedIds }); };
    return React.createElement(AbstractCollapsibleItemsSelect, __assign({}, otherProps, { optionTooltipGenerator: optionTooltipGenerator, renderOption: renderOption, renderToggleAllOption: renderToggleAllOption, renderCounter: renderCounter }));
}
NxCollapsibleMultiSelect.propTypes = propTypes;
export default NxCollapsibleMultiSelect;
//# sourceMappingURL=NxCollapsibleMultiSelect.js.map