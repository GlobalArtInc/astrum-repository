import React from 'react';
import { Props } from './types';
import { Option } from '../../commonTypes';
export { Props, Option } from './types';
declare function NxStatefulCollapsibleRadioSelect<T extends Option>(props: Props<T>): React.JSX.Element;
declare namespace NxStatefulCollapsibleRadioSelect {
    var propTypes: import("prop-types").ValidationMap<Props<Option>>;
}
export default NxStatefulCollapsibleRadioSelect;
//# sourceMappingURL=NxStatefulCollapsibleRadioSelect.d.ts.map