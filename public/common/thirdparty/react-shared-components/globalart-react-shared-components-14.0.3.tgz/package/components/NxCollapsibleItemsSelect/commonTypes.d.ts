import { ReactNode } from 'react';
import * as PropTypes from 'prop-types';
import RequiredReactNode from '../../util/RequiredReactNode';
export interface Option {
    id: string | null;
    name: RequiredReactNode;
}
export interface CommonProps<T extends Option = Option> {
    options: T[];
    name: string;
    children: ReactNode;
    id?: string | null;
    isOpen?: boolean | null;
    onToggleCollapse?: (() => void) | null;
    disabled?: boolean | null;
    disabledTooltip?: string | null;
    optionTooltipGenerator?: ((option: T) => string) | null;
    tooltipModifierClass?: string | null;
    onFilterChange?: ((filter: string) => void) | null;
    filter?: string | null;
    filteredOptions?: T[] | null;
    filterPlaceholder?: string | null;
    filterThreshold?: number | null;
}
export declare const optionPropType: PropTypes.Validator<Option>;
export declare const commonPropTypes: PropTypes.ValidationMap<CommonProps>;
//# sourceMappingURL=commonTypes.d.ts.map