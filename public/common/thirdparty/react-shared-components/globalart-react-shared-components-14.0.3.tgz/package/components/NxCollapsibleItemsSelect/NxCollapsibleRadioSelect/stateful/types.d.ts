import { ReactNode } from 'react';
import * as PropTypes from 'prop-types';
import { Option } from '../../commonTypes';
export { Option } from '../../commonTypes';
export interface Props<T extends Option = Option> {
    options: T[];
    name: string;
    children: ReactNode;
    onChange: ((selected: string | null, toggledId?: string | null) => void);
    selectedId?: string | null;
    id?: string | null;
    isOpen?: boolean | null;
    disabled?: boolean | null;
    disabledTooltip?: string | null;
    optionTooltipGenerator?: ((option: T) => string) | null;
    tooltipModifierClass?: string | null;
    filterPlaceholder?: string | null;
    filterThreshold?: number | null;
}
export declare const propTypes: PropTypes.ValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map