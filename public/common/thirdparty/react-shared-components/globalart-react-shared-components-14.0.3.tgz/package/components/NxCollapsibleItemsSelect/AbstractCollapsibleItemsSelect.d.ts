import React, { HTMLAttributes, ReactElement } from 'react';
import { Option } from './commonTypes';
import { CommonProps } from './commonTypes';
import { NxCollapsibleItemsChildElement } from '../NxCollapsibleItems/types';
export interface Props<T extends Option = Option> extends CommonProps<T> {
    renderOption: (option: T) => NxCollapsibleItemsChildElement;
    renderToggleAllOption?: (() => NxCollapsibleItemsChildElement | null) | null;
    renderCounter?: (() => ReactElement<HTMLAttributes<HTMLElement>> | null) | null;
}
export declare function generateId(groupName: string, elementId: string | null): string;
declare function AbstractCollapsibleItemsSelect<T extends Option>(props: Props<T>): React.JSX.Element;
export default AbstractCollapsibleItemsSelect;
//# sourceMappingURL=AbstractCollapsibleItemsSelect.d.ts.map