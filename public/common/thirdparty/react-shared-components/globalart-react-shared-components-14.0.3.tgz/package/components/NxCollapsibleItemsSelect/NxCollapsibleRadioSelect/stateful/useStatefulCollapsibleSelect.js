/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import { useMemo, useState } from 'react';
import { map, prop } from 'ramda';
import { textContent } from '../../../../util/childUtil';
import useFuzzyFilter from '../../../../util/useFuzzyFilter';
/**
 * Common logic for NxStatefulCollapsibleMultiSelect and NxStatefulCollapsibleRadioSelect. Tracks the open state
 * and the filtering
 */
export default function useStatefulCollapsibleSelect(props) {
    var options = props.options, optionTooltipGeneratorProp = props.optionTooltipGenerator, isOpenInitialState = !!props.isOpen;
    var _a = useState(isOpenInitialState), isOpen = _a[0], toggleOpen = _a[1], onToggleCollapse = function () {
        toggleOpen(!isOpen);
    };
    var wrappedOptions = useMemo(function () { return map(function (option) { return ({ option: option, stringName: textContent(option.name) }); }, options); }, [options]);
    var _b = useFuzzyFilter(wrappedOptions, { keys: ['stringName'], threshold: 0.1 }), filteredWrappedOptions = _b[0], filter = _b[1], onFilterChange = _b[2];
    var filteredOptions = useMemo(function () { return map(prop('option'), filteredWrappedOptions); }, [filteredWrappedOptions]);
    var optionTooltipGenerator = optionTooltipGeneratorProp && function optionTooltipGenerator(option) {
        return optionTooltipGeneratorProp(option);
    };
    return { isOpen: isOpen, onToggleCollapse: onToggleCollapse, filteredOptions: filteredOptions, optionTooltipGenerator: optionTooltipGenerator, filter: filter, onFilterChange: onFilterChange };
}
//# sourceMappingURL=useStatefulCollapsibleSelect.js.map