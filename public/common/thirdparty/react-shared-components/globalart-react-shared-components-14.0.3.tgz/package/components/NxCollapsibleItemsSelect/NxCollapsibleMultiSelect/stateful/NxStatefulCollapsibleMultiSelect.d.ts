import React from 'react';
import { Props } from './types';
import { Option } from '../../commonTypes';
export { Props, Option } from './types';
declare function NxStatefulCollapsibleMultiSelect<T extends Option>(props: Props<T>): React.JSX.Element;
declare namespace NxStatefulCollapsibleMultiSelect {
    var propTypes: import("prop-types").ValidationMap<Props<Option>>;
}
export default NxStatefulCollapsibleMultiSelect;
//# sourceMappingURL=NxStatefulCollapsibleMultiSelect.d.ts.map