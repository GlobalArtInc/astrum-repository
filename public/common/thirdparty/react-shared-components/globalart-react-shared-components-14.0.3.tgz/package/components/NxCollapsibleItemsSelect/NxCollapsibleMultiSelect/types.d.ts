import * as PropTypes from 'prop-types';
import { CommonProps, Option } from '../commonTypes';
export { Option } from '../commonTypes';
export interface Props<T extends Option = Option> extends CommonProps<T> {
    selectedIds?: Set<string | null> | null;
    onChange: ((selectedIds: Set<string | null>, toggledId?: string | null) => void);
}
export declare const propTypes: PropTypes.WeakValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map