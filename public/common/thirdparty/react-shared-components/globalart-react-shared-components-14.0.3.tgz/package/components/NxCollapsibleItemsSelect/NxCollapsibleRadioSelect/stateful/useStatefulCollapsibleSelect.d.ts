import { Option } from '../../commonTypes';
import { Props } from './types';
/**
 * Common logic for NxStatefulCollapsibleMultiSelect and NxStatefulCollapsibleRadioSelect. Tracks the open state
 * and the filtering
 */
export default function useStatefulCollapsibleSelect<T extends Option>(props: Pick<Props<T>, 'isOpen' | 'options' | 'optionTooltipGenerator'>): {
    isOpen: boolean;
    onToggleCollapse: () => void;
    filteredOptions: T[];
    optionTooltipGenerator: ((option: T) => string) | null | undefined;
    filter: string;
    onFilterChange: (s: string) => void;
};
//# sourceMappingURL=useStatefulCollapsibleSelect.d.ts.map