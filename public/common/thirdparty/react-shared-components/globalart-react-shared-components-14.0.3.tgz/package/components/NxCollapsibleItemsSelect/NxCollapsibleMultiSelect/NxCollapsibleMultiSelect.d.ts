import React from 'react';
import { Props, Option } from './types';
export { Props, Option } from './types';
declare function NxCollapsibleMultiSelect<T extends Option>(props: Props<T>): React.JSX.Element;
declare namespace NxCollapsibleMultiSelect {
    var propTypes: import("prop-types").WeakValidationMap<Props<Option>>;
}
export default NxCollapsibleMultiSelect;
//# sourceMappingURL=NxCollapsibleMultiSelect.d.ts.map