import * as PropTypes from 'prop-types';
import { requiredNullableString } from '../../util/customPropTypes';
export var optionPropType = PropTypes.shape({
    id: requiredNullableString,
    name: PropTypes.node.isRequired
}).isRequired;
export var commonPropTypes = {
    options: PropTypes.arrayOf(optionPropType).isRequired,
    name: PropTypes.string.isRequired,
    children: PropTypes.oneOfType([
        PropTypes.arrayOf(PropTypes.node),
        PropTypes.node
    ]),
    id: PropTypes.string,
    isOpen: PropTypes.bool,
    onToggleCollapse: PropTypes.func,
    disabled: PropTypes.bool,
    disabledTooltip: PropTypes.string,
    optionTooltipGenerator: PropTypes.func,
    tooltipModifierClass: PropTypes.string,
    onFilterChange: PropTypes.func,
    filter: PropTypes.string,
    filteredOptions: PropTypes.arrayOf(optionPropType),
    filterPlaceholder: PropTypes.string,
    filterThreshold: PropTypes.number
};
//# sourceMappingURL=commonTypes.js.map