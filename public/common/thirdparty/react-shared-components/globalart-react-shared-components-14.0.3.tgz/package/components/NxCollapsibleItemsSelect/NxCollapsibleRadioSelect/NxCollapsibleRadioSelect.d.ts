import React from 'react';
import { Props, Option } from './types';
export { Props, Option } from './types';
declare function NxCollapsibleRadioSelect<T extends Option>(props: Props<T>): React.JSX.Element;
declare namespace NxCollapsibleRadioSelect {
    var propTypes: import("prop-types").WeakValidationMap<Props<Option>>;
}
export default NxCollapsibleRadioSelect;
//# sourceMappingURL=NxCollapsibleRadioSelect.d.ts.map