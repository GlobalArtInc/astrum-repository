import * as PropTypes from 'prop-types';
import { PublicProps as AsTextInputProps } from '../AsTextInput/AsTextInput';
export interface Props extends Omit<AsTextInputProps, 'validatable' | 'isPristine' | 'validationErrors' | 'type'> {
    searchIcon?: boolean | null;
}
export declare const propTypes: PropTypes.ValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map