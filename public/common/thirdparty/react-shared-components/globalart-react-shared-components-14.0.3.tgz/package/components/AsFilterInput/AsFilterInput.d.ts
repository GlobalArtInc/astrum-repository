import React from 'react';
import './AsFilterInput.scss';
import { Props } from './types';
export { Props } from './types';
declare function AsFilterInput(props: Props): React.JSX.Element;
declare namespace AsFilterInput {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default AsFilterInput;
//# sourceMappingURL=AsFilterInput.d.ts.map