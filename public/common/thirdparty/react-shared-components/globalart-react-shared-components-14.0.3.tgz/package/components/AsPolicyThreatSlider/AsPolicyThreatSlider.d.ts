import { FunctionComponent } from 'react';
import { Props } from './types';
export { Props, PolicyThreatLevelRange, propTypes } from './types';
import './AsPolicyThreatSlider.scss';
declare const AsPolicyThreatSlider: FunctionComponent<Props>;
export default AsPolicyThreatSlider;
//# sourceMappingURL=AsPolicyThreatSlider.d.ts.map