var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import { Slider } from '@mui/material';
import classnames from 'classnames';
import { categoryByPolicyThreatLevel } from '../../util/threatLevels';
import { propTypes } from './types';
export { propTypes } from './types';
import './AsPolicyThreatSlider.scss';
function toThreatLevelNumber(value) {
    return Math.min(10, Math.max(0, Math.round(value)));
}
function getPolicyThreatCategory(value) {
    return categoryByPolicyThreatLevel[toThreatLevelNumber(value)];
}
var getAriaLabel = function (index) { return "threat level ".concat(index === 0 ? 'min' : 'max'); };
var getAriaValueText = function (value) {
    var limitedValue = toThreatLevelNumber(value), threatCategory = getPolicyThreatCategory(value);
    return "".concat(limitedValue, " (").concat(threatCategory, ")");
};
/**
 * A ValueLabelComponent that renders the values inside of the thumbs and changes CSS classes depending on
 * position/value
 */
// MUI doesn't appear to define an accurate type for these props. There's SliderValueLabelProps but it's missing
// valueLabelDisplay, valueLabelFormat, and ownerState
//eslint-disable-next-line @typescript-eslint/no-explicit-any
function ValueLabel(props) {
    var value = props.value, className = props.className, ownerState = props.ownerState, children = props.children, valueLabelDisplay = props.valueLabelDisplay, valueLabelFormat = props.valueLabelFormat, otherProps = __rest(props, ["value", "className", "ownerState", "children", "valueLabelDisplay", "valueLabelFormat"]), threatCategory = getPolicyThreatCategory(value), asBaseClass = 'as-policy-threat-slider__value-label', classes = classnames(asBaseClass, "".concat(asBaseClass, "--").concat(threatCategory), className), thumb = React.Children.only(children), thumbWithValue = React.cloneElement(thumb, { value: value });
    return React.createElement("span", __assign({ className: classes }, otherProps), thumbWithValue);
}
// MUI doesn't appear to define a specific type for these props
//eslint-disable-next-line @typescript-eslint/no-explicit-any
function Thumb(props) {
    var value = props.value, children = props.children, ownerState = props.ownerState, otherProps = __rest(props, ["value", "children", "ownerState"]);
    return (React.createElement("span", __assign({}, otherProps),
        children,
        value));
}
var AsPolicyThreatSlider = function AsPolicyThreatSlider(_a) {
    var onChange = _a.onChange, value = _a.value, className = _a.className, disabled = _a.disabled;
    var classes = classnames('as-policy-threat-slider', className);
    function sliderOnChange(_, val) {
        if (onChange) {
            onChange(val);
        }
    }
    return (React.createElement("div", { className: classes },
        React.createElement(Slider, { value: value, min: 0, max: 10, marks: true, disabled: disabled || undefined, onChange: sliderOnChange, valueLabelDisplay: "on", getAriaLabel: getAriaLabel, getAriaValueText: getAriaValueText, slots: {
                valueLabel: ValueLabel,
                thumb: Thumb
            } })));
};
AsPolicyThreatSlider.propTypes = propTypes;
export default AsPolicyThreatSlider;
//# sourceMappingURL=AsPolicyThreatSlider.js.map