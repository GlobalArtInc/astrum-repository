import * as PropTypes from 'prop-types';
import { ThreatLevelNumber, ThreatLevelCategory } from '../../util/threatLevels';
export interface Props {
    threatLevelCategory?: ThreatLevelCategory;
    policyThreatLevel?: ThreatLevelNumber;
    title?: string | null;
    className?: string | null;
    presentational?: boolean | null;
}
export declare const propTypes: PropTypes.WeakValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map