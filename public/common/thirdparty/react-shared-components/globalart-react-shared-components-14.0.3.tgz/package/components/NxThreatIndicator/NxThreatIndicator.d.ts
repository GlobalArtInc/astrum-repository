import { FunctionComponent } from 'react';
import { Props } from './types';
export { Props } from './types';
import './NxThreatIndicator.scss';
declare const NxThreatIndicator: FunctionComponent<Props>;
export default NxThreatIndicator;
//# sourceMappingURL=NxThreatIndicator.d.ts.map