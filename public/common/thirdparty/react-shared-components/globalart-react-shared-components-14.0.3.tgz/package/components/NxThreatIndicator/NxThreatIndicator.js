/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import NxTooltip from '../NxTooltip/NxTooltip';
import { categoryByPolicyThreatLevel } from '../../util/threatLevels';
import { propTypes } from './types';
import './NxThreatIndicator.scss';
import NxFontAwesomeIcon from '../NxFontAwesomeIcon/NxFontAwesomeIcon';
import { faCircle } from '@fortawesome/free-solid-svg-icons';
import classnames from 'classnames';
var capitalize = function (string) { return string.charAt(0).toUpperCase() + string.slice(1); };
var NxThreatIndicator = function NxThreatIndicator(props) {
    var title = props.title, threatLevelCategory = props.threatLevelCategory, policyThreatLevel = props.policyThreatLevel, classNameProp = props.className, presentational = props.presentational, category = threatLevelCategory ? threatLevelCategory :
        policyThreatLevel != null ? categoryByPolicyThreatLevel[policyThreatLevel] :
            'unspecified', className = classnames(classNameProp, "nx-threat-indicator nx-threat-indicator--".concat(category, " nx-icon--colorful")), label = "threat level ".concat(category);
    var icon = (React.createElement(NxFontAwesomeIcon, { "aria-label": presentational ? undefined : label, className: className, icon: faCircle, role: presentational ? 'presentation' : 'graphics-symbol img', fixedWidth: true }));
    return presentational ? icon : (React.createElement(NxTooltip, { title: title || capitalize(category) }, icon));
};
NxThreatIndicator.propTypes = propTypes;
export default NxThreatIndicator;
//# sourceMappingURL=NxThreatIndicator.js.map