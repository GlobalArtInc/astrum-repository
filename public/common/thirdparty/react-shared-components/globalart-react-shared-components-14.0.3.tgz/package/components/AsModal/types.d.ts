import { ComponentPropsWithoutRef, Ref } from 'react';
import * as PropTypes from 'prop-types';
export type CloseHandler = (evt: Event) => void;
export declare const AS_MODAL_VARIANTS: readonly ["wide", "normal", "narrow"];
export type AS_MODAL_VARIANT_TYPE = (typeof AS_MODAL_VARIANTS)[number];
interface BaseProps extends ComponentPropsWithoutRef<'div'> {
    ref?: Ref<HTMLDialogElement>;
    variant?: AS_MODAL_VARIANT_TYPE | null;
}
interface CurrentProps extends BaseProps {
    onCancel: CloseHandler;
    onClose?: never;
}
interface DeprecatedProps extends BaseProps {
    onClose: CloseHandler;
    onCancel?: never;
}
export type Props = CurrentProps | DeprecatedProps;
export declare const propTypes: PropTypes.ValidationMap<Props>;
export {};
//# sourceMappingURL=types.d.ts.map