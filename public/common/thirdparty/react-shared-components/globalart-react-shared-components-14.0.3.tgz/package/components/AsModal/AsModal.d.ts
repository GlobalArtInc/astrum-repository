import React from 'react';
import { Props } from './types';
import './AsModal.scss';
declare function AsModal(props: Props): React.JSX.Element;
declare namespace AsModal {
    var propTypes: import("prop-types").ValidationMap<Props>;
    var Header: (props: React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement>) => React.ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement>, "className">, string | React.JSXElementConstructor<any>>;
    var Content: (props: React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => React.ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | React.JSXElementConstructor<any>>;
}
export default AsModal;
export { Props } from './types';
//# sourceMappingURL=AsModal.d.ts.map