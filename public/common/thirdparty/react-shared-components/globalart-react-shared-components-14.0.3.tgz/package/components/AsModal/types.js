import * as PropTypes from 'prop-types';
export var AS_MODAL_VARIANTS = ['wide', 'normal', 'narrow'];
export var propTypes = {
    onCancel: PropTypes.func,
    onClose: PropTypes.func,
    variant: PropTypes.oneOf(AS_MODAL_VARIANTS)
};
//# sourceMappingURL=types.js.map