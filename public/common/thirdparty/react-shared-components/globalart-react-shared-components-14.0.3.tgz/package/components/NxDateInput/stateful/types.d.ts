import * as PropTypes from 'prop-types';
import { Props as NxStatefulTextInputProps } from '../../NxTextInput/stateful/types';
export type Props = Omit<NxStatefulTextInputProps, 'type'>;
export declare const propTypes: PropTypes.ValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map