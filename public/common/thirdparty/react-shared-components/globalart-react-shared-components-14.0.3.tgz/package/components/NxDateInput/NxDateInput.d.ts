import React from 'react';
import { Props } from './types';
export { Props, PublicProps, StateProps, propTypes } from './types';
declare function NxDateInput(props: Props): React.JSX.Element;
declare namespace NxDateInput {
    var propTypes: Omit<import("prop-types").ValidationMap<import("../NxTextInput/types").PublicProps>, "type">;
}
export default NxDateInput;
//# sourceMappingURL=NxDateInput.d.ts.map