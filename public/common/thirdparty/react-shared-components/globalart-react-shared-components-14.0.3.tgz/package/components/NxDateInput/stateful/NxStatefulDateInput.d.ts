import React from 'react';
import { Props } from './types';
export { Props, propTypes } from './types';
declare function NxStatefulDateInput(props: Props): React.JSX.Element;
declare namespace NxStatefulDateInput {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default NxStatefulDateInput;
//# sourceMappingURL=NxStatefulDateInput.d.ts.map