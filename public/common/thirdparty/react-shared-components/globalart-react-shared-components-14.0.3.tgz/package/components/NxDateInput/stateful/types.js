import { omit } from 'ramda';
import { propTypes as NxStatefulTextInputPropTypes } from '../../NxTextInput/stateful/types';
export var propTypes = omit(['type'], NxStatefulTextInputPropTypes);
//# sourceMappingURL=types.js.map