import { Props as NxTextInputProps, PublicProps as NxTextInputPublicProps } from '../../components/NxTextInput/NxTextInput';
export { StateProps } from '../../components/NxTextInput/NxTextInput';
export type Props = Omit<NxTextInputProps, 'type'>;
export type PublicProps = Omit<NxTextInputPublicProps, 'type'>;
export declare const propTypes: Omit<import("prop-types").ValidationMap<NxTextInputPublicProps>, "type">;
//# sourceMappingURL=types.d.ts.map