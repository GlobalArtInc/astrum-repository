/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import { omit } from 'ramda';
import { propTypes as NxTextInputPropTypes } from '../../components/NxTextInput/NxTextInput';
export var propTypes = omit(['type'], NxTextInputPropTypes);
//# sourceMappingURL=types.js.map