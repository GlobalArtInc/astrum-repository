var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import { PrivateNxTextInput } from '../../components/NxTextInput/NxTextInput';
import { propTypes } from './types';
export { propTypes } from './types';
export default function NxDateInput(props) {
    return React.createElement(PrivateNxTextInput, __assign({}, props, { type: "date" }));
}
NxDateInput.propTypes = propTypes;
//# sourceMappingURL=NxDateInput.js.map