var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { useContext } from 'react';
import classnames from 'classnames';
import { faPlusCircle, faTimesCircle } from '@fortawesome/free-solid-svg-icons';
import './NxTag.scss';
import '../../util/selectableColors.scss';
import NxFontAwesomeIcon from '../NxFontAwesomeIcon/NxFontAwesomeIcon';
import NxOverflowTooltip from '../NxTooltip/NxOverflowTooltip';
import { TooltipContext } from '../NxTooltip/NxTooltip';
import { propTypes, selectablePropTypes } from './types';
export default function NxTag(props) {
    var _a;
    var hasTooltip = useContext(TooltipContext);
    var children = props.children, className = props.className, selectedIcons = props.selectedIcons, color = props.color, title = props.title, attrs = __rest(props, ["children", "className", "selectedIcons", "color", "title"]), tagClasses = classnames('nx-tag', className, (_a = {
            'nx-selectable-color--indigo': !color
        },
        _a["nx-selectable-color--".concat(color)] = color,
        _a));
    var label = (React.createElement("label", __assign({ className: tagClasses, title: title }, attrs),
        React.createElement("span", { className: "nx-tag__text" }, children),
        selectedIcons));
    return !hasTooltip ? React.createElement(NxOverflowTooltip, null, label) : label;
}
NxTag.propTypes = propTypes;
export function NxSelectableTag(props) {
    var children = props.children, className = props.className, selected = props.selected, onSelect = props.onSelect, attrs = __rest(props, ["children", "className", "selected", "onSelect"]), isSelected = selected, tagClasses = classnames('nx-tag--selectable', className, {
        'nx-tag--selected': isSelected,
        'nx-tag--unselected': !isSelected
    }), tagIcons = React.createElement(NxFontAwesomeIcon, { icon: isSelected ? faTimesCircle : faPlusCircle, className: "nx-tag__action" });
    return (React.createElement(NxTag, __assign({ className: tagClasses, selectedIcons: tagIcons }, attrs),
        children,
        React.createElement("input", { type: "checkbox", className: "nx-tag__input", checked: isSelected, "aria-checked": isSelected, role: "switch", onChange: onSelect || undefined })));
}
NxSelectableTag.propTypes = selectablePropTypes;
//# sourceMappingURL=NxTag.js.map