import { ReactNode, ReactElement, ComponentPropsWithRef } from 'react';
import * as PropTypes from 'prop-types';
import { SelectableColor } from '../../util/selectableColors';
export interface Props extends Omit<ComponentPropsWithRef<'label'>, 'onSelect'> {
    children: ReactNode;
    tagColor?: SelectableColor | null;
    selectedIcons?: ReactElement | null;
}
export type PublicProps = Omit<Props, 'selectedIcons'>;
export interface SelectableProps extends Props {
    onSelect: (() => void);
    selected: boolean;
}
export declare const propTypes: PropTypes.ValidationMap<Props>;
export declare const selectablePropTypes: PropTypes.ValidationMap<SelectableProps>;
//# sourceMappingURL=types.d.ts.map