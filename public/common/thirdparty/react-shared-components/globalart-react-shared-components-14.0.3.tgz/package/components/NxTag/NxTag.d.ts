import React from 'react';
import './NxTag.scss';
import '../../util/selectableColors.scss';
import { Props, SelectableProps } from './types';
export { SelectableProps, PublicProps } from './types';
declare function NxTag(props: Props): React.JSX.Element;
declare namespace NxTag {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default NxTag;
export declare function NxSelectableTag(props: SelectableProps): React.JSX.Element;
export declare namespace NxSelectableTag {
    var propTypes: import("prop-types").ValidationMap<SelectableProps>;
}
//# sourceMappingURL=NxTag.d.ts.map