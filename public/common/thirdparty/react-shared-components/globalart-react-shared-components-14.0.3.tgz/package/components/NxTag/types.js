var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
import * as PropTypes from 'prop-types';
import { selectableColors } from '../../util/selectableColors';
export var propTypes = {
    children: PropTypes.node.isRequired,
    tagColor: PropTypes.oneOf(selectableColors)
};
export var selectablePropTypes = __assign(__assign({}, propTypes), { onSelect: PropTypes.func.isRequired, selected: PropTypes.bool.isRequired });
//# sourceMappingURL=types.js.map