import * as PropTypes from 'prop-types';
export var asTileHeaderTitlePropTypes = {
    children: PropTypes.node,
    className: PropTypes.string
};
//# sourceMappingURL=types.js.map