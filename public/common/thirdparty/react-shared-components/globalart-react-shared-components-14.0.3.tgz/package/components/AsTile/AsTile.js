var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import classnames from 'classnames';
import AsOverflowTooltip from '../AsTooltip/AsOverflowTooltip';
import withClass from '../../util/withClass';
import { asTileHeaderTitlePropTypes } from './types';
function AsTileHeaderTitle(props) {
    var className = props.className, children = props.children, attrs = __rest(props, ["className", "children"]);
    var classes = classnames('as-tile-header__title', className);
    return (React.createElement(AsOverflowTooltip, null,
        React.createElement("div", __assign({ className: classes }, attrs), children)));
}
AsTileHeaderTitle.propTypes = asTileHeaderTitlePropTypes;
var AsTile = Object.assign(withClass('section', 'as-tile'), {
    Header: withClass('header', 'as-tile-header'),
    Headings: withClass('hgroup', 'as-tile-header__headings'),
    HeaderTitle: AsTileHeaderTitle,
    HeaderSubtitle: withClass('h3', 'as-tile-header__subtitle'),
    HeaderActions: withClass('div', 'as-tile__actions'),
    Content: withClass('div', 'as-tile-content'),
    Subsection: withClass('section', 'as-tile-subsection'),
    SubsectionHeader: withClass('header', 'as-tile-subsection__header'),
    HeaderTags: withClass('div', 'as-tile__tags')
});
export default AsTile;
//# sourceMappingURL=AsTile.js.map