import { ComponentPropsWithRef } from 'react';
import * as PropTypes from 'prop-types';
export type AsTileHeaderTitleProps = ComponentPropsWithRef<'div'>;
export declare const asTileHeaderTitlePropTypes: PropTypes.WeakValidationMap<AsTileHeaderTitleProps>;
//# sourceMappingURL=types.d.ts.map