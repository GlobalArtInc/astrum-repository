import React from 'react';
import { Props } from './types';
export { Props } from './types';
declare function AsStatefulToggle({ defaultChecked, onChange, ...otherProps }: Props): React.JSX.Element;
declare namespace AsStatefulToggle {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default AsStatefulToggle;
//# sourceMappingURL=AsStatefulToggle.d.ts.map