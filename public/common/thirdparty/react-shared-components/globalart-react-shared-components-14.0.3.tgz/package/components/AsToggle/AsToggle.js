var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import classnames from 'classnames';
import { omit } from 'ramda';
import AsFontAwesomeIcon from '../AsFontAwesomeIcon/AsFontAwesomeIcon';
import { faCheckCircle, faTimesCircle } from '@fortawesome/free-solid-svg-icons';
import './AsToggle.scss';
import { propTypes } from './types';
export default function AsToggle(props) {
    var className = props.className, onChangeProp = props.onChange, isChecked = props.isChecked, disabled = props.disabled, inputId = props.inputId, children = props.children, _a = props.inputAttributes, inputAttributes = _a === void 0 ? {} : _a, otherProps = __rest(props, ["className", "onChange", "isChecked", "disabled", "inputId", "children", "inputAttributes"]);
    var labelClasses = classnames('as-toggle', className, {
        'as-toggle--disabled': disabled,
        'tm-checked': isChecked,
        'tm-unchecked': !isChecked
    });
    var _b = inputAttributes, checkboxClassName = _b.className, unfilteredInputAttributes = __rest(_b, ["className"]);
    var otherInputAttributes = omit(['disabled', 'checked', 'readOnly', 'onChange'], unfilteredInputAttributes);
    var toggleIndicator = React.createElement(AsFontAwesomeIcon, { icon: isChecked ? faCheckCircle : faTimesCircle, className: "as-toggle__indicator" });
    var onChange = onChangeProp ? function () { onChangeProp(!isChecked); } : undefined;
    return (React.createElement("label", __assign({}, otherProps, { className: labelClasses }),
        React.createElement("input", __assign({ type: "checkbox", id: otherInputAttributes.id || inputId || undefined, className: classnames('as-toggle__input', checkboxClassName), disabled: !!disabled, checked: isChecked, readOnly: !onChange, onChange: onChange, role: "switch", "aria-checked": isChecked }, otherInputAttributes)),
        React.createElement("div", { className: "as-toggle__control" }, toggleIndicator),
        children && React.createElement("span", { className: "as-toggle__content" }, children)));
}
AsToggle.propTypes = propTypes;
//# sourceMappingURL=AsToggle.js.map