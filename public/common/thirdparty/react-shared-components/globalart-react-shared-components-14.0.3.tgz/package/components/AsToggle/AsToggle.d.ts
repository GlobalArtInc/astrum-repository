import React from 'react';
import './AsToggle.scss';
import { Props } from './types';
export { Props } from './types';
declare function AsToggle(props: Props): React.JSX.Element;
declare namespace AsToggle {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default AsToggle;
//# sourceMappingURL=AsToggle.d.ts.map