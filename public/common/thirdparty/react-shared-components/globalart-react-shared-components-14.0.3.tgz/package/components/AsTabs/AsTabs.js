var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { Children, cloneElement, isValidElement } from 'react';
import classnames from 'classnames';
import { useUniqueId } from '../../util/idUtil';
import TabContext from './TabContext';
import { asTabsPropTypes } from './types';
import './AsTabs.scss';
var AsTabs = function AsTabsElement(props) {
    var activeTab = props.activeTab, onTabSelect = props.onTabSelect, id = props.id, className = props.className, children = props.children, attrs = __rest(props, ["activeTab", "onTabSelect", "id", "className", "children"]);
    var _a = Children.toArray(children), tabList = _a[0], tabPanels = _a.slice(1);
    if (!isValidElement(tabList)) {
        console.error('AsTabs must have an AsTabList');
        return null;
    }
    else if (Children.toArray(tabList.props.children).length === 0) {
        console.error('AsTabs must have at least one AsTab');
        return null;
    }
    var rootId = useUniqueId('as-tabs', id);
    var clonedTabList = cloneElement(tabList, {
        children: Children.toArray(tabList.props.children).map(function (tab, index) {
            var activeTabContext = {
                activeTab: activeTab,
                rootId: rootId,
                index: index,
                onTabSelect: onTabSelect
            };
            return React.createElement(TabContext.Provider, { key: index, value: activeTabContext }, tab);
        })
    });
    var clonedTabPanels = tabPanels.map(function (tabPanel, index) {
        var activeTabContext = {
            activeTab: activeTab,
            rootId: rootId,
            index: index,
            onTabSelect: onTabSelect
        };
        return React.createElement(TabContext.Provider, { key: index, value: activeTabContext }, tabPanel);
    });
    return (React.createElement("div", __assign({ id: rootId, className: classnames('as-tabs', className) }, attrs),
        clonedTabList,
        clonedTabPanels));
};
AsTabs.propTypes = asTabsPropTypes;
export default AsTabs;
//# sourceMappingURL=AsTabs.js.map