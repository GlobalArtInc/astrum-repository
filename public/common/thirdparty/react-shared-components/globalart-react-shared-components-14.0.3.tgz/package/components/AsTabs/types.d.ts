import { ComponentPropsWithRef, PropsWithChildren, ReactElement } from 'react';
import PropTypes from 'prop-types';
export interface TabContextType {
    activeTab?: number | null;
    rootId: string;
    index: number;
    onTabSelect: (index: number) => void;
}
export type AsTabsProps = ComponentPropsWithRef<'div'> & {
    activeTab?: number | null;
    onTabSelect: ((index: number) => void);
    children?: ReactElement<PropsWithChildren> | ReactElement<PropsWithChildren>[] | null;
};
export type AsTabListProps = ComponentPropsWithRef<'ul'>;
export type AsTabPanelProps = ComponentPropsWithRef<'div'>;
export type AsTabProps = ComponentPropsWithRef<'li'> & {
    index?: number | null;
};
export declare const asTabsPropTypes: PropTypes.ValidationMap<AsTabsProps>;
export declare const asTabPropTypes: PropTypes.ValidationMap<AsTabProps>;
export declare const asTabListPropTypes: PropTypes.ValidationMap<AsTabListProps>;
export declare const asTabPanelPropTypes: PropTypes.ValidationMap<AsTabPanelProps>;
//# sourceMappingURL=types.d.ts.map