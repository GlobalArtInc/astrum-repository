var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { useState } from 'react';
import AsTabs from '../AsTabs';
import { propTypes } from './types';
/**
 * A stateful component for rendering clickable tabs.
 * Clicking on a AsTabLabel will show the associated Tab (determined by using an index number for each).
 * This assumes the following:
 * * The first child must be a AsTabList component.
 * * There is at least one AsTabPanel component for each AsTab in the AsTabList component.
 * * The AsTabPanel must have a labelledBy prop that matches the id of an AsTab.
 */
var AsStatefulTabs = function AsStatefulTabsElement(props) {
    var defaultActiveTab = props.defaultActiveTab, children = props.children, onTabSelect = props.onTabSelect, attrs = __rest(props, ["defaultActiveTab", "children", "onTabSelect"]);
    var _a = useState(defaultActiveTab), activeTab = _a[0], setActiveTab = _a[1];
    function handleTabSelect(index) {
        if (onTabSelect) {
            onTabSelect(index);
        }
        setActiveTab(index);
    }
    return (React.createElement(AsTabs, __assign({ activeTab: activeTab, onTabSelect: handleTabSelect }, attrs), children));
};
AsStatefulTabs.propTypes = propTypes;
export default AsStatefulTabs;
//# sourceMappingURL=AsStatefulTabs.js.map