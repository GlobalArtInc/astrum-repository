import React from 'react';
import { AsTabListProps } from './types';
export { AsTabListProps };
declare const AsTabList: {
    (props: AsTabListProps): React.JSX.Element;
    propTypes: import("prop-types").ValidationMap<React.DetailedHTMLProps<React.HTMLAttributes<HTMLUListElement>, HTMLUListElement>>;
};
export default AsTabList;
//# sourceMappingURL=AsTabList.d.ts.map