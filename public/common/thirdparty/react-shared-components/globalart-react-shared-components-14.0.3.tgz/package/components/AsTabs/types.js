import PropTypes from 'prop-types';
export var asTabsPropTypes = {
    activeTab: PropTypes.number,
    onTabSelect: PropTypes.func.isRequired,
    children: PropTypes.oneOfType([
        PropTypes.element,
        PropTypes.arrayOf(PropTypes.element.isRequired)
    ])
};
export var asTabPropTypes = {
    index: PropTypes.number,
    children: PropTypes.node
};
export var asTabListPropTypes = {
    children: PropTypes.node
};
export var asTabPanelPropTypes = {
    className: PropTypes.string
};
//# sourceMappingURL=types.js.map