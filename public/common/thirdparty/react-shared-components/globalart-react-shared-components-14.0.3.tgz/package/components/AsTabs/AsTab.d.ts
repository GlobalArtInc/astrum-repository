import React from 'react';
import { AsTabProps } from './types';
export { AsTabProps };
declare const AsTab: {
    (props: AsTabProps): React.JSX.Element;
    propTypes: import("prop-types").ValidationMap<AsTabProps>;
};
export default AsTab;
//# sourceMappingURL=AsTab.d.ts.map