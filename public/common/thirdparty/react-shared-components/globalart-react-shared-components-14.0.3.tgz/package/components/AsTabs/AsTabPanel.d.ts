import React from 'react';
import { AsTabPanelProps } from './types';
export { AsTabPanelProps };
declare const AsTabPanel: {
    (props: AsTabPanelProps): React.JSX.Element | null;
    propTypes: import("prop-types").ValidationMap<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>>;
};
export default AsTabPanel;
//# sourceMappingURL=AsTabPanel.d.ts.map