import React from 'react';
import { Props } from './types';
/**
 * A stateful component for rendering clickable tabs.
 * Clicking on a AsTabLabel will show the associated Tab (determined by using an index number for each).
 * This assumes the following:
 * * The first child must be a AsTabList component.
 * * There is at least one AsTabPanel component for each AsTab in the AsTabList component.
 * * The AsTabPanel must have a labelledBy prop that matches the id of an AsTab.
 */
declare const AsStatefulTabs: {
    (props: Props): React.JSX.Element;
    propTypes: import("prop-types").ValidationMap<Props>;
};
export default AsStatefulTabs;
//# sourceMappingURL=AsStatefulTabs.d.ts.map