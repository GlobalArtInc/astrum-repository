import React from 'react';
import { AsTabsProps } from './types';
export { AsTabsProps } from './types';
import './AsTabs.scss';
declare const AsTabs: {
    (props: AsTabsProps): React.JSX.Element | null;
    propTypes: import("prop-types").ValidationMap<AsTabsProps>;
};
export default AsTabs;
//# sourceMappingURL=AsTabs.d.ts.map