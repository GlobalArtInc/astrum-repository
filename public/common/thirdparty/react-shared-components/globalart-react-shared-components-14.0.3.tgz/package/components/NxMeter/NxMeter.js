var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import { propTypes } from './types';
import './NxMeter.scss';
import classnames from 'classnames';
import NxTooltip from '../NxTooltip/NxTooltip';
export default function NxMeter(props) {
    var classNameProp = props.className, maxProp = props.max, children = props.children, otherAttributes = __rest(props, ["className", "max", "children"]), className = classnames('nx-meter', classNameProp), max = maxProp !== null && maxProp !== void 0 ? maxProp : 100;
    return (React.createElement(NxTooltip, { title: children },
        React.createElement("meter", __assign({ className: className, max: max }, otherAttributes),
            React.createElement("span", { className: "nx-meter__content" }, children))));
}
NxMeter.propTypes = propTypes;
//# sourceMappingURL=NxMeter.js.map