import * as PropTypes from 'prop-types';
import { ComponentPropsWithRef, ReactNode } from 'react';
export interface Props extends Omit<ComponentPropsWithRef<'meter'>, 'max' | 'min' | 'low' | 'high' | 'optimum'> {
    max?: number | null;
    value: number;
    children: Exclude<ReactNode, null | undefined>;
}
export declare const propTypes: PropTypes.ValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map