import React from 'react';
import { Props } from './types';
import './NxMeter.scss';
export { Props };
declare function NxMeter(props: Props): React.JSX.Element;
declare namespace NxMeter {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default NxMeter;
//# sourceMappingURL=NxMeter.d.ts.map