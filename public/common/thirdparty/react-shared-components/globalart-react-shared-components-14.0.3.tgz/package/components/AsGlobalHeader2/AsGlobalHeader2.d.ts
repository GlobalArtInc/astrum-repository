import React from 'react';
import { Props } from './types';
import './AsGlobalHeader2.scss';
declare function AsGlobalHeader2({ logoProps, homeHref, className, children, ...otherProps }: Props): React.JSX.Element;
declare namespace AsGlobalHeader2 {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default AsGlobalHeader2;
export { Props, propTypes } from './types';
//# sourceMappingURL=AsGlobalHeader2.d.ts.map