import React from 'react';
import { FontAwesomeIconProps as Props } from '@fortawesome/react-fontawesome';
export { Props } from '@fortawesome/react-fontawesome';
/**
 * A wrapper component around FontAwesomeIcon that adds our as-icon css class. Takes the same props as FontAwesomeIcon
 */
export default function AsFontAwesomeIcon(props: Props): React.JSX.Element;
//# sourceMappingURL=AsFontAwesomeIcon.d.ts.map