/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import { faCircleNotch } from '@fortawesome/free-solid-svg-icons';
import { propTypes } from './types';
export { propTypes } from './types';
import AsFontAwesomeIcon from '../AsFontAwesomeIcon/AsFontAwesomeIcon';
import './AsLoadingSpinner.scss';
var AsLoadingSpinner = function AsLoadingSpinner(_a) {
    var children = _a.children, ariaLabel = _a["aria-label"];
    return (React.createElement("div", { role: "status", className: "as-loading-spinner", "aria-label": ariaLabel },
        React.createElement(AsFontAwesomeIcon, { icon: faCircleNotch, className: "fa-spin as-loading-spinner__icon" }),
        React.createElement("span", null, children || 'Loading…')));
};
AsLoadingSpinner.propTypes = propTypes;
export default AsLoadingSpinner;
//# sourceMappingURL=AsLoadingSpinner.js.map