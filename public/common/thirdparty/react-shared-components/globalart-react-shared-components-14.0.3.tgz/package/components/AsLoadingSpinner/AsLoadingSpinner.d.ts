import { FunctionComponent } from 'react';
import { Props } from './types';
export { Props, propTypes } from './types';
import './AsLoadingSpinner.scss';
declare const AsLoadingSpinner: FunctionComponent<Props>;
export default AsLoadingSpinner;
//# sourceMappingURL=AsLoadingSpinner.d.ts.map