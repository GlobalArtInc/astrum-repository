var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import classnames from 'classnames';
import { faAngleRight } from '@fortawesome/free-solid-svg-icons';
import { includesDisabledClass } from '../../util/classUtil';
import NxFontAwesomeIcon from '../NxFontAwesomeIcon/NxFontAwesomeIcon';
import { nxListButtonItemPropTypes } from './types';
export default function NxListButtonItem(props) {
    var children = props.children, className = props.className, disabled = props.disabled, selectedProp = props.selected, buttonClassName = props.buttonClassName, buttonAttributes = props.buttonAttributes, attrs = __rest(props, ["children", "className", "disabled", "selected", "buttonClassName", "buttonAttributes"]), selected = selectedProp !== null && selectedProp !== void 0 ? selectedProp : undefined, liClassNames = classnames('nx-list__item', 'nx-list__item--clickable', className), buttonClassNames = classnames('nx-list__btn', buttonClassName, { selected: selected, disabled: disabled });
    return (
    // aria-current is the valid one here by the standards, but aria-selected is the one that actually
    // tends to work in real-world screenreaders
    React.createElement("li", __assign({ className: liClassNames }, attrs, { "aria-selected": selected, "aria-current": selected }),
        React.createElement("button", __assign({ "aria-disabled": includesDisabledClass(buttonClassNames), className: buttonClassNames, disabled: disabled ? true : false }, buttonAttributes),
            children,
            React.createElement(NxFontAwesomeIcon, { icon: faAngleRight, className: "nx-chevron" }))));
}
NxListButtonItem.propTypes = nxListButtonItemPropTypes;
//# sourceMappingURL=NxListButtonItem.js.map