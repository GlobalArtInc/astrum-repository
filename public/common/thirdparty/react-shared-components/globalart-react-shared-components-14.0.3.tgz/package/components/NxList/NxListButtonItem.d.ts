import React from 'react';
import { NxListButtonItemProps } from './types';
declare function NxListButtonItem(props: NxListButtonItemProps): React.JSX.Element;
declare namespace NxListButtonItem {
    var propTypes: import("prop-types").ValidationMap<NxListButtonItemProps>;
}
export default NxListButtonItem;
//# sourceMappingURL=NxListButtonItem.d.ts.map