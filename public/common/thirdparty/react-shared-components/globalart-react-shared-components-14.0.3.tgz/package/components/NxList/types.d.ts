import { ReactNode, ComponentPropsWithRef, ComponentPropsWithoutRef } from 'react';
import { ValidationMap } from 'prop-types';
export interface NxListProps extends ComponentPropsWithRef<'ul'> {
    bulleted?: boolean | null;
    emptyMessage?: ReactNode;
    error?: string | null;
    isLoading?: boolean | null;
    retryHandler?: (() => void) | null;
}
export declare const nxListPropTypes: ValidationMap<NxListProps>;
export interface NxListButtonItemProps extends ComponentPropsWithRef<'li'> {
    selected?: boolean | null;
    disabled?: boolean | null;
    buttonClassName?: string | null;
    buttonAttributes?: ComponentPropsWithoutRef<'button'> | null;
}
export declare const nxListButtonItemPropTypes: ValidationMap<NxListButtonItemProps>;
export interface NxListLinkItemProps extends ComponentPropsWithRef<'li'> {
    disabled?: boolean | null;
    selected?: boolean | null;
    href: string;
    anchorClassName?: string | null;
    anchorAttributes?: ComponentPropsWithoutRef<'a'> | null;
}
export declare const nxListLinkItemPropTypes: ValidationMap<NxListLinkItemProps>;
//# sourceMappingURL=types.d.ts.map