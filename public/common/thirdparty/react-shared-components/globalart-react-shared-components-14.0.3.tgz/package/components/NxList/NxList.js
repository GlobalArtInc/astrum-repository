var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { useRef } from 'react';
import classnames from 'classnames';
import useMergedRef from '@react-hook/merged-ref';
import withClass from '../../util/withClass';
import NxLoadingSpinner from '../NxLoadingSpinner/NxLoadingSpinner';
import NxLoadError from '../NxLoadError/NxLoadError';
import NxDescriptionList from '../NxDescriptionList/NxDescriptionList';
import NxListButtonItem from './NxListButtonItem';
import NxListLinkItem from './NxListLinkItem';
import { nxListPropTypes } from './types';
import useEmptyComponent from '../../util/useEmptyComponent';
import { ensureRef } from '../../util/reactUtil';
export default function NxList(props) {
    var externalRef = props.ref, className = props.className, children = props.children, bulleted = props.bulleted, emptyMessage = props.emptyMessage, _a = props.isLoading, isLoading = _a === void 0 ? false : _a, error = props.error, retryHandler = props.retryHandler, attrs = __rest(props, ["ref", "className", "children", "bulleted", "emptyMessage", "isLoading", "error", "retryHandler"]);
    var classNames = classnames(className, 'nx-list', { 'nx-list--bulleted': bulleted });
    var ulRef = useRef(null);
    var emptyListRef = useRef(null);
    var ref = useMergedRef(ulRef, ensureRef(externalRef));
    var isEmpty = useEmptyComponent(ulRef, emptyListRef);
    if (isEmpty && !isLoading && !error) {
        if (!emptyMessage) {
            console.warn('emptyMessage is required when no list items are to be rendered');
        }
    }
    var nxListEmpty = (React.createElement("li", { ref: emptyListRef, className: "nx-list__item nx-list__item--empty" },
        React.createElement("span", { className: "nx-list__text" }, emptyMessage || 'This list is empty.')));
    var nxListLoading = (React.createElement("li", { className: "nx-list__item" },
        React.createElement(NxLoadingSpinner, null)));
    var nxListError = (React.createElement("li", { className: "nx-list__item nx-list__item--error" },
        React.createElement(NxLoadError, { error: error, retryHandler: retryHandler })));
    return (React.createElement("ul", __assign({ ref: ref, className: classNames }, attrs),
        isLoading && nxListLoading,
        !!error && !isLoading && nxListError,
        !isLoading && !error && children,
        !(isLoading || error) && isEmpty && nxListEmpty));
}
NxList.propTypes = nxListPropTypes;
NxList.Item = withClass('li', 'nx-list__item');
NxList.Text = withClass('span', 'nx-list__text');
NxList.Subtext = withClass('span', 'nx-list__subtext');
NxList.Actions = withClass('div', 'nx-list__actions');
NxList.ButtonItem = NxListButtonItem;
NxList.LinkItem = NxListLinkItem;
// deprecated aliases
NxList.Description = NxDescriptionList.Description;
NxList.DescriptionTerm = NxDescriptionList.Term;
export { nxListPropTypes } from './types';
//# sourceMappingURL=NxList.js.map