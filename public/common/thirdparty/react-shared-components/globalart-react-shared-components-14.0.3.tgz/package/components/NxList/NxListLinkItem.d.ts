import React from 'react';
import { NxListLinkItemProps } from './types';
declare function NxListLinkItem(props: NxListLinkItemProps): React.JSX.Element;
declare namespace NxListLinkItem {
    var propTypes: import("prop-types").ValidationMap<NxListLinkItemProps>;
}
export default NxListLinkItem;
//# sourceMappingURL=NxListLinkItem.d.ts.map