import React from 'react';
import { Props } from './types';
export { Props };
import './AsFieldset.scss';
declare function AsFieldset(props: Props): React.JSX.Element;
declare namespace AsFieldset {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default AsFieldset;
//# sourceMappingURL=AsFieldset.d.ts.map