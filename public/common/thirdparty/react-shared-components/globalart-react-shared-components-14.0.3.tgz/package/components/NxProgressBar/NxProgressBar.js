var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import { faExclamationCircle, faCheckCircle } from '@fortawesome/free-solid-svg-icons';
import classnames from 'classnames';
import { map, range } from 'ramda';
import NxFontAwesomeIcon from '../NxFontAwesomeIcon/NxFontAwesomeIcon';
import { propTypes } from './types';
import './NxProgressBar.scss';
function Steps(_a) {
    var max = _a.max, value = _a.value;
    var indexes = range(1, max), mkStepClasses = function (idx) { return classnames('nx-progress-bar__step', {
        'nx-progress-bar__step--below-value': idx < value,
        'nx-progress-bar__step--at-value': idx === value,
        'nx-progress-bar__step--above-value': idx > value
    }); }, mkStep = function (idx) { return React.createElement("span", { key: idx, className: mkStepClasses(idx) }); }, steps = map(mkStep, indexes);
    return (React.createElement("div", { role: "presentation", className: "nx-progress-bar__step-container" }, steps));
}
export default function NxProgressBar(props) {
    var className = props.className, inlineCounter = props.inlineCounter, label = props.label, labelError = props.labelError, labelSuccess = props.labelSuccess, maxProp = props.max, showCounterProp = props.showCounter, showStepsProp = props.showSteps, value = props.value, variantProp = props.variant, otherAttributes = __rest(props, ["className", "inlineCounter", "label", "labelError", "labelSuccess", "max", "showCounter", "showSteps", "value", "variant"]);
    var variant = variantProp !== null && variantProp !== void 0 ? variantProp : 'normal';
    var showCounter = showCounterProp !== null && showCounterProp !== void 0 ? showCounterProp : true;
    var showSteps = !!showStepsProp;
    var showLabelElement = !(variant === 'inline' || variant === 'small' || inlineCounter);
    var max = maxProp !== null && maxProp !== void 0 ? maxProp : 100;
    var percentage = Math.round(value / max * 100);
    var labelText = labelError || ((percentage === 100 && labelSuccess) ? labelSuccess : label);
    var counterElement = showCounter
        ? React.createElement("span", { className: "nx-counter nx-progress-bar__counter" }, "".concat(labelError ? 0 : percentage, "%"))
        : null;
    var labelElement = showLabelElement ? (React.createElement(React.Fragment, null,
        labelError && React.createElement(NxFontAwesomeIcon, { icon: faExclamationCircle }),
        percentage === 100 && React.createElement(NxFontAwesomeIcon, { icon: faCheckCircle }),
        React.createElement("span", { className: "nx-progress-bar__label-text" }, labelText))) : null;
    var classes = classnames('nx-progress-bar', "nx-progress-bar--".concat(variant), {
        'nx-progress-bar--inline-counter': inlineCounter,
        'nx-progress-bar--error': labelError,
        'nx-progress-bar--success': percentage === 100
    }, className);
    return (React.createElement("label", { className: classes },
        React.createElement("progress", __assign({ "aria-label": !showLabelElement ? labelText : undefined, className: "nx-progress-bar__progress", value: labelError ? 0 : value, max: max }, otherAttributes)),
        showSteps && React.createElement(Steps, { max: max, value: labelError ? 0 : value }),
        variant !== 'inline' && (React.createElement("span", { className: "nx-progress-bar__counter-and-label" },
            !showSteps && counterElement,
            labelElement))));
}
NxProgressBar.propTypes = propTypes;
//# sourceMappingURL=NxProgressBar.js.map