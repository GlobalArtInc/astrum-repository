/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import * as PropTypes from 'prop-types';
export var NX_PROGRESS_BAR_VARIANTS = ['inline', 'small', 'normal', 'full'];
export var propTypes = {
    inlineCounter: PropTypes.bool,
    label: PropTypes.string.isRequired,
    labelError: PropTypes.string,
    labelSuccess: PropTypes.string,
    max: PropTypes.number,
    showCounter: PropTypes.bool,
    value: PropTypes.number.isRequired,
    variant: PropTypes.oneOf(NX_PROGRESS_BAR_VARIANTS)
};
//# sourceMappingURL=types.js.map