import React from 'react';
import { Props } from './types';
import './NxProgressBar.scss';
declare function NxProgressBar(props: Props): React.JSX.Element;
declare namespace NxProgressBar {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default NxProgressBar;
export { Props } from './types';
//# sourceMappingURL=NxProgressBar.d.ts.map