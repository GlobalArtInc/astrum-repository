var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { useContext } from 'react';
import classnames from 'classnames';
import { faPlusCircle, faTimesCircle } from '@fortawesome/free-solid-svg-icons';
import './AsTag.scss';
import '../../util/selectableColors.scss';
import AsFontAwesomeIcon from '../AsFontAwesomeIcon/AsFontAwesomeIcon';
import AsOverflowTooltip from '../AsTooltip/AsOverflowTooltip';
import { TooltipContext } from '../AsTooltip/AsTooltip';
import { propTypes, selectablePropTypes } from './types';
export default function AsTag(props) {
    var _a;
    var hasTooltip = useContext(TooltipContext);
    var children = props.children, className = props.className, selectedIcons = props.selectedIcons, color = props.color, title = props.title, attrs = __rest(props, ["children", "className", "selectedIcons", "color", "title"]), tagClasses = classnames('as-tag', className, (_a = {
            'as-selectable-color--indigo': !color
        },
        _a["as-selectable-color--".concat(color)] = color,
        _a));
    var label = (React.createElement("label", __assign({ className: tagClasses, title: title }, attrs),
        React.createElement("span", { className: "as-tag__text" }, children),
        selectedIcons));
    return !hasTooltip ? React.createElement(AsOverflowTooltip, null, label) : label;
}
AsTag.propTypes = propTypes;
export function AsSelectableTag(props) {
    var children = props.children, className = props.className, selected = props.selected, onSelect = props.onSelect, attrs = __rest(props, ["children", "className", "selected", "onSelect"]), isSelected = selected, tagClasses = classnames('as-tag--selectable', className, {
        'as-tag--selected': isSelected,
        'as-tag--unselected': !isSelected
    }), tagIcons = React.createElement(AsFontAwesomeIcon, { icon: isSelected ? faTimesCircle : faPlusCircle, className: "as-tag__action" });
    return (React.createElement(AsTag, __assign({ className: tagClasses, selectedIcons: tagIcons }, attrs),
        children,
        React.createElement("input", { type: "checkbox", className: "as-tag__input", checked: isSelected, "aria-checked": isSelected, role: "switch", onChange: onSelect || undefined })));
}
AsSelectableTag.propTypes = selectablePropTypes;
//# sourceMappingURL=AsTag.js.map