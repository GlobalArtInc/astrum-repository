import React from 'react';
import './AsTag.scss';
import '../../util/selectableColors.scss';
import { Props, SelectableProps } from './types';
export { SelectableProps, PublicProps } from './types';
declare function AsTag(props: Props): React.JSX.Element;
declare namespace AsTag {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default AsTag;
export declare function AsSelectableTag(props: SelectableProps): React.JSX.Element;
export declare namespace AsSelectableTag {
    var propTypes: import("prop-types").ValidationMap<SelectableProps>;
}
//# sourceMappingURL=AsTag.d.ts.map