import React from 'react';
import { ItemLabelProps } from './types';
export default function NxTreeItemLabel(props: ItemLabelProps): React.JSX.Element;
//# sourceMappingURL=NxTreeItemLabel.d.ts.map