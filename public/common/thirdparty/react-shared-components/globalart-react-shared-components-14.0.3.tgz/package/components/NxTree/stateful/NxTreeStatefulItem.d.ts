import React from 'react';
import { StatefulItemProps } from '../types';
export { StatefulItemProps };
declare function NxTreeStatefulItem({ defaultOpen, ...otherProps }: StatefulItemProps): React.JSX.Element;
declare namespace NxTreeStatefulItem {
    var propTypes: import("prop-types").ValidationMap<StatefulItemProps>;
}
export default NxTreeStatefulItem;
//# sourceMappingURL=NxTreeStatefulItem.d.ts.map