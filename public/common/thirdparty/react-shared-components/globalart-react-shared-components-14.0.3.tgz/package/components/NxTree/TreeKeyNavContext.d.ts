import { TreeKeyNavContextType } from './types';
declare const TreeKeyNavContext: import("react").Context<TreeKeyNavContextType>;
export default TreeKeyNavContext;
//# sourceMappingURL=TreeKeyNavContext.d.ts.map