var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { useContext, useRef, useEffect, useState } from 'react';
import classnames from 'classnames';
import NxTreeItem from './NxTreeItem';
import NxTreeItemLabel from './NxTreeItemLabel';
import TreeKeyNavContext from './TreeKeyNavContext';
import NxTreeStatefulItem from './stateful/NxTreeStatefulItem';
import './NxTree.scss';
export default function NxTree(props) {
    var className = props.className, onFocusProp = props.onFocus, otherProps = __rest(props, ["className", "onFocus"]), parentKeyNavContext = useContext(TreeKeyNavContext), ref = useRef(null), 
    // The child tree item which is focusable, if any. Only one item in the tree is focusable at a time
    _a = useState(null), focusedChild = _a[0], setFocusedChild = _a[1], 
    // Whether keynav is currently moving upwards or down. Determines whether entering a subtree
    // should focus its top element or its last visible descendant
    // NOTE: only the state stored in the top-level tree is used, subtrees ignore their version of
    // this state and delegate to the root tree
    _b = useState('down'), navigationDirection = _b[0], setNavigationDirection = _b[1], childKeyNavContext = {
        setNavigationDirection: (parentKeyNavContext === null || parentKeyNavContext === void 0 ? void 0 : parentKeyNavContext.setNavigationDirection) || setNavigationDirection,
        navigationDirection: (parentKeyNavContext === null || parentKeyNavContext === void 0 ? void 0 : parentKeyNavContext.navigationDirection) || navigationDirection,
        focusedChild: focusedChild,
        focusNext: function () {
            if (focusedChild) {
                if (focusedChild.nextElementSibling) {
                    setFocusedChild(focusedChild.nextElementSibling);
                }
                else if (parentKeyNavContext) {
                    parentKeyNavContext.focusNext();
                }
            }
        },
        focusPrev: function () {
            if (focusedChild) {
                if (focusedChild.previousElementSibling) {
                    setFocusedChild(focusedChild.previousElementSibling);
                }
                else if (parentKeyNavContext) {
                    parentKeyNavContext.focusPrev();
                }
            }
        },
        // delegate to parent item if any
        focusParent: (parentKeyNavContext === null || parentKeyNavContext === void 0 ? void 0 : parentKeyNavContext.focusParent) || (function () { }),
        // subtrees delegate to root
        focusFirst: (parentKeyNavContext === null || parentKeyNavContext === void 0 ? void 0 : parentKeyNavContext.focusFirst) || function () {
            var _a;
            setNavigationDirection('down');
            setFocusedChild(((_a = ref.current) === null || _a === void 0 ? void 0 : _a.firstElementChild) || null);
        },
        focusLast: (parentKeyNavContext === null || parentKeyNavContext === void 0 ? void 0 : parentKeyNavContext.focusLast) || function () {
            setNavigationDirection('up');
            setFocusedChild(null);
            // focus the last element - but only after first unfocusing everything in order to trigger the
            // last element to update its child focus based on the navigation direction, in case the last element
            // was already the focused one
            setTimeout(function () { var _a; setFocusedChild(((_a = ref.current) === null || _a === void 0 ? void 0 : _a.lastElementChild) || null); }, 0);
        },
        getTreeRoot: parentKeyNavContext ? parentKeyNavContext.getTreeRoot : function () { return ref.current; }
    }, classes = classnames('nx-tree', className);
    useEffect(function () {
        var _a, _b;
        // We want to focus either the first or last child of this tree in two scenarios:
        // 1. this is the top tree
        // 2. this is a subtree which is currently designated (via `focusedChild`) as containing the focus
        if (!parentKeyNavContext ||
            ((parentKeyNavContext === null || parentKeyNavContext === void 0 ? void 0 : parentKeyNavContext.focusedChild) && (parentKeyNavContext === null || parentKeyNavContext === void 0 ? void 0 : parentKeyNavContext.focusedChild) === ref.current)) {
            if (!focusedChild) {
                var childToFocus = (parentKeyNavContext === null || parentKeyNavContext === void 0 ? void 0 : parentKeyNavContext.navigationDirection) === 'up' ?
                    (_a = ref.current) === null || _a === void 0 ? void 0 : _a.lastElementChild :
                    (_b = ref.current) === null || _b === void 0 ? void 0 : _b.firstElementChild;
                setFocusedChild(childToFocus || null);
            }
        }
        else {
            setFocusedChild(null);
        }
    }, [!!parentKeyNavContext, parentKeyNavContext === null || parentKeyNavContext === void 0 ? void 0 : parentKeyNavContext.focusedChild]);
    function onFocus(evt) {
        if (onFocusProp) {
            onFocusProp(evt);
        }
        // determine which immediate child contained the focused node, and set focusedChild to that node
        var el = evt.target, elsParent = el.parentElement;
        while (elsParent) {
            if (elsParent === ref.current) {
                setFocusedChild(el);
                break;
            }
            el = elsParent;
            elsParent = el.parentElement;
        }
    }
    return (React.createElement(TreeKeyNavContext.Provider, { value: childKeyNavContext },
        React.createElement("ul", __assign({ ref: ref, className: classes, role: parentKeyNavContext ? 'group' : 'tree', onFocus: onFocus }, otherProps))));
}
NxTree.Item = NxTreeItem;
NxTree.StatefulItem = NxTreeStatefulItem;
NxTree.ItemLabel = NxTreeItemLabel;
//# sourceMappingURL=NxTree.js.map