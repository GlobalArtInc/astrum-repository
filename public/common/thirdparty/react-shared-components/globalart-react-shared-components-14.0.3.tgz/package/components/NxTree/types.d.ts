import * as PropTypes from 'prop-types';
import { ComponentPropsWithRef } from 'react';
export type NavigationDirection = 'up' | 'down';
export type TreeKeyNavContextType = {
    focusNext: () => void;
    focusPrev: () => void;
    focusParent: () => void;
    focusFirst: () => void;
    focusLast: () => void;
    focusedChild: Element | null;
    navigationDirection: NavigationDirection;
    setNavigationDirection: (dir: NavigationDirection) => void;
    getTreeRoot: () => (Element | null);
} | null;
export type TreeItemFocusState = 'self' | 'children' | null;
interface NonCollapsibleItemProps {
    collapsible?: false | null;
}
interface CollapsibleItemProps {
    collapsible: true;
    isOpen: boolean;
    onToggleCollapse: (() => void);
}
export type ItemProps = ComponentPropsWithRef<'li'> & (NonCollapsibleItemProps | CollapsibleItemProps) & {
    onActivate?: () => void;
};
export type ItemLabelProps = ComponentPropsWithRef<'span'>;
export interface StatefulItemProps extends ComponentPropsWithRef<'li'> {
    collapsible?: boolean | null;
    defaultOpen?: boolean | null;
}
export declare const itemPropTypes: {
    collapsible: PropTypes.Requireable<boolean>;
    isOpen: PropTypes.Requireable<boolean>;
    onToggleCollapse: PropTypes.Requireable<(...args: any[]) => any>;
};
export declare const statefulItemPropTypes: PropTypes.ValidationMap<StatefulItemProps>;
export {};
//# sourceMappingURL=types.d.ts.map