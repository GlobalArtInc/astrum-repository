import React from 'react';
import { ItemProps } from './types';
declare function NxTreeItem(props: ItemProps): React.JSX.Element;
declare namespace NxTreeItem {
    var propTypes: {
        collapsible: import("prop-types").Requireable<boolean>;
        isOpen: import("prop-types").Requireable<boolean>;
        onToggleCollapse: import("prop-types").Requireable<(...args: any[]) => any>;
    };
}
export default NxTreeItem;
//# sourceMappingURL=NxTreeItem.d.ts.map