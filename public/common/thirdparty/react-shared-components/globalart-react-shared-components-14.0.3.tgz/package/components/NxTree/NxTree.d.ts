import React, { ComponentPropsWithRef } from 'react';
import { ItemProps } from './types';
import NxTreeItem from './NxTreeItem';
import NxTreeItemLabel from './NxTreeItemLabel';
import NxTreeStatefulItem from './stateful/NxTreeStatefulItem';
export { ItemProps };
import './NxTree.scss';
declare function NxTree(props: ComponentPropsWithRef<'ul'>): React.JSX.Element;
declare namespace NxTree {
    var Item: typeof NxTreeItem;
    var StatefulItem: typeof NxTreeStatefulItem;
    var ItemLabel: typeof NxTreeItemLabel;
}
export default NxTree;
//# sourceMappingURL=NxTree.d.ts.map