import { ComponentPropsWithRef } from 'react';
import * as PropTypes from 'prop-types';
export interface Props extends Omit<ComponentPropsWithRef<'dl'>, 'className' | 'children'> {
    criticalCount?: number | null;
    severeCount?: number | null;
    moderateCount?: number | null;
    lowCount?: number | null;
    noneCount?: number | null;
    unspecifiedCount?: number | null;
    layout?: string | null;
    className?: string | null;
}
export declare const propTypes: PropTypes.ValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map