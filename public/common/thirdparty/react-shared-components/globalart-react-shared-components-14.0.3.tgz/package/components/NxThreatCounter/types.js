import * as PropTypes from 'prop-types';
export var propTypes = {
    criticalCount: PropTypes.number,
    severeCount: PropTypes.number,
    moderateCount: PropTypes.number,
    lowCount: PropTypes.number,
    noneCount: PropTypes.number,
    unspecifiedCount: PropTypes.number,
    layout: PropTypes.string,
    className: PropTypes.string
};
//# sourceMappingURL=types.js.map