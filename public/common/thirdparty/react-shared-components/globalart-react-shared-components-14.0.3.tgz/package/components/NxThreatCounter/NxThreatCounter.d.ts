import React from 'react';
import { Props } from './types';
export { Props } from './types';
import './NxThreatCounter.scss';
declare function NxThreatCounter(props: Props): React.JSX.Element | null;
declare namespace NxThreatCounter {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default NxThreatCounter;
//# sourceMappingURL=NxThreatCounter.d.ts.map