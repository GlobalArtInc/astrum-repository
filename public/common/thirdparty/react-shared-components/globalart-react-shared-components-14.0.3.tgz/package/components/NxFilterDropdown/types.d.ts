import { ComponentPropsWithRef } from 'react';
import * as PropTypes from 'prop-types';
import DataItem from '../../util/DataItem';
export interface Props<T extends string | number = string> extends Omit<ComponentPropsWithRef<'div'>, 'onChange'> {
    options: DataItem<T>[];
    isOpen: boolean;
    onToggleCollapse: (() => void);
    selectedIds: Set<T>;
    onChange: ((selectedIds: Set<T>, toggledId?: T) => void);
    showReset?: boolean | null;
    placeholder?: string | null;
}
export declare const propTypes: {
    isOpen: PropTypes.Validator<boolean>;
    onToggleCollapse: PropTypes.Validator<(...args: any[]) => any>;
    onChange: PropTypes.Validator<(...args: any[]) => any>;
    showReset: PropTypes.Requireable<boolean>;
    placeholder: PropTypes.Requireable<string>;
};
//# sourceMappingURL=types.d.ts.map