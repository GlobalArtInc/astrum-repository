import * as PropTypes from 'prop-types';
export var propTypes = {
    // options and selectedIds are omitted due to issue with parametric props
    isOpen: PropTypes.bool.isRequired,
    onToggleCollapse: PropTypes.func.isRequired,
    onChange: PropTypes.func.isRequired,
    showReset: PropTypes.bool,
    placeholder: PropTypes.string
};
//# sourceMappingURL=types.js.map