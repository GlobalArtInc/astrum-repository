import React from 'react';
import { Props } from './types';
import './NxFilterDropdown.scss';
export { Props };
declare function NxFilterDropdown<T extends string | number = string>(props: Props<T>): React.JSX.Element;
declare namespace NxFilterDropdown {
    var propTypes: {
        isOpen: import("prop-types").Validator<boolean>;
        onToggleCollapse: import("prop-types").Validator<(...args: any[]) => any>;
        onChange: import("prop-types").Validator<(...args: any[]) => any>;
        showReset: import("prop-types").Requireable<boolean>;
        placeholder: import("prop-types").Requireable<string>;
    };
}
export default NxFilterDropdown;
//# sourceMappingURL=NxFilterDropdown.d.ts.map