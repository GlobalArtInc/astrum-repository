import React from 'react';
import { Props } from './types';
export { Props } from './types';
declare function NxStatefulFilterDropdown<T extends string | number = string>(props: Props<T>): React.JSX.Element;
declare namespace NxStatefulFilterDropdown {
    var propTypes: Omit<{
        isOpen: import("prop-types").Validator<boolean>;
        onToggleCollapse: import("prop-types").Validator<(...args: any[]) => any>;
        onChange: import("prop-types").Validator<(...args: any[]) => any>;
        showReset: import("prop-types").Requireable<boolean>;
        placeholder: import("prop-types").Requireable<string>;
    }, "isOpen" | "onToggleCollapse">;
}
export default NxStatefulFilterDropdown;
//# sourceMappingURL=NxStatefulFilterDropdown.d.ts.map