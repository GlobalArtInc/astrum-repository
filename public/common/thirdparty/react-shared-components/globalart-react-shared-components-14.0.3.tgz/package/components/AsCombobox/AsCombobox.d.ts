import React from 'react';
import './AsCombobox.scss';
import { Props } from './types';
import DataItem from '../../util/DataItem';
export { Props } from './types';
declare function AsCombobox<T extends string | number | DataItem<string | number, string> = string>(props: Props<T>): React.JSX.Element;
declare namespace AsCombobox {
    var propTypes: import("prop-types").ValidationMap<Props<DataItem<string | number, string>>>;
}
export default AsCombobox;
//# sourceMappingURL=AsCombobox.d.ts.map