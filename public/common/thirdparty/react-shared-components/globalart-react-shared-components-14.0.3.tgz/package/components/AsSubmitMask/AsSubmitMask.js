/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import classnames from 'classnames';
import { faCheckCircle } from '@fortawesome/free-solid-svg-icons';
import AsFontAwesomeIcon from '../AsFontAwesomeIcon/AsFontAwesomeIcon';
import { propTypes } from './types';
export { propTypes } from './types';
import AsLoadingSpinner from '../AsLoadingSpinner/AsLoadingSpinner';
import './AsSubmitMask.scss';
export var SUCCESS_VISIBLE_TIME_MS = 800;
var AsSubmitMask = function AsSubmitMask(_a) {
    var message = _a.message, successMessage = _a.successMessage, success = _a.success, ariaLabel = _a["aria-label"];
    var classes = classnames('as-submit-mask', {
        'as-submit-mask--success': !!success
    });
    return (React.createElement("div", { className: classes },
        React.createElement("div", { className: "as-submit-mask__message" }, success ?
            React.createElement(React.Fragment, null,
                React.createElement(AsFontAwesomeIcon, { icon: faCheckCircle, className: "as-loading-spinner__icon" }),
                React.createElement("span", { role: "status", className: "as-submit-mask__message-text", "aria-label": ariaLabel }, successMessage || 'Success!')) :
            React.createElement(AsLoadingSpinner, { "aria-label": ariaLabel }, message || 'Submitting…'))));
};
AsSubmitMask.propTypes = propTypes;
export default AsSubmitMask;
//# sourceMappingURL=AsSubmitMask.js.map