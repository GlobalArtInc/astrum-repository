import { FunctionComponent } from 'react';
import { Props } from './types';
export { Props, propTypes } from './types';
import './AsSubmitMask.scss';
export declare const SUCCESS_VISIBLE_TIME_MS = 800;
declare const AsSubmitMask: FunctionComponent<Props>;
export default AsSubmitMask;
//# sourceMappingURL=AsSubmitMask.d.ts.map