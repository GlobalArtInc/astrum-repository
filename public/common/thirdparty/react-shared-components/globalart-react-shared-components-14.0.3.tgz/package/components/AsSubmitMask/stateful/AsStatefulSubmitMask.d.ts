import { FunctionComponent } from 'react';
import { Props } from '../AsSubmitMask';
declare const AsStatefulSubmitMask: FunctionComponent<Props>;
export default AsStatefulSubmitMask;
//# sourceMappingURL=AsStatefulSubmitMask.d.ts.map