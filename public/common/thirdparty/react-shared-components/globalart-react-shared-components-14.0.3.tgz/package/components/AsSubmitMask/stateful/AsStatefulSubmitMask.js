var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { useRef, useState, useEffect } from 'react';
import AsSubmitMask, { SUCCESS_VISIBLE_TIME_MS } from '../AsSubmitMask';
var propsToState = function (_a) {
    var success = _a.success;
    return success ? 'success' : 'pending';
};
var AsStatefulSubmitMask = function AsStatefulSubmitMask(props) {
    // internalState is used to track the timer-based hiding of the mask in the success scenario
    var stateFromProps = propsToState(props), _a = useState(stateFromProps), internalState = _a[0], setInternalState = _a[1], 
    // the pattern for using timeouts with react hooks is to use `useRef` to create a 'box' for a mutable value,
    // and in that box store the Timeout value so that it may be cancelled later
    successTimeoutHolder = useRef(null), isSuccess = internalState === 'success';
    // if the external props are trying to change the state, and aren't trying to simply set it back
    // to "success" when it's already "done", change the state
    if (internalState !== stateFromProps && !(internalState === 'done' && stateFromProps === 'success')) {
        setInternalState(stateFromProps);
    }
    function clearSuccessTimeout() {
        if (successTimeoutHolder.current) {
            clearTimeout(successTimeoutHolder.current);
            successTimeoutHolder.current = null;
        }
    }
    useEffect(function () {
        if (isSuccess) {
            if (!successTimeoutHolder.current) {
                successTimeoutHolder.current = setTimeout(setInternalState.bind(null, 'done'), SUCCESS_VISIBLE_TIME_MS);
            }
        }
        else {
            clearSuccessTimeout();
        }
        return clearSuccessTimeout;
    }, [isSuccess]);
    return internalState === 'done' ? null : React.createElement(AsSubmitMask, __assign({}, props, { success: isSuccess }));
};
AsStatefulSubmitMask.propTypes = AsSubmitMask.propTypes;
export default AsStatefulSubmitMask;
//# sourceMappingURL=AsStatefulSubmitMask.js.map