import * as PropTypes from 'prop-types';
export var propTypes = {
    onClosing: PropTypes.func.isRequired,
    children: PropTypes.node
};
//# sourceMappingURL=types.js.map