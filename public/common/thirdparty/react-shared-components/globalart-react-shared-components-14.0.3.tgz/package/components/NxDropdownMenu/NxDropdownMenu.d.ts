import React from 'react';
import { Props } from './types';
import './NxDropdownMenu.scss';
export { Props };
/**
 * This component is not currently intended for public export. It is a helper for NxDropdown and NxSegmentedButton
 * so they can reset focus when they close
 */
declare function NxDropdownMenu(props: Props): React.JSX.Element;
declare namespace NxDropdownMenu {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default NxDropdownMenu;
//# sourceMappingURL=NxDropdownMenu.d.ts.map