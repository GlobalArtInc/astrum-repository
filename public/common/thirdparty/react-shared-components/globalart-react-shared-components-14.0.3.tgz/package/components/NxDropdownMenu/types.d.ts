import { ComponentPropsWithRef } from 'react';
import * as PropTypes from 'prop-types';
export interface Props extends ComponentPropsWithRef<'div'> {
    onClosing: () => void;
}
export declare const propTypes: PropTypes.ValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map