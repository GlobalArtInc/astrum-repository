var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { useLayoutEffect } from 'react';
import classnames from 'classnames';
import { propTypes } from './types';
import './NxDropdownMenu.scss';
/**
 * This component is not currently intended for public export. It is a helper for NxDropdown and NxSegmentedButton
 * so they can reset focus when they close
 */
export default function NxDropdownMenu(props) {
    var onClosing = props.onClosing, classNameProp = props.className, attrs = __rest(props, ["onClosing", "className"]), className = classnames('nx-dropdown-menu', classNameProp);
    // onClosing must execute when this element is being removed but BEFORE it actually gets removed from the DOM
    useLayoutEffect(function () { return onClosing; }, []);
    return React.createElement("div", __assign({ className: className }, attrs));
}
NxDropdownMenu.propTypes = propTypes;
//# sourceMappingURL=NxDropdownMenu.js.map