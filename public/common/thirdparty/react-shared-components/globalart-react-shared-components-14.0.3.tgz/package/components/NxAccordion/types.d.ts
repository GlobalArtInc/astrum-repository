import { ComponentPropsWithRef, MouseEvent } from 'react';
import * as PropTypes from 'prop-types';
export interface HeaderContextType {
    onClick: (evt: MouseEvent) => void;
    open: boolean;
    accordionId: string;
}
export interface Props extends Omit<ComponentPropsWithRef<'details'>, 'onToggle'> {
    onToggle?: ((open: boolean) => void) | null;
}
export type HeaderProps = ComponentPropsWithRef<'header'>;
export declare const propTypes: PropTypes.ValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map