import React from 'react';
import { HeaderProps, Props } from './types';
import './NxAccordion.scss';
export { Props, HeaderProps };
declare function NxAccordionHeader({ className, onClick: onClickProp, children, ...otherProps }: HeaderProps): React.JSX.Element;
declare function NxAccordion(props: Props): React.JSX.Element;
declare namespace NxAccordion {
    var propTypes: import("prop-types").ValidationMap<Props>;
    var Header: typeof NxAccordionHeader;
    var Title: (props: React.DetailedHTMLProps<React.HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>) => React.ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>, "className">, string | React.JSXElementConstructor<any>>;
}
export default NxAccordion;
//# sourceMappingURL=NxAccordion.d.ts.map