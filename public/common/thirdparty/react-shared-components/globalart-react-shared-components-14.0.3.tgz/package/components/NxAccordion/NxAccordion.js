var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { useContext, useRef } from 'react';
import classnames from 'classnames';
import { faChevronCircleDown, faChevronCircleUp } from '@fortawesome/free-solid-svg-icons';
import NxFontAwesomeIcon from '../NxFontAwesomeIcon/NxFontAwesomeIcon';
import { propTypes } from './types';
import './NxAccordion.scss';
import { splitOutFirst } from '../../util/childUtil';
import withClass from '../../util/withClass';
import { useUniqueId } from '../../util/idUtil';
var HeaderContext = React.createContext({
    onClick: function () { },
    open: false,
    accordionId: ''
});
function NxAccordionHeader(_a) {
    var className = _a.className, onClickProp = _a.onClick, children = _a.children, otherProps = __rest(_a, ["className", "onClick", "children"]);
    var classes = classnames('nx-accordion__header', className), _b = useContext(HeaderContext), onClickContext = _b.onClick, open = _b.open, accordionId = _b.accordionId, summaryElRef = useRef(null);
    // returns whether or not el is within a <button>. Assumes that el is a child of the <summary>
    function isWithinSummaryBtn(el) {
        return el.tagName === 'BUTTON' ? true :
            el === summaryElRef.current ? false :
                el.parentElement === null ? false :
                    isWithinSummaryBtn(el.parentElement);
    }
    function onClick(evt) {
        if (onClickProp) {
            onClickProp(evt);
        }
        // do not trigger collapse/expand for clicks on nested buttons, only on the header itself
        if (!isWithinSummaryBtn(evt.target)) {
            onClickContext(evt);
        }
    }
    return (React.createElement("summary", __assign({ className: classes, onClick: onClick, ref: summaryElRef, role: "button", "aria-controls": accordionId }, otherProps),
        React.createElement("div", { className: "nx-accordion__summary-wrapper" },
            React.createElement(NxFontAwesomeIcon, { className: "nx-accordion__chevron", icon: open ? faChevronCircleUp : faChevronCircleDown }),
            children)));
}
export default function NxAccordion(props) {
    var className = props.className, onToggle = props.onToggle, open = props.open, children = props.children, id = props.id, otherProps = __rest(props, ["className", "onToggle", "open", "children", "id"]), classes = classnames('nx-accordion', className), _a = splitOutFirst(NxAccordionHeader, children), header = _a[0], otherChildren = _a[1], accordionId = useUniqueId('nx-accordion', id);
    function onHeaderClick(evt) {
        evt.preventDefault();
        if (onToggle) {
            onToggle(!open);
        }
    }
    var headerContext = {
        onClick: onHeaderClick,
        open: !!open,
        accordionId: accordionId
    };
    return (
    // By the standards, this role shouldn't be here explicitly and aria-expanded isn't valid.
    // But real-world screenreaders need them
    React.createElement("details", __assign({ id: accordionId, className: classes, open: open }, otherProps, { role: "group", "aria-expanded": !!open }),
        React.createElement(HeaderContext.Provider, { value: headerContext }, header),
        React.createElement("div", { className: "nx-accordion__content" }, otherChildren)));
}
NxAccordion.propTypes = propTypes;
NxAccordion.Header = NxAccordionHeader;
NxAccordion.Title = withClass('h2', 'nx-accordion__header-title');
//# sourceMappingURL=NxAccordion.js.map