import React from 'react';
import { Props } from './types';
export { Props };
declare function NxStatefulAccordion({ defaultOpen, onToggle, ...otherProps }: Props): React.JSX.Element;
declare namespace NxStatefulAccordion {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default NxStatefulAccordion;
//# sourceMappingURL=NxStatefulAccordion.d.ts.map