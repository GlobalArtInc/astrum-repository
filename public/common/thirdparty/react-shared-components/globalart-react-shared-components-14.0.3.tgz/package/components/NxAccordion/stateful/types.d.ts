import * as PropTypes from 'prop-types';
import { Props as StatelessProps } from '../types';
export type Props = Omit<StatelessProps, 'open'> & {
    defaultOpen?: boolean | null;
};
export declare const propTypes: PropTypes.ValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map