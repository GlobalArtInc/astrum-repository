import * as PropTypes from 'prop-types';
export var propTypes = {
    onToggle: PropTypes.func
};
//# sourceMappingURL=types.js.map