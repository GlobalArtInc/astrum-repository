import React from 'react';
import { AbstractDropdownProps } from './types';
export { AbstractDropdownProps, AbstractDropdownRenderToggleElement } from './types';
/**
 * Abstracted Dropdown global event handling.
 * @param isOpen - a boolean to indicate if the dropdown is open or not.
 * @param className - a classname string for the div containing the toggle and dropdown.
 * @param disabled - If true disables toggling of dropdown.
 * @param onToggleCollapse - The onToggleCollapse function that was provided from outside of the component
 * @param onCloseClick - A callback that should fire when a click
 *    is detected that would result in the dropdown getting closed. The Mouse event is passed to this handler,
 *    and if the handler calls `preventDefault` on it, the close is cancelled
 * @param onCloseKeyDown - A callback provided that should fire when a key press
 *    is detected that would result in the dropdown getting closed. The Keyboard event is passed to this handler,
 *    and if the handler calls `preventDefault` on it, the close is cancelled
 * @param onToggleCollapse - The onToggleCollapse function that was provided from outside of the component
 * @param onKeyDown - Any onKeyDown function that might have been provided from outside of the component.
 *    Note that this fires after the close processing occurs
 * @return - A div with the toggle element and dropdown menu.
 */
export default function AbstractDropdown(props: AbstractDropdownProps): React.JSX.Element;
//# sourceMappingURL=AbstractDropdown.d.ts.map