var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import classnames from 'classnames';
import { faCaretDown, faCaretUp } from '@fortawesome/free-solid-svg-icons';
import { propTypes } from './types';
import NxTooltip from '../NxTooltip/NxTooltip';
import NxButton from '../NxButton/NxButton';
import NxFontAwesomeIcon from '../NxFontAwesomeIcon/NxFontAwesomeIcon';
import { wrapTooltipProps } from '../../util/tooltipUtils';
import './NxDropdown.scss';
import NxOverflowTooltip from '../NxTooltip/NxOverflowTooltip';
import AbstractDropdown from './AbstractDropdown';
import withClass from '../../util/withClass';
export default function NxDropdown(props) {
    var children = props.children, className = props.className, disabled = props.disabled, isOpen = props.isOpen, label = props.label, toggleTooltip = props.toggleTooltip, variant = props.variant, otherProps = __rest(props, ["children", "className", "disabled", "isOpen", "label", "toggleTooltip", "variant"]);
    var buttonClasses = classnames('nx-dropdown__toggle', { disabled: disabled, open: isOpen });
    var classes = classnames('nx-dropdown', className);
    var toggleTooltipProps = toggleTooltip && wrapTooltipProps(toggleTooltip);
    // Wrap .nx-dropdown-button and .nx-dropdown-link children in overflow tooltips
    var wrappedChildren = children && React.Children.map(children, function (child) { return (child && typeof child !== 'boolean' && child.props.className &&
        /(\s|^)nx-dropdown-(button|link)(\s|$)/.test(child.props.className) ?
        React.createElement(NxOverflowTooltip, null, child) :
        child); });
    var renderToggleElement = function (toggleRef, onToggleCollapse) {
        var button = (React.createElement(NxButton, { ref: toggleRef, type: "button", variant: variant || 'tertiary', className: buttonClasses, onClick: !disabled && onToggleCollapse || undefined, "aria-haspopup": "true", "aria-expanded": isOpen },
            React.createElement("span", { className: "nx-dropdown__toggle-label" }, label),
            React.createElement(NxFontAwesomeIcon, { className: "nx-dropdown__toggle-caret", icon: isOpen ? faCaretUp : faCaretDown, size: "lg" })));
        return toggleTooltipProps ? React.createElement(NxTooltip, __assign({}, toggleTooltipProps), button) : button;
    };
    return (React.createElement(AbstractDropdown, __assign({ className: classes, isOpen: isOpen, disabled: disabled, renderToggleElement: renderToggleElement }, otherProps), wrappedChildren));
}
NxDropdown.propTypes = propTypes;
NxDropdown.Divider = withClass('hr', 'nx-dropdown__divider');
export { propTypes } from './types';
//# sourceMappingURL=NxDropdown.js.map