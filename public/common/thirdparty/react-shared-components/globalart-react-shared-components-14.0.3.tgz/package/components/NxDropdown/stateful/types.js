import * as PropTypes from 'prop-types';
import { NX_BUTTON_VARIANTS } from '../../NxButton/types';
import { tooltipPropTypesShape } from '../../../util/tooltipUtils';
import { childrenPropTypes } from '../types';
;
export var propTypes = {
    label: PropTypes.oneOfType([
        PropTypes.node.isRequired,
        PropTypes.string.isRequired
    ]).isRequired,
    variant: PropTypes.oneOf(NX_BUTTON_VARIANTS),
    className: PropTypes.string,
    children: childrenPropTypes,
    disabled: PropTypes.bool,
    toggleTooltip: PropTypes.oneOfType([tooltipPropTypesShape, PropTypes.string])
};
//# sourceMappingURL=types.js.map