import { FunctionComponent } from 'react';
import { Props } from './types';
declare const NxStatefulDropdown: FunctionComponent<Props>;
export default NxStatefulDropdown;
export { Props, propTypes } from './types';
//# sourceMappingURL=NxStatefulDropdown.d.ts.map