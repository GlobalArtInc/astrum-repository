import * as PropTypes from 'prop-types';
import { NX_BUTTON_VARIANTS } from '../NxButton/types';
import { tooltipPropTypesShape } from '../../util/tooltipUtils';
export var childrenPropTypes = PropTypes.oneOfType([
    PropTypes.arrayOf(PropTypes.oneOfType([PropTypes.element, PropTypes.oneOf([null, undefined, false])])),
    PropTypes.oneOfType([PropTypes.element, PropTypes.oneOf([null, undefined, false])])
]);
export var propTypes = {
    label: PropTypes.oneOfType([
        PropTypes.node.isRequired,
        PropTypes.string.isRequired
    ]).isRequired,
    isOpen: PropTypes.bool.isRequired,
    variant: PropTypes.oneOf(NX_BUTTON_VARIANTS),
    className: PropTypes.string,
    children: childrenPropTypes,
    disabled: PropTypes.bool,
    onToggleCollapse: PropTypes.func,
    onCloseKeyDown: PropTypes.func,
    onCloseClick: PropTypes.func,
    toggleTooltip: PropTypes.oneOfType([tooltipPropTypesShape, PropTypes.string])
};
//# sourceMappingURL=types.js.map