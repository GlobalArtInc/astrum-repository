import React from 'react';
import { Props } from './types';
import './NxDropdown.scss';
declare function NxDropdown(props: Props): React.JSX.Element;
declare namespace NxDropdown {
    var propTypes: import("prop-types").WeakValidationMap<Props>;
    var Divider: (props: React.DetailedHTMLProps<React.HTMLAttributes<HTMLHRElement>, HTMLHRElement>) => React.ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLHRElement>, HTMLHRElement>, "className">, string | React.JSXElementConstructor<any>>;
}
export default NxDropdown;
export { Props, propTypes } from './types';
//# sourceMappingURL=NxDropdown.d.ts.map