/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import { faTimesCircle } from '@fortawesome/free-solid-svg-icons';
import prettyBytes from 'pretty-bytes';
import AsFontAwesomeIcon from '../AsFontAwesomeIcon/AsFontAwesomeIcon';
import AsOverflowTooltip from '../AsTooltip/AsOverflowTooltip';
import AsTooltip from '../AsTooltip/AsTooltip';
var formatSize = function (size) { return prettyBytes(size, { minimumFractionDigits: 1, maximumFractionDigits: 1 }); };
export default function SelectedFile(_a) {
    var ref = _a.ref, file = _a.file, onDismiss = _a.onDismiss, descriptionId = _a.descriptionId;
    // Testing on NVDA shows a need to set this as the aria-label in addition to the tooltip
    var buttonLabel = 'Dismiss Upload';
    return (React.createElement("span", { className: "as-selected-file", ref: ref },
        React.createElement("span", { className: "as-selected-file__info", id: descriptionId },
            React.createElement(AsOverflowTooltip, null,
                React.createElement("span", { className: "as-selected-file__name" }, file.name)),
            React.createElement("span", { className: "as-selected-file__size" }, formatSize(file.size))),
        React.createElement(AsTooltip, { title: buttonLabel },
            React.createElement("button", { type: "button", "aria-label": buttonLabel, className: "as-selected-file__dismiss-btn", onClick: onDismiss },
                React.createElement(AsFontAwesomeIcon, { icon: faTimesCircle })))));
}
//# sourceMappingURL=SelectedFile.js.map