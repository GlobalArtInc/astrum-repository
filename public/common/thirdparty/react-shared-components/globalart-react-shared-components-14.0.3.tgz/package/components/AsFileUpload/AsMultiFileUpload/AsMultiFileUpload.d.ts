import React from 'react';
import { Props } from '../types';
export { Props };
import './AsMultiFileUpload.scss';
declare function AsMultiFileUpload(props: Props): React.JSX.Element;
declare namespace AsMultiFileUpload {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default AsMultiFileUpload;
//# sourceMappingURL=AsMultiFileUpload.d.ts.map