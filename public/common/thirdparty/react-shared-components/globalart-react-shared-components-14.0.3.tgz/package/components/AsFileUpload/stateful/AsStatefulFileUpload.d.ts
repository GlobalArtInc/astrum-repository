import React from 'react';
import { StatefulProps as Props } from '../types';
export { Props };
declare function AsStatefulFileUpload(props: Props): React.JSX.Element;
declare namespace AsStatefulFileUpload {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default AsStatefulFileUpload;
//# sourceMappingURL=AsStatefulFileUpload.d.ts.map