var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { useEffect, useRef, useContext } from 'react';
import { faExclamationCircle } from '@fortawesome/free-solid-svg-icons';
import classnames from 'classnames';
import AsFontAwesomeIcon from '../AsFontAwesomeIcon/AsFontAwesomeIcon';
import AsButton from '../AsButton/AsButton';
import SelectedFile from './SelectedFile';
import { FormAriaContext } from '../AsForm/context';
import { useUniqueId } from '../../util/idUtil';
import { propTypes } from './types';
import './AsFileUpload.scss';
export default function AsFileUpload(props) {
    var ref = props.ref, classNameProp = props.className, onChangeProp = props.onChange, files = props.files, isRequired = props.isRequired, isPristine = props.isPristine, id = props.id, disabled = props.disabled, attrs = __rest(props, ["ref", "className", "onChange", "files", "isRequired", "isPristine", "id", "disabled"]), file = files === null || files === void 0 ? void 0 : files.item(0), isFileSelected = !!file, formShowValidationErrors = useContext(FormAriaContext).showValidationErrors, showValidationErrors = formShowValidationErrors || !isPristine, showError = isRequired && showValidationErrors && !isFileSelected, className = classnames('as-file-upload', classNameProp), noFileMessageClassName = classnames('as-file-upload__no-file-message', {
        'as-file-upload__no-file-message--invalid': showError
    }), inputRef = useRef(null), inputId = useUniqueId('as-file-upload-input', id), validationErrorId = useUniqueId('as-file-upload-validation-error'), descriptionId = useUniqueId('as-file-upload-description');
    function onChange(evt) {
        var files = evt.currentTarget.files, normalizedFiles = !(files === null || files === void 0 ? void 0 : files.length) ? null : files;
        onChangeProp(normalizedFiles);
    }
    function openPicker() {
        var _a;
        (_a = inputRef.current) === null || _a === void 0 ? void 0 : _a.click();
    }
    function onDismiss() {
        var _a;
        (_a = inputRef.current) === null || _a === void 0 ? void 0 : _a.focus();
        onChangeProp(null);
    }
    useEffect(function () {
        if (inputRef.current) {
            if (isFileSelected) {
                inputRef.current.files = files;
            }
            else {
                // there's no way to clear the list via the files prop, but this does it
                inputRef.current.value = '';
            }
        }
    }, [files]);
    return (React.createElement("div", { ref: ref, className: className },
        React.createElement("input", __assign({ ref: inputRef }, attrs, { disabled: disabled, onChange: onChange, id: inputId, className: "as-file-upload__input", type: "file", "aria-describedby": descriptionId, "aria-required": isRequired !== null && isRequired !== void 0 ? isRequired : undefined, "aria-invalid": showError || undefined, "aria-errormessage": showError ? validationErrorId : undefined })),
        React.createElement(AsButton, { type: "button", "aria-hidden": true, disabled: disabled, variant: "tertiary", onClick: openPicker, tabIndex: -1, className: "as-file-upload__select-btn" }, "Choose File"),
        isFileSelected ?
            React.createElement(SelectedFile, { descriptionId: descriptionId, file: file, onDismiss: onDismiss }) :
            React.createElement("span", { id: descriptionId, className: noFileMessageClassName },
                React.createElement("span", null, "No file selected"),
                React.createElement(AsFontAwesomeIcon, { icon: faExclamationCircle })),
        showError &&
            // TODO confirm whether this text should be hard-coded
            React.createElement("div", { id: validationErrorId, role: "alert", className: "as-field-validation-message" }, "This field is required!")));
}
AsFileUpload.propTypes = propTypes;
//# sourceMappingURL=AsFileUpload.js.map