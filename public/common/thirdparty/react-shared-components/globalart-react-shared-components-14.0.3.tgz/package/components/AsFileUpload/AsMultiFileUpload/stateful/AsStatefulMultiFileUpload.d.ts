import React from 'react';
import { StatefulProps as Props } from '../../types';
export { Props };
declare function AsStatefulMultiFileUpload(props: Props): React.JSX.Element;
declare namespace AsStatefulMultiFileUpload {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default AsStatefulMultiFileUpload;
//# sourceMappingURL=AsStatefulMultiFileUpload.d.ts.map