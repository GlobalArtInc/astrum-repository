import React from 'react';
import { Props } from './types';
export { Props };
import './AsFileUpload.scss';
declare function AsFileUpload(props: Props): React.JSX.Element;
declare namespace AsFileUpload {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default AsFileUpload;
//# sourceMappingURL=AsFileUpload.d.ts.map