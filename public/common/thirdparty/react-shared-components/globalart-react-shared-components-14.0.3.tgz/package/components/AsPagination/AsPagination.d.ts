import React from 'react';
import { Props, propTypes } from './types';
export { Props, propTypes };
declare function AsPagination({ className, pageCount, currentPage, onChange, ...attrs }: Props): React.JSX.Element;
declare namespace AsPagination {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default AsPagination;
//# sourceMappingURL=AsPagination.d.ts.map