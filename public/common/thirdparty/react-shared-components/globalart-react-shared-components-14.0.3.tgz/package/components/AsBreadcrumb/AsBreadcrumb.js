var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import classnames from 'classnames';
import { append, dropLast, head, init, insert, last, map, tail, takeLast } from 'ramda';
import { faEllipsisH } from '@fortawesome/free-solid-svg-icons';
import AsTextLink from '../AsTextLink/AsTextLink';
import { propTypes } from './types';
import AsIconDropdown from '../AsIconDropdown/AsIconDropdown';
import './AsBreadcrumb.scss';
import AsOverflowTooltip from '../AsTooltip/AsOverflowTooltip';
function CurrentBreadcrumb(_a) {
    var name = _a.name;
    return (React.createElement(AsOverflowTooltip, null,
        React.createElement("li", { className: "as-breadcrumb__list-item as-breadcrumb__list-item--link-container" },
            React.createElement("a", { className: "as-breadcrumb__link as-breadcrumb__link--current", "aria-current": "page" }, name))));
}
function BreadcrumbLink(_a) {
    var name = _a.name, href = _a.href;
    return (React.createElement(AsOverflowTooltip, null,
        React.createElement("li", { className: "as-breadcrumb__list-item as-breadcrumb__list-item--link-container" },
            React.createElement(AsTextLink, { className: "as-breadcrumb__link", href: href }, name))));
}
function BreadcrumbDropdownLink(_a) {
    var name = _a.name, href = _a.href;
    return (React.createElement(AsOverflowTooltip, null,
        React.createElement(AsTextLink, { className: "as-dropdown-link", href: href }, name)));
}
function BreadcrumbDropdown(_a) {
    var crumbs = _a.crumbs, isOpen = _a.isOpen, onToggleCollapse = _a.onToggleCollapse;
    return (React.createElement("li", { className: "as-breadcrumb__list-item" },
        React.createElement(AsIconDropdown, { isOpen: isOpen, onToggleCollapse: onToggleCollapse, icon: faEllipsisH, title: "more\u2026" }, map(function (c) { return React.createElement(BreadcrumbDropdownLink, __assign({ key: c.href }, c)); }, crumbs))));
}
export default function AsBreadcrumb(props) {
    var crumbs = props.crumbs, isDropdownOpen = props.isDropdownOpen, onToggleDropdown = props.onToggleDropdown, classNameProp = props.className, otherProps = __rest(props, ["crumbs", "isDropdownOpen", "onToggleDropdown", "className"]), crumbBeforeDropdown = crumbs.length < 2 ? null : head(crumbs);
    if (crumbBeforeDropdown) {
        var dropdownCrumbs = crumbs.length < 5 ? [] : tail(dropLast(2, crumbs)), crumbsAfterDropdown = crumbs.length < 5 ? tail(crumbs) : takeLast(2, crumbs), crumbsToBecomeLinks = __spreadArray([crumbBeforeDropdown], init(crumbsAfterDropdown), true), 
        // if we're in this block, the list was at least two items long so last on the "after" crumbs will
        // always have a value
        /* eslint-disable-next-line @typescript-eslint/no-non-null-assertion */
        currentCrumb = last(crumbsAfterDropdown), currentCrumbRender = React.createElement(CurrentBreadcrumb, __assign({ key: currentCrumb.href }, currentCrumb)), rowLinks = map(function (c) { return React.createElement(BreadcrumbLink, __assign({ key: c.href }, c)); }, crumbsToBecomeLinks), dropdown = dropdownCrumbs.length ?
            React.createElement(BreadcrumbDropdown, { key: "%%as-breadcrumb-dropdown", isOpen: isDropdownOpen, onToggleCollapse: onToggleDropdown, crumbs: dropdownCrumbs }) :
            null, rowInteractiveParts = dropdown ? insert(1, dropdown, rowLinks) : rowLinks, rowItems = append(currentCrumbRender, rowInteractiveParts), className = classnames('as-breadcrumb', classNameProp);
        // do not render anything when at the top level of the breadcrumb hiearchy
        return (React.createElement("nav", __assign({ className: className, "aria-label": "breadcrumbs" }, otherProps),
            React.createElement("ol", { className: "as-breadcrumb__list" }, rowItems)));
    }
    else {
        return null;
    }
}
AsBreadcrumb.propTypes = propTypes;
//# sourceMappingURL=AsBreadcrumb.js.map