import React from 'react';
import { StatefulProps } from '../types';
export { StatefulProps as Props };
export default function AsStatefulBreadcrumb(props: StatefulProps): React.JSX.Element;
//# sourceMappingURL=AsStatefulBreadcrumb.d.ts.map