import React from 'react';
import { Props, Crumb } from './types';
import './AsBreadcrumb.scss';
export { Props, Crumb };
declare function AsBreadcrumb(props: Props): React.JSX.Element | null;
declare namespace AsBreadcrumb {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default AsBreadcrumb;
//# sourceMappingURL=AsBreadcrumb.d.ts.map