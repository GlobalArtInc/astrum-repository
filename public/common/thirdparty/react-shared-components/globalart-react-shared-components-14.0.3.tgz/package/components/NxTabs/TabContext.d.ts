import React from 'react';
import { TabContextType } from './types';
declare const _default: React.Context<TabContextType>;
export default _default;
//# sourceMappingURL=TabContext.d.ts.map