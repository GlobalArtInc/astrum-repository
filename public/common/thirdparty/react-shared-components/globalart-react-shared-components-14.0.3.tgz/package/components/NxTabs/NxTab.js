var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { useContext, useRef } from 'react';
import classnames from 'classnames';
import TabContext from './TabContext';
import { nxTabPropTypes } from './types';
import NxOverflowTooltip from '../NxTooltip/NxOverflowTooltip';
import { modifierKeyIsPressed } from '../../util/keyboardUtil';
var SPACE = ' ';
var NxTab = function NxTabElement(props) {
    var _a = useContext(TabContext), activeTab = _a.activeTab, rootId = _a.rootId, index = _a.index, onTabSelect = _a.onTabSelect;
    var className = props.className, children = props.children, onClick = props.onClick, onKeyPress = props.onKeyPress, attrs = __rest(props, ["className", "children", "onClick", "onKeyPress"]);
    var isActiveTab = activeTab === index;
    var classNames = classnames('nx-tab', className, { active: isActiveTab });
    var liElement = useRef(null);
    function handleKeyPress(event) {
        if (onKeyPress) {
            onKeyPress(event);
        }
        if (!event.isDefaultPrevented() && (event.key === SPACE || event.key === 'Enter')) {
            event.preventDefault();
            onTabSelect(index);
        }
    }
    function handleClick(event) {
        if (onClick) {
            onClick(event);
        }
        if (!event.isDefaultPrevented()) {
            onTabSelect(index);
        }
    }
    function handleKeyDown(event) {
        if (event.isDefaultPrevented() || modifierKeyIsPressed(event)) {
            return;
        }
        // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
        var tabElements = event.currentTarget.parentElement.children;
        var getNextElementFromEventKey = function (key) {
            var _a, _b;
            switch (key) {
                case 'Tab': {
                    if (!activeTab) {
                        return;
                    }
                    var tabId = tabElements[activeTab].getAttribute('aria-controls');
                    return document.getElementById(tabId);
                }
                case 'ArrowLeft':
                    return (_a = tabElements[index - 1]) !== null && _a !== void 0 ? _a : tabElements[tabElements.length - 1];
                case 'ArrowRight':
                    return (_b = tabElements[index + 1]) !== null && _b !== void 0 ? _b : tabElements[0];
                case 'Home':
                    return tabElements[0];
                case 'End':
                    return tabElements[tabElements.length - 1];
                default:
                    return;
            }
        };
        var nextElement = getNextElementFromEventKey(event.key);
        if (nextElement) {
            event.preventDefault();
            nextElement.focus();
        }
    }
    return (React.createElement(NxOverflowTooltip, { title: children },
        React.createElement("li", __assign({ role: "tab", id: "".concat(rootId, "-tab-").concat(index), "aria-controls": "".concat(rootId, "-tabpanel-").concat(index), className: classNames, "aria-selected": isActiveTab, onKeyPress: handleKeyPress, onKeyDown: handleKeyDown, onClick: handleClick, tabIndex: isActiveTab ? 0 : -1, ref: liElement }, attrs),
            children,
            React.createElement("div", { className: "nx-tab__hidden-children" }, children))));
};
NxTab.propTypes = nxTabPropTypes;
export default NxTab;
//# sourceMappingURL=NxTab.js.map