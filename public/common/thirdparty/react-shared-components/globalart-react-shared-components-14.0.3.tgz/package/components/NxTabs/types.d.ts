import { ComponentPropsWithRef, PropsWithChildren, ReactElement } from 'react';
import PropTypes from 'prop-types';
export interface TabContextType {
    activeTab?: number | null;
    rootId: string;
    index: number;
    onTabSelect: (index: number) => void;
}
export type NxTabsProps = ComponentPropsWithRef<'div'> & {
    activeTab?: number | null;
    onTabSelect: ((index: number) => void);
    children?: ReactElement<PropsWithChildren> | ReactElement<PropsWithChildren>[] | null;
};
export type NxTabListProps = ComponentPropsWithRef<'ul'>;
export type NxTabPanelProps = ComponentPropsWithRef<'div'>;
export type NxTabProps = ComponentPropsWithRef<'li'> & {
    index?: number | null;
};
export declare const nxTabsPropTypes: PropTypes.ValidationMap<NxTabsProps>;
export declare const nxTabPropTypes: PropTypes.ValidationMap<NxTabProps>;
export declare const nxTabListPropTypes: PropTypes.ValidationMap<NxTabListProps>;
export declare const nxTabPanelPropTypes: PropTypes.ValidationMap<NxTabPanelProps>;
//# sourceMappingURL=types.d.ts.map