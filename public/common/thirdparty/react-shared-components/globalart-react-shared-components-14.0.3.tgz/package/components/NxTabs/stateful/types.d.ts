import { PropsWithChildren, ReactElement } from 'react';
import { HTMLAttributes } from 'react';
import PropTypes from 'prop-types';
export type Props = HTMLAttributes<HTMLDivElement> & {
    defaultActiveTab?: number | null;
    onTabSelect?: ((id: number) => void) | null;
    children?: ReactElement<PropsWithChildren> | ReactElement<PropsWithChildren>[] | null;
};
export declare const propTypes: PropTypes.ValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map