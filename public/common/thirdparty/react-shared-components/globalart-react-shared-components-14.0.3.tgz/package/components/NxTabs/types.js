import PropTypes from 'prop-types';
export var nxTabsPropTypes = {
    activeTab: PropTypes.number,
    onTabSelect: PropTypes.func.isRequired,
    children: PropTypes.oneOfType([
        PropTypes.element,
        PropTypes.arrayOf(PropTypes.element.isRequired)
    ])
};
export var nxTabPropTypes = {
    index: PropTypes.number,
    children: PropTypes.node
};
export var nxTabListPropTypes = {
    children: PropTypes.node
};
export var nxTabPanelPropTypes = {
    className: PropTypes.string
};
//# sourceMappingURL=types.js.map