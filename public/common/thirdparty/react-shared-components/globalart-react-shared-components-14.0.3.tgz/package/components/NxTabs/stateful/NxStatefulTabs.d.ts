import React from 'react';
import { Props } from './types';
/**
 * A stateful component for rendering clickable tabs.
 * Clicking on a NxTabLabel will show the associated Tab (determined by using an index number for each).
 * This assumes the following:
 * * The first child must be a NxTabList component.
 * * There is at least one NxTabPanel component for each NxTab in the NxTabList component.
 * * The NxTabPanel must have a labelledBy prop that matches the id of an NxTab.
 */
declare const NxStatefulTabs: {
    (props: Props): React.JSX.Element;
    propTypes: import("prop-types").ValidationMap<Props>;
};
export default NxStatefulTabs;
//# sourceMappingURL=NxStatefulTabs.d.ts.map