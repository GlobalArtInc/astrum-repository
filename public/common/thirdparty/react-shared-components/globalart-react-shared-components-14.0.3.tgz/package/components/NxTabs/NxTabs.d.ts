import React from 'react';
import { NxTabsProps } from './types';
export { NxTabsProps } from './types';
import './NxTabs.scss';
declare const NxTabs: {
    (props: NxTabsProps): React.JSX.Element | null;
    propTypes: import("prop-types").ValidationMap<NxTabsProps>;
};
export default NxTabs;
//# sourceMappingURL=NxTabs.d.ts.map