import PropTypes from 'prop-types';
export var propTypes = {
    defaultActiveTab: PropTypes.number,
    onTabSelect: PropTypes.func,
    children: PropTypes.oneOfType([
        PropTypes.element,
        PropTypes.arrayOf(PropTypes.element.isRequired)
    ])
};
//# sourceMappingURL=types.js.map