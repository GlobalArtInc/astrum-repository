import React from 'react';
import { NxTabPanelProps } from './types';
export { NxTabPanelProps };
declare const NxTabPanel: {
    (props: NxTabPanelProps): React.JSX.Element | null;
    propTypes: import("prop-types").ValidationMap<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>>;
};
export default NxTabPanel;
//# sourceMappingURL=NxTabPanel.d.ts.map