import React from 'react';
import { NxTabProps } from './types';
export { NxTabProps };
declare const NxTab: {
    (props: NxTabProps): React.JSX.Element;
    propTypes: import("prop-types").ValidationMap<NxTabProps>;
};
export default NxTab;
//# sourceMappingURL=NxTab.d.ts.map