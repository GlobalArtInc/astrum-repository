var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { useContext } from 'react';
import classnames from 'classnames';
import TabContext from './TabContext';
import { nxTabPanelPropTypes } from './types';
var NxTabPanel = function NxTabPanelElement(props) {
    var _a = useContext(TabContext), activeTab = _a.activeTab, rootId = _a.rootId, index = _a.index;
    var className = props.className, attrs = __rest(props, ["className"]);
    if (activeTab !== index) {
        return null;
    }
    return (React.createElement("div", __assign({ role: "tabpanel", id: "".concat(rootId, "-tabpanel-").concat(index), "aria-labelledby": "".concat(rootId, "-tab-").concat(index), className: classnames('nx-tab-panel', className), tabIndex: 0 }, attrs)));
};
NxTabPanel.propTypes = nxTabPanelPropTypes;
export default NxTabPanel;
//# sourceMappingURL=NxTabPanel.js.map