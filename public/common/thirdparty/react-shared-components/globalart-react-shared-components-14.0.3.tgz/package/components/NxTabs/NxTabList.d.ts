import React from 'react';
import { NxTabListProps } from './types';
export { NxTabListProps };
declare const NxTabList: {
    (props: NxTabListProps): React.JSX.Element;
    propTypes: import("prop-types").ValidationMap<React.DetailedHTMLProps<React.HTMLAttributes<HTMLUListElement>, HTMLUListElement>>;
};
export default NxTabList;
//# sourceMappingURL=NxTabList.d.ts.map