import PropTypes from 'prop-types';
export var nxThreatIndicatorLegendPropTypes = {
    critical: PropTypes.bool,
    severe: PropTypes.bool,
    moderate: PropTypes.bool,
    low: PropTypes.bool,
    none: PropTypes.bool,
    unspecified: PropTypes.bool,
    vertical: PropTypes.bool,
    header: PropTypes.string
};
//# sourceMappingURL=types.js.map