import React from 'react';
import { NxThreatIndicatorLegendProps } from './types';
import './NxThreatIndicatorLegend.scss';
declare function NxThreatIndicatorLegend(props: NxThreatIndicatorLegendProps): React.JSX.Element | null;
declare namespace NxThreatIndicatorLegend {
    var propTypes: import("prop-types").ValidationMap<NxThreatIndicatorLegendProps>;
}
export default NxThreatIndicatorLegend;
export { NxThreatIndicatorLegendProps, nxThreatIndicatorLegendPropTypes } from './types';
//# sourceMappingURL=NxThreatIndicatorLegend.d.ts.map