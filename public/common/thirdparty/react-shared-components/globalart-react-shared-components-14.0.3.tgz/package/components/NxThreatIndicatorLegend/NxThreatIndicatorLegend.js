var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import classnames from 'classnames';
import { nxThreatIndicatorLegendPropTypes } from './types';
import NxThreatIndicator from '../NxThreatIndicator/NxThreatIndicator';
import './NxThreatIndicatorLegend.scss';
var capitalize = function (str) { return str.charAt(0).toUpperCase() + str.slice(1); };
var ThreatIndicator = function (_a) {
    var threatType = _a.threatType;
    return (React.createElement("div", { className: "nx-threat-indicator-legend__threat-container" },
        React.createElement(NxThreatIndicator, { threatLevelCategory: threatType }),
        React.createElement("span", null, capitalize(threatType))));
};
export default function NxThreatIndicatorLegend(props) {
    var critical = props.critical, severe = props.severe, moderate = props.moderate, low = props.low, none = props.none, unspecified = props.unspecified, vertical = props.vertical, header = props.header, className = props.className, attrs = __rest(props, ["critical", "severe", "moderate", "low", "none", "unspecified", "vertical", "header", "className"]);
    var classNames = classnames(className, 'nx-threat-indicator-legend', {
        'nx-threat-indicator-legend--vertical': vertical
    });
    if (!critical && !severe && !moderate && !low && !none && !unspecified) {
        console.warn("No threat level categories for NxThreatIndicatorLegend have been provided\n    as props so nothing will be rendered.");
        return null;
    }
    return (React.createElement("div", __assign({ className: classNames }, attrs),
        React.createElement("label", { className: "nx-threat-indicator-legend__header" }, header || 'Legend'),
        critical && React.createElement(ThreatIndicator, { threatType: "critical" }),
        severe && React.createElement(ThreatIndicator, { threatType: "severe" }),
        moderate && React.createElement(ThreatIndicator, { threatType: "moderate" }),
        low && React.createElement(ThreatIndicator, { threatType: "low" }),
        none && React.createElement(ThreatIndicator, { threatType: "none" }),
        unspecified && React.createElement(ThreatIndicator, { threatType: "unspecified" })));
}
NxThreatIndicatorLegend.propTypes = nxThreatIndicatorLegendPropTypes;
export { nxThreatIndicatorLegendPropTypes } from './types';
//# sourceMappingURL=NxThreatIndicatorLegend.js.map