var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { useState } from 'react';
import { initialState, userInput } from '../stateHelpers';
import { PrivateNxTextInput } from '../NxTextInput';
import { propTypes } from './types';
export { propTypes } from './types';
export function PrivateNxStatefulTextInput(props) {
    var defaultValue = props.defaultValue, onChange = props.onChange, validator = props.validator, attrs = __rest(props, ["defaultValue", "onChange", "validator"]), _a = useState(initialState(defaultValue || '', validator)), state = _a[0], setState = _a[1];
    function changeHandler(newValue) {
        setState(userInput(validator || null, newValue));
        if (onChange) {
            onChange(newValue);
        }
    }
    return React.createElement(PrivateNxTextInput, __assign({ validatable: !!validator }, attrs, state, { onChange: changeHandler }));
}
var NxStatefulTextInput = PrivateNxStatefulTextInput;
export default NxStatefulTextInput;
NxStatefulTextInput.propTypes = propTypes;
//# sourceMappingURL=NxStatefulTextInput.js.map