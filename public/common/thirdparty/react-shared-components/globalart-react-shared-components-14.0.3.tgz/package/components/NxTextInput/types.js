var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import * as PropTypes from 'prop-types';
/**
 * The valid values for the `type` Prop
 */
export var publicInputTypes = ['textarea', 'text', 'password'];
export var inputTypes = __spreadArray(__spreadArray([], publicInputTypes, true), ['date'], false);
export var propTypes = {
    type: PropTypes.oneOf(__spreadArray(__spreadArray([], publicInputTypes, true), [undefined], false)),
    value: PropTypes.string.isRequired,
    isPristine: PropTypes.bool.isRequired,
    validationErrors: PropTypes.oneOfType([PropTypes.arrayOf(PropTypes.string.isRequired), PropTypes.string]),
    onChange: PropTypes.func,
    onKeyPress: PropTypes.func,
    validatable: PropTypes.bool,
    inputAttributes: PropTypes.object
};
//# sourceMappingURL=types.js.map