import * as PropTypes from 'prop-types';
import { NxTextInputType, PublicNxTextInputType, DivAttrs, InputAttrs, Validator } from '../types';
export interface Props extends DivAttrs {
    type?: NxTextInputType | null;
    defaultValue?: string | null;
    validator?: Validator;
    onChange?: ((newVal: string) => void) | null;
    onKeyPress?: ((newVal: string) => void) | null;
    disabled?: boolean | null;
    placeholder?: string | null;
    inputAttributes?: InputAttrs;
}
export interface PublicProps extends Props {
    type?: PublicNxTextInputType | null;
}
export declare const propTypes: PropTypes.ValidationMap<PublicProps>;
//# sourceMappingURL=types.d.ts.map