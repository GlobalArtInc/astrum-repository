import { StateProps, Validator } from './types';
/**
 * @return an initialized state with the specified value and isPristine set to true.
 */
export declare function initialState(value: string, validator?: Validator): StateProps;
/**
 * Meant to be used to handle user changes to the text input value.
 *
 * This function is curried, so that it can be partially applied over the validator.
 *
 * Note that the cast of this function is necessary because the current version of the ramda types wrongfully drops
 * the `null` from the Validator union type.
 *
 * @param validator an optional validator function that receives the new input value as a string and returns zero or
 * more validation error messages.
 * @param newValue the new value of the text box after the user's input.
 * @return a state object that is not pristine, with the specified value, and with validationErrorsas computed by the
 * validator function.
 */
export declare const userInput: ((v: Validator | undefined, n: string) => StateProps) & ((v: Validator) => (n: string) => StateProps);
//# sourceMappingURL=stateHelpers.d.ts.map