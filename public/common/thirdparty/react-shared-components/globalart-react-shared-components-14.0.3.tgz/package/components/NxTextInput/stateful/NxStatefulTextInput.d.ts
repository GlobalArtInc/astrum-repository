import React, { FunctionComponent } from 'react';
import { Props, PublicProps } from './types';
export { Props, PublicProps, propTypes } from './types';
export declare function PrivateNxStatefulTextInput(props: Props): React.JSX.Element;
declare const NxStatefulTextInput: FunctionComponent<PublicProps>;
export default NxStatefulTextInput;
//# sourceMappingURL=NxStatefulTextInput.d.ts.map