import React, { FunctionComponent } from 'react';
import './NxTextInput.scss';
import { Props, PublicProps } from './types';
export { Props, PublicProps, StateProps, Validator, propTypes, inputTypes } from './types';
export declare function PrivateNxTextInput(props: Props): React.JSX.Element;
declare const NxTextInput: FunctionComponent<PublicProps>;
export default NxTextInput;
//# sourceMappingURL=NxTextInput.d.ts.map