var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import classnames from 'classnames';
import { useUniqueId } from '../../util/idUtil';
/**
 * A wrapper component around FontAwesomeIcon that adds our nx-icon css class. Takes the same props as FontAwesomeIcon
 */
export default function NxFontAwesomeIcon(props) {
    var className = classnames(props.className, 'nx-icon'), titleId = useUniqueId(''), // FA adds its own prefix to this, no need for us to add one too
    otherProps = props.title ? { titleId: titleId } : undefined;
    return React.createElement(FontAwesomeIcon, __assign({}, otherProps, props, { className: className }));
}
//# sourceMappingURL=NxFontAwesomeIcon.js.map