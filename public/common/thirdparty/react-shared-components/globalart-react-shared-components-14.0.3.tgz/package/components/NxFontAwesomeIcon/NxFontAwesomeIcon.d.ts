import React from 'react';
import { FontAwesomeIconProps as Props } from '@fortawesome/react-fontawesome';
export { Props } from '@fortawesome/react-fontawesome';
/**
 * A wrapper component around FontAwesomeIcon that adds our nx-icon css class. Takes the same props as FontAwesomeIcon
 */
export default function NxFontAwesomeIcon(props: Props): React.JSX.Element;
//# sourceMappingURL=NxFontAwesomeIcon.d.ts.map