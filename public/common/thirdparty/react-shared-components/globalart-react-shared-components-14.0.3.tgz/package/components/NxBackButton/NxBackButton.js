/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import { faChevronLeft } from '@fortawesome/free-solid-svg-icons';
import NxFontAwesomeIcon from '../NxFontAwesomeIcon/NxFontAwesomeIcon';
import './NxBackButton.scss';
import { propTypes } from './types';
export { propTypes } from './types';
/**
 * A standard UI element for navigating back to a previous page
 * @param targetPageTitle The name of the page to navigate to
 * @param text Optional custom text to override the back button's default text logic
 * @param href The URL to navigate to when the back button is clicked
 */
var NxBackButton = function NxBackButton(_a) {
    var targetPageTitle = _a.targetPageTitle, text = _a.text, href = _a.href;
    var linkText = text || (targetPageTitle ? "Back to ".concat(targetPageTitle) : 'Back');
    return (React.createElement("div", { className: "nx-back-button tm-back-button" },
        React.createElement("a", { className: "nx-text-link", href: href },
            React.createElement(NxFontAwesomeIcon, { icon: faChevronLeft }),
            React.createElement("span", null, linkText))));
};
NxBackButton.propTypes = propTypes;
export default NxBackButton;
//# sourceMappingURL=NxBackButton.js.map