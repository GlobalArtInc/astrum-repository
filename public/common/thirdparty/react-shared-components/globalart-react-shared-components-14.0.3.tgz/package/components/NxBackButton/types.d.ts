import * as PropTypes from 'prop-types';
export interface Props {
    targetPageTitle?: string | null;
    text?: string | null;
    href: string;
}
export declare const propTypes: {
    targetPageTitle: PropTypes.Requireable<string>;
    text: PropTypes.Requireable<string>;
    href: PropTypes.Validator<string>;
};
//# sourceMappingURL=types.d.ts.map