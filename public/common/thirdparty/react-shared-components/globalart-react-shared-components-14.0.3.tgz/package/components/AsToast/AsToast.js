var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { useState, useContext, useRef } from 'react';
import classnames from 'classnames';
import AsToastContainerContext from './contexts';
import { asToastPropTypes } from './types';
var AsToast = function (props) {
    var _a;
    var onClose = props.onClose, children = props.children, className = props.className, attrs = __rest(props, ["onClose", "children", "className"]);
    var _b = useState(false), isClosing = _b[0], setIsClosing = _b[1];
    var toastContainerContextValue = useContext(AsToastContainerContext);
    var ref = useRef(null);
    var handleClose = function () {
        if (!isClosing) {
            setIsClosing(true);
            toastContainerContextValue.onToastClosing(ref.current);
        }
    };
    var handleAnimationEnd = function () {
        var _a, _b;
        if (isClosing) {
            onClose();
        }
        else {
            // finished opening
            (_b = (_a = ref.current) === null || _a === void 0 ? void 0 : _a.querySelector('.as-btn--close')) === null || _b === void 0 ? void 0 : _b.focus();
        }
    };
    var validChild = React.Children.only(children), childrenWithProps = React.cloneElement(validChild, {
        onClose: handleClose,
        role: (_a = validChild.props.role) !== null && _a !== void 0 ? _a : 'alert'
    });
    var classes = classnames('as-toast', className, {
        'as-toast--closing': isClosing
    });
    return (React.createElement("div", __assign({ className: classes, onAnimationEnd: handleAnimationEnd, ref: ref }, attrs), childrenWithProps));
};
AsToast.propTypes = asToastPropTypes;
export default AsToast;
//# sourceMappingURL=AsToast.js.map