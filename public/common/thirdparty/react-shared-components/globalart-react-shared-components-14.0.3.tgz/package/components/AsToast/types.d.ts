import { ReactNode, ReactElement, ComponentPropsWithRef } from 'react';
import * as PropTypes from 'prop-types';
type CloseableElementWithRoleProps = Pick<ComponentPropsWithRef<'dialog'>, 'role' | 'onClose'>;
export interface AsToastProps extends ComponentPropsWithRef<'div'> {
    onClose: () => void;
    children: ReactElement<CloseableElementWithRoleProps> | ReactElement<CloseableElementWithRoleProps>[];
}
export declare const asToastPropTypes: PropTypes.ValidationMap<AsToastProps>;
export type AsToastContainerContextType = {
    onToastClosing: (toast: HTMLElement | null) => void;
};
export interface AsToastContainerProps {
    children: ReactNode;
}
export declare const asToastContainerPropTypes: PropTypes.ValidationMap<AsToastContainerProps>;
export {};
//# sourceMappingURL=types.d.ts.map