import React from 'react';
import { AsToastProps } from './types';
export { AsToastProps };
declare const AsToast: {
    (props: AsToastProps): React.JSX.Element;
    propTypes: import("prop-types").ValidationMap<AsToastProps>;
};
export default AsToast;
//# sourceMappingURL=AsToast.d.ts.map