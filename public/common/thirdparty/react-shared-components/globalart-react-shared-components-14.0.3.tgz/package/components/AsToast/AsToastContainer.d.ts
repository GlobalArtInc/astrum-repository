import React from 'react';
import { AsToastContainerProps } from './types';
export { AsToastContainerProps };
import './AsToast.scss';
declare const AsToastContainer: {
    (props: AsToastContainerProps): React.JSX.Element;
    propType: import("prop-types").ValidationMap<AsToastContainerProps>;
};
export default AsToastContainer;
//# sourceMappingURL=AsToastContainer.d.ts.map