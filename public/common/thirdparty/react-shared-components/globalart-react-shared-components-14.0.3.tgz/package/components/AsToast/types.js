import * as PropTypes from 'prop-types';
export var asToastPropTypes = {
    onClose: PropTypes.func.isRequired,
    children: PropTypes.oneOfType([
        PropTypes.arrayOf(PropTypes.element.isRequired).isRequired,
        PropTypes.element.isRequired
    ])
};
export var asToastContainerPropTypes = {
    children: PropTypes.any
};
//# sourceMappingURL=types.js.map