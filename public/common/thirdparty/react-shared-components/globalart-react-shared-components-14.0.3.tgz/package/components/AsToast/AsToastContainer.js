/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { useRef, useEffect } from 'react';
import AsToastContainerContext from './contexts';
import { reject, last } from 'ramda';
import { asToastContainerPropTypes } from './types';
import './AsToast.scss';
var AsToastContainer = function (props) {
    var children = props.children;
    var ref = useRef(null);
    // When all toasts are closed, the focus should return to the last element that received focus that was not
    // a toast element.
    var activeElementNotToast = useRef(null);
    var onToastClosing = function (toast) {
        var _a, _b, _c;
        var closeBtns = Array.from((_b = (_a = ref.current) === null || _a === void 0 ? void 0 : _a.querySelectorAll('.as-toast:not(.as-toast--closing) .as-btn--close')) !== null && _b !== void 0 ? _b : []);
        var filteredButtons = toast ? reject(function (btn) { return toast.contains(btn); }, closeBtns) : closeBtns;
        var lastCloseBtn = last(filteredButtons);
        if (lastCloseBtn) {
            lastCloseBtn.focus();
        }
        else {
            (_c = activeElementNotToast.current) === null || _c === void 0 ? void 0 : _c.focus();
        }
    };
    var updateActiveElementNotToast = function () {
        var _a;
        var currentFocusedElement = document.activeElement;
        if (!((_a = ref.current) === null || _a === void 0 ? void 0 : _a.contains(currentFocusedElement))) {
            activeElementNotToast.current = currentFocusedElement;
        }
    };
    useEffect(function () {
        document.addEventListener('focusin', updateActiveElementNotToast);
        return function () { return document.removeEventListener('focusin', updateActiveElementNotToast); };
    }, []);
    return (React.createElement(AsToastContainerContext.Provider, { value: { onToastClosing: onToastClosing } },
        React.createElement("div", { className: "as-toast-container", ref: ref }, children)));
};
AsToastContainer.propType = asToastContainerPropTypes;
export default AsToastContainer;
//# sourceMappingURL=AsToastContainer.js.map