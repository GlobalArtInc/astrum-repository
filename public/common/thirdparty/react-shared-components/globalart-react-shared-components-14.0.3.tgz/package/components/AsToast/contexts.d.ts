import { AsToastContainerContextType } from './types';
declare const AsToastContainerContext: import("react").Context<AsToastContainerContextType>;
export default AsToastContainerContext;
//# sourceMappingURL=contexts.d.ts.map