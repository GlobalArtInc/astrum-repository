var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { useRef } from 'react';
import classnames from 'classnames';
import { mergeDeepRight } from 'ramda';
import { propTypes } from './types';
import AsFormGroup from '../AsFormGroup/AsFormGroup';
import AsTextInput from '../AsTextInput/AsTextInput';
import AsButton from '../AsButton/AsButton';
import './AsCopyToClipboard.scss';
export default function AsCopyToClipboard(props) {
    var content = props.content, label = props.label, sublabel = props.sublabel, className = props.className, onCopyUsingBtn = props.onCopyUsingBtn, inputProps = props.inputProps, otherProps = __rest(props, ["content", "label", "sublabel", "className", "onCopyUsingBtn", "inputProps"]), classes = classnames('as-copy-to-clipboard', className), textInputRef = useRef(null), inputPropsWithReadOnly = mergeDeepRight(inputProps !== null && inputProps !== void 0 ? inputProps : {}, {
        inputAttributes: { readOnly: true }
    });
    function copyWithNavigatorClipboard() {
        window.navigator.clipboard.writeText(content).then(function () {
            // select all text in the input to help the user understand what happened
            if (textInputRef.current) {
                var textarea = textInputRef.current.querySelector('textarea');
                if (textarea) {
                    textarea.select();
                }
            }
            if (onCopyUsingBtn) {
                onCopyUsingBtn();
            }
        }, function (e) {
            console.error('Error copying to clipboard', e);
        });
    }
    function copyWithExecCommand() {
        if (textInputRef.current) {
            var textarea = textInputRef.current.querySelector('textarea');
            if (textarea) {
                textarea.select();
                var copySuccessful = document.execCommand('copy');
                if (copySuccessful && onCopyUsingBtn) {
                    onCopyUsingBtn();
                }
            }
        }
    }
    function copyToClipboard() {
        // the clipboard object is the modern API, but it is only available in secure contexts (ie https or localhost)
        if (window.navigator.clipboard) {
            copyWithNavigatorClipboard();
        }
        else {
            // document.execCommand works outside of https, but is deprecated and might be deactivated some day
            copyWithExecCommand();
        }
    }
    return (React.createElement("div", __assign({ className: classes }, otherProps),
        React.createElement(AsButton, { type: "button", variant: "tertiary", onClick: copyToClipboard }, "Copy to Clipboard"),
        React.createElement(AsFormGroup, { label: label, sublabel: sublabel },
            React.createElement(AsTextInput, __assign({}, inputPropsWithReadOnly, { ref: textInputRef, type: "textarea", value: content, isPristine: true })))));
}
AsCopyToClipboard.propTypes = propTypes;
//# sourceMappingURL=AsCopyToClipboard.js.map