import React from 'react';
import { Props } from './types';
import './AsCopyToClipboard.scss';
export { Props };
declare function AsCopyToClipboard(props: Props): React.JSX.Element;
declare namespace AsCopyToClipboard {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default AsCopyToClipboard;
//# sourceMappingURL=AsCopyToClipboard.d.ts.map