import * as PropTypes from 'prop-types';
import { Props as AsFormGroupProps } from '../AsFormGroup/types';
import { PublicProps as AsTextInputProps } from '../AsTextInput/types';
export type InternalInputProps = Omit<AsTextInputProps, 'type' | 'value' | 'isPristine'>;
type ExternalInputProps = Omit<InternalInputProps, 'readOnly'>;
export interface Props extends Omit<AsFormGroupProps, 'children' | 'isRequired'> {
    content: string;
    onCopyUsingBtn?: (() => void) | null;
    inputProps?: ExternalInputProps | null;
}
export declare const propTypes: PropTypes.ValidationMap<Props>;
export {};
//# sourceMappingURL=types.d.ts.map