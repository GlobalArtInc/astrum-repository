import React from 'react';
import { Props } from './types';
export { Props };
declare function AsFormGroup({ className, label, sublabel, children, isRequired, ...attrs }: Props): React.JSX.Element;
declare namespace AsFormGroup {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default AsFormGroup;
//# sourceMappingURL=AsFormGroup.d.ts.map