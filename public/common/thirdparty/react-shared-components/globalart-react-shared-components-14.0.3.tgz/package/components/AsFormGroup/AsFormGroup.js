var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import classnames from 'classnames';
import { propTypes } from './types';
import { useUniqueId } from '../../util/idUtil';
export default function AsFormGroup(_a) {
    var _b;
    var className = _a.className, label = _a.label, sublabel = _a.sublabel, children = _a.children, isRequired = _a.isRequired, attrs = __rest(_a, ["className", "label", "sublabel", "children", "isRequired"]);
    var classNames = classnames('as-form-group', className), labelClassnames = classnames('as-label', { 'as-label--optional': !isRequired }), childId = useUniqueId('as-form-group-child', children.props.id), sublabelId = useUniqueId('as-sub-label', sublabel ? undefined : ''), childDescribedBy = classnames(children.props['aria-describedby'], sublabelId), childRequired = (_b = children.props['aria-required']) !== null && _b !== void 0 ? _b : isRequired, childNeedsAugmentation = !children.props.id || sublabelId || (isRequired && !children.props['aria-required']), childEl = childNeedsAugmentation ?
        React.cloneElement(children, {
            id: childId,
            'aria-describedby': childDescribedBy,
            'aria-required': childRequired
        }) :
        children;
    return (React.createElement("div", __assign({ className: classNames }, attrs),
        React.createElement("label", { htmlFor: childId, className: labelClassnames },
            React.createElement("span", { className: "as-label__text" }, label)),
        sublabel && React.createElement("div", { id: sublabelId, className: "as-sub-label" }, sublabel),
        childEl));
}
AsFormGroup.propTypes = propTypes;
//# sourceMappingURL=AsFormGroup.js.map