import * as PropTypes from 'prop-types';
import { ComponentPropsWithRef } from 'react';
export declare const AS_PROGRESS_BAR_VARIANTS: readonly ["inline", "small", "normal", "full"];
export type AS_PROGRESS_BAR_VARIANT_TYPE = (typeof AS_PROGRESS_BAR_VARIANTS)[number];
export interface StepsProps {
    max: number;
    value: number;
}
export interface Props extends Omit<ComponentPropsWithRef<'progress'>, 'value' | 'max'> {
    inlineCounter?: boolean | null;
    label: string;
    labelSuccess?: string | null;
    labelError?: string | null;
    max?: number | null;
    showCounter?: boolean | null;
    showSteps?: boolean | null;
    value: number;
    variant?: AS_PROGRESS_BAR_VARIANT_TYPE | null;
}
export declare const propTypes: PropTypes.ValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map