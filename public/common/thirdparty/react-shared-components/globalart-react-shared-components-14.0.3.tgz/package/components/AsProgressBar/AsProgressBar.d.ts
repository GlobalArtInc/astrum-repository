import React from 'react';
import { Props } from './types';
import './AsProgressBar.scss';
declare function AsProgressBar(props: Props): React.JSX.Element;
declare namespace AsProgressBar {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default AsProgressBar;
export { Props } from './types';
//# sourceMappingURL=AsProgressBar.d.ts.map