import { FunctionComponent } from 'react';
import { Props } from './types';
import './AsGlobalSidebar2.scss';
declare const AsGlobalSidebar2: FunctionComponent<Props>;
export default AsGlobalSidebar2;
export { Props, propTypes } from './types';
//# sourceMappingURL=AsGlobalSidebar2.d.ts.map