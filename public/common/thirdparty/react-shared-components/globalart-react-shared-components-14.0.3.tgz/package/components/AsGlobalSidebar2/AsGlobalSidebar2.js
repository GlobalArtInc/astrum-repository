/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import classnames from 'classnames';
import AsButton from '../AsButton/AsButton';
import AsOverflowTooltip from '../AsTooltip/AsOverflowTooltip';
import AsFontAwesomeIcon from '../AsFontAwesomeIcon/AsFontAwesomeIcon';
import { useUniqueId } from '../../util/idUtil';
import { propTypes } from './types';
import './AsGlobalSidebar2.scss';
var AsGlobalSidebar2 = function AsGlobalSidebar(props) {
    var isOpen = props.isOpen, children = props.children, className = props.className, toggleOpenIcon = props.toggleOpenIcon, toggleCloseIcon = props.toggleCloseIcon, onToggleClick = props.onToggleClick;
    var id = useUniqueId('as-global-sidebar-2');
    var classes = classnames(className, 'as-global-sidebar-2 as-viewport-sized', {
        'open': isOpen,
        'closed': !isOpen
    });
    var toggleButtonIcon = isOpen ? toggleOpenIcon : toggleCloseIcon;
    return (React.createElement("div", { className: classes, id: id },
        React.createElement("nav", { className: "as-global-sidebar-2__nav as-scrollable as-viewport-sized__scrollable", "aria-label": "global sidebar" }, children),
        React.createElement(AsOverflowTooltip, null,
            React.createElement(AsButton, { "aria-expanded": isOpen, "aria-controls": id, onClick: onToggleClick, className: "as-global-sidebar-2__toggle" },
                React.createElement(AsFontAwesomeIcon, { icon: toggleButtonIcon, fixedWidth: true }),
                React.createElement("span", { className: "as-global-sidebar-2__text" },
                    isOpen ? 'Collapse' : 'Expand',
                    " Menu")))));
};
AsGlobalSidebar2.propTypes = propTypes;
export default AsGlobalSidebar2;
export { propTypes } from './types';
//# sourceMappingURL=AsGlobalSidebar2.js.map