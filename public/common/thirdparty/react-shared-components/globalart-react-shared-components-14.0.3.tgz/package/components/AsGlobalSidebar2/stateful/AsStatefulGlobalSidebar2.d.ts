import { FunctionComponent } from 'react';
import { Props } from './types';
declare const AsStatefulGlobalSidebar2: FunctionComponent<Props>;
export default AsStatefulGlobalSidebar2;
export { Props, propTypes } from './types';
//# sourceMappingURL=AsStatefulGlobalSidebar2.d.ts.map