var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import classnames from 'classnames';
import AsFontAwesomeIcon from '../AsFontAwesomeIcon/AsFontAwesomeIcon';
import AsOverflowTooltip from '../AsTooltip/AsOverflowTooltip';
import { asGlobalSidebar2NavigationLinkPropTypes } from './types';
import './AsGlobalSidebar2NavigationLink.scss';
var AsGlobalSidebarNavigationLink = function AsNavigationSidebarLink(props) {
    var className = props.className, isSelected = props.isSelected, icon = props.icon, text = props.text, attrs = __rest(props, ["className", "isSelected", "icon", "text"]);
    var classes = classnames(className, 'as-global-sidebar-2__navigation-link as-text-link', {
        'selected': isSelected
    });
    return (React.createElement(AsOverflowTooltip, null,
        React.createElement("a", __assign({ className: classes }, attrs),
            React.createElement(AsFontAwesomeIcon, { icon: icon, fixedWidth: true }),
            React.createElement("span", { className: "as-global-sidebar-2__text" }, text))));
};
AsGlobalSidebarNavigationLink.propTypes = asGlobalSidebar2NavigationLinkPropTypes;
export default AsGlobalSidebarNavigationLink;
//# sourceMappingURL=AsGlobalSidebar2NavigationLink.js.map