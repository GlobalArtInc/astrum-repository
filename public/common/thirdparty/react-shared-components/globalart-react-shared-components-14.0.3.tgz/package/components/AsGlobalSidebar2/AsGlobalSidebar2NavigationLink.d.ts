import { FunctionComponent } from 'react';
import { AsGlobalSidebar2NavigationLinkProps as Props } from './types';
export { AsGlobalSidebar2NavigationLinkProps } from './types';
import './AsGlobalSidebar2NavigationLink.scss';
declare const AsGlobalSidebarNavigationLink: FunctionComponent<Props>;
export default AsGlobalSidebarNavigationLink;
//# sourceMappingURL=AsGlobalSidebar2NavigationLink.d.ts.map