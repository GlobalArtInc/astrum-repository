import * as PropTypes from 'prop-types';
// generic props omitted due to type checking issues
export var propTypes = {
    label: PropTypes.node.isRequired,
    filterValue: PropTypes.string.isRequired,
    onFilterChange: PropTypes.func.isRequired,
    isSelected: PropTypes.bool,
    onItemChange: PropTypes.func,
    footerContent: PropTypes.node.isRequired,
    filterFn: PropTypes.func,
    showMoveAll: PropTypes.bool,
    onMoveAll: PropTypes.func,
    allowReordering: PropTypes.bool,
    onReorderItem: PropTypes.func
};
//# sourceMappingURL=types.js.map