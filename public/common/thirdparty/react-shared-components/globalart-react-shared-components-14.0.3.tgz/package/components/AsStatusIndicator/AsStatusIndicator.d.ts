import React from 'react';
import { Props } from './types';
export declare const AsNegativeStatusIndicator: ({ className, ...otherProps }: Props) => React.JSX.Element;
export declare const AsPositiveStatusIndicator: ({ className, ...otherProps }: Props) => React.JSX.Element;
export declare const AsIntermediateStatusIndicator: ({ className, ...otherProps }: Props) => React.JSX.Element;
export declare const AsErrorStatusIndicator: ({ className, ...otherProps }: Props) => React.JSX.Element;
//# sourceMappingURL=AsStatusIndicator.d.ts.map