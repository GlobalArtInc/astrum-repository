import React from 'react';
import { Props } from './types';
import './AsSmallTag.scss';
export { Props } from './types';
declare function AsSmallTag(props: Props): React.JSX.Element;
declare namespace AsSmallTag {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default AsSmallTag;
//# sourceMappingURL=AsSmallTag.d.ts.map