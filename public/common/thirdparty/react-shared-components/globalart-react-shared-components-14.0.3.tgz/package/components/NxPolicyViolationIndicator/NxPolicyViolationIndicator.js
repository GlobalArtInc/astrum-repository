var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import classnames from 'classnames';
import { faExclamationCircle } from '@fortawesome/free-solid-svg-icons';
import { categoryByPolicyThreatLevel } from '../../util/threatLevels';
import NxFontAwesomeIcon from '../NxFontAwesomeIcon/NxFontAwesomeIcon';
import { propTypes } from './types';
import './NxPolicyViolationIndicator.scss';
export default function NxPolicyViolationIndicator(props) {
    var threatLevelCategory = props.threatLevelCategory, policyThreatLevel = props.policyThreatLevel, className = props.className, children = props.children, attrs = __rest(props, ["threatLevelCategory", "policyThreatLevel", "className", "children"]);
    var category = threatLevelCategory ? threatLevelCategory :
        policyThreatLevel != null ? categoryByPolicyThreatLevel[policyThreatLevel] :
            'unspecified', classNames = classnames("nx-policy-violation-indicator nx-policy-violation-indicator--".concat(category), className), label = "threat level ".concat(category);
    return (React.createElement("div", __assign({ className: classNames }, attrs),
        React.createElement("span", { className: "nx-policy-violation-indicator__badge" },
            React.createElement(NxFontAwesomeIcon, { "aria-hidden": false, "aria-label": label, icon: faExclamationCircle })),
        React.createElement("span", { className: "nx-policy-violation-indicator__text" }, children || category)));
}
NxPolicyViolationIndicator.propTypes = propTypes;
//# sourceMappingURL=NxPolicyViolationIndicator.js.map