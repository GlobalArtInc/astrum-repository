import * as PropTypes from 'prop-types';
import { ComponentPropsWithRef } from 'react';
import { ThreatLevelNumber, ThreatLevelCategory } from '../../util/threatLevels';
export interface Props extends ComponentPropsWithRef<'div'> {
    threatLevelCategory?: ThreatLevelCategory;
    policyThreatLevel?: ThreatLevelNumber;
    children?: string | null;
}
export declare const propTypes: PropTypes.WeakValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map