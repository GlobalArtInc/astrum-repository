import React from 'react';
import { Props } from './types';
export { Props } from './types';
import './NxPolicyViolationIndicator.scss';
declare function NxPolicyViolationIndicator(props: Props): React.JSX.Element;
declare namespace NxPolicyViolationIndicator {
    var propTypes: import("prop-types").WeakValidationMap<Props>;
}
export default NxPolicyViolationIndicator;
//# sourceMappingURL=NxPolicyViolationIndicator.d.ts.map