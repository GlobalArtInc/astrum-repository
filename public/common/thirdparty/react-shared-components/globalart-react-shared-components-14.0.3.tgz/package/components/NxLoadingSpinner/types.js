import * as PropTypes from 'prop-types';
export var propTypes = {
    children: PropTypes.node
};
//# sourceMappingURL=types.js.map