import { ReactNode } from 'react';
import * as PropTypes from 'prop-types';
export type Props = {
    children?: ReactNode;
    'aria-label'?: string;
};
export declare const propTypes: PropTypes.ValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map