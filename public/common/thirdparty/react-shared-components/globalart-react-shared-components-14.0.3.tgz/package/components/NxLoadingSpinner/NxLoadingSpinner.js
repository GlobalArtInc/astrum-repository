/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import { faCircleNotch } from '@fortawesome/free-solid-svg-icons';
import { propTypes } from './types';
export { propTypes } from './types';
import NxFontAwesomeIcon from '../NxFontAwesomeIcon/NxFontAwesomeIcon';
import './NxLoadingSpinner.scss';
var NxLoadingSpinner = function NxLoadingSpinner(_a) {
    var children = _a.children, ariaLabel = _a["aria-label"];
    return (React.createElement("div", { role: "status", className: "nx-loading-spinner", "aria-label": ariaLabel },
        React.createElement(NxFontAwesomeIcon, { icon: faCircleNotch, className: "fa-spin nx-loading-spinner__icon" }),
        React.createElement("span", null, children || 'Loading…')));
};
NxLoadingSpinner.propTypes = propTypes;
export default NxLoadingSpinner;
//# sourceMappingURL=NxLoadingSpinner.js.map