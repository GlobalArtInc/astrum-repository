import { FunctionComponent } from 'react';
import { Props } from './types';
export { Props, propTypes } from './types';
import './NxLoadingSpinner.scss';
declare const NxLoadingSpinner: FunctionComponent<Props>;
export default NxLoadingSpinner;
//# sourceMappingURL=NxLoadingSpinner.d.ts.map