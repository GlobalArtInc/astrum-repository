import React from 'react';
import { Props } from './types';
declare function NxButton({ variant, className, children, title: titleProp, disabled, ...attrs }: Props): React.JSX.Element;
declare namespace NxButton {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default NxButton;
export { Props, propTypes } from './types';
//# sourceMappingURL=NxButton.d.ts.map