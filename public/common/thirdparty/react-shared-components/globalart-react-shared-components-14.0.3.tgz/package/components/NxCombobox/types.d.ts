import * as PropTypes from 'prop-types';
import { ComponentPropsWithRef, ReactNode } from 'react';
import DataItem from '../../util/DataItem';
export type DataItemType<T extends string | number | DataItem<string | number, string>> = T extends string | number ? DataItem<T, string> : T;
type FilterInputType = boolean | 'search';
export interface Props<T extends string | number | DataItem<string | number, string> = string> extends Omit<ComponentPropsWithRef<'div'>, 'onChange'> {
    value: string;
    loading?: boolean | null;
    loadError?: ReactNode;
    matches: DataItemType<T>[];
    onSearch: (s: string) => void;
    onChange: (s: string, item?: DataItemType<T>) => void;
    itemTooltip?: ((item: DataItemType<T>) => ReactNode) | null;
    disabled?: boolean | null;
    emptyMessage?: ReactNode;
    autoComplete?: boolean | null;
    validatable?: boolean | null;
    isPristine?: boolean | null;
    validationErrors?: string | string[] | null;
    filterInput?: FilterInputType | null;
}
export declare const propTypes: PropTypes.ValidationMap<Props<DataItem<string | number, string>>>;
export {};
//# sourceMappingURL=types.d.ts.map