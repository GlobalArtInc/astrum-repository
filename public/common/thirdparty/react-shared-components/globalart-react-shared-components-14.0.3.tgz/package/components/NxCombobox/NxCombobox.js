var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { useEffect, useRef, useState } from 'react';
import classnames from 'classnames';
import { always, dec, head, inc, tail, omit } from 'ramda';
import usePrevious from '../../util/usePrevious';
import './NxCombobox.scss';
import { propTypes } from './types';
import NxTextInput from '../NxTextInput/NxTextInput';
import NxDropdownMenu from '../NxDropdownMenu/NxDropdownMenu';
import NxLoadError from '../NxLoadError/NxLoadError';
import NxLoadingSpinner from '../NxLoadingSpinner/NxLoadingSpinner';
import { useUniqueId } from '../../util/idUtil';
import NxTooltip from '../NxTooltip/NxTooltip';
import NxFilterInput from '../NxFilterInput/NxFilterInput';
var SELECTION_POLL_INTERVAL = 100;
export default function NxCombobox(props) {
    var _a;
    var classNameProp = props.className, loading = props.loading, loadError = props.loadError, matches = props.matches, value = props.value, onChange = props.onChange, onSearch = props.onSearch, itemTooltip = props.itemTooltip, disabled = props.disabled, emptyMessage = props.emptyMessage, autoComplete = props.autoComplete, validatable = props.validatable, isPristine = props.isPristine, validationErrors = props.validationErrors, filterInput = props.filterInput, id = props.id, ariaRequired = props["aria-required"], ariaDescribedBy = props["aria-describedby"], ariaLabel = props["aria-label"], attrs = __rest(props, ["className", "loading", "loadError", "matches", "value", "onChange", "onSearch", "itemTooltip", "disabled", "emptyMessage", "autoComplete", "validatable", "isPristine", "validationErrors", "filterInput", "id", 'aria-required', 'aria-describedby', 'aria-label']), previousValue = usePrevious(value), newAttrs = omit(['trimmedValue'], attrs), // eslint-disable-line @typescript-eslint/no-explicit-any
    // A state variable tracking when a selection is made from the dropdown. This state helps close the dropdown
    // when a selection is made, and re-open when the input receives focus
    _b = useState(false), hiddenBySelection = _b[0], setHiddenBySelection = _b[1], _c = useState(null), focusableBtnIndex = _c[0], setFocusableBtnIndex = _c[1], _d = useState(false), inputIsFocused = _d[0], setInputIsFocused = _d[1], inputVal = autoComplete && focusableBtnIndex !== null && matches.length
        ? matches[focusableBtnIndex].displayName
        : value, isEmpty = !matches.length, showEmptyMessage = isEmpty && value.length, isAlert = (loading || loadError || showEmptyMessage) && !hiddenBySelection && inputIsFocused, dropdownRef = useRef(null), inputRef = useRef(null), alertRef = useRef(null), showDropdown = !disabled && !isEmpty && !hiddenBySelection && inputIsFocused, showAlert = !!(!disabled && isAlert && value), inputId = useUniqueId('nx-combobox-input', id), alertDropdownId = useUniqueId('nx-combobox-alert-dropdown'), dropdownId = useUniqueId('nx-combobox-dropdown'), dropdownBtnIdPrefix = useUniqueId('nx-dropdown-button'), focusableBtnId = focusableBtnIndex !== null ?
        getDropdownBtnIdForIndex(focusableBtnIndex) : undefined, className = classnames('nx-combobox', classNameProp), alertClassName = classnames('nx-combobox__alert', {
        'nx-combobox__alert--error': !!loadError
    }), inputDescribedby = classnames(ariaDescribedBy, (_a = {},
        _a[alertDropdownId] = showAlert,
        _a)), TextInput = filterInput ? NxFilterInput : NxTextInput, filterInputProps = filterInput === 'search' ? { searchIcon: true } : null, _e = useState(true), pageIsFocused = _e[0], setPageIsFocused = _e[1];
    // There is a requirement that when there is an error querying the data, if the user navigates away from
    // the component and then comes back to it the search should be retried automatically
    function handleComponentFocus(evt) {
        setInputIsFocused(true);
        if (loadError) {
            // check if this is focus coming into the component from somewhere else on the page, not just moving between
            // children of this component and not from focus coming into the browser from some other window
            var comingFromOutsidePage = pageIsFocused === false, comingFromChildNode = evt.relatedTarget instanceof Node && evt.currentTarget.contains(evt.relatedTarget);
            if (!(comingFromOutsidePage || comingFromChildNode)) {
                doSearch(value);
            }
        }
        setPageIsFocused(document.hasFocus());
        setHiddenBySelection(false);
    }
    function handleComponentBlur(evt) {
        setPageIsFocused(document.hasFocus());
        if (!(evt.relatedTarget instanceof Node && evt.currentTarget.contains(evt.relatedTarget))) {
            setInputIsFocused(false);
            // The automatically selected suggestion becomes the value of the combobox
            // when the combobox loses focus.
            if (autoComplete && focusableBtnIndex !== null) {
                var elToFocusMatch = matches[focusableBtnIndex];
                handleSelection(elToFocusMatch.displayName, elToFocusMatch);
            }
            setFocusableBtnIndex(null);
        }
    }
    function getDropdownBtnIdForIndex(idx) {
        return "".concat(dropdownBtnIdPrefix, "-").concat(idx);
    }
    function handleOnChange(newVal) {
        setFocusableBtnIndex(null);
        onChange(newVal);
        setHiddenBySelection(false);
        if (newVal.toLowerCase() !== value.toLowerCase()) {
            doSearch(newVal);
        }
    }
    function doSearch(val) {
        focusTextInput();
        onSearch(val);
    }
    function focusTextInput() {
        var _a;
        (_a = inputRef.current) === null || _a === void 0 ? void 0 : _a.focus();
    }
    // A function that listens for when a selection is made, therefore passing both the displayName and DataItem to the
    // onChange function, and closing the dropdown menu. This function should only be used when a selection is made,
    // either by direct selection or when autocomplete triggers a selection from the input losing focus.
    function handleSelection(displayName, dataItem) {
        onChange(displayName, dataItem);
        setHiddenBySelection(true);
    }
    function handleDropdownBtnClick(item) {
        var displayName = item.displayName;
        focusTextInput();
        handleSelection(displayName, item);
        onSearch(displayName);
        setFocusableBtnIndex(null);
    }
    // helper for focusing different buttons in the dropdown menu
    var adjustBtnFocus = function (adjust) { return function () {
        var _a;
        var newFocusableBtnIndex = adjust(focusableBtnIndex !== null && focusableBtnIndex !== void 0 ? focusableBtnIndex : 0), elToFocus = (_a = dropdownRef.current) === null || _a === void 0 ? void 0 : _a.children[newFocusableBtnIndex];
        if (elToFocus) {
            var match = matches[newFocusableBtnIndex];
            setFocusableBtnIndex(newFocusableBtnIndex);
            onChange(match.displayName, match);
            elToFocus.scrollIntoView({ block: 'nearest' });
        }
    }; }, focusNext = adjustBtnFocus(inc), focusPrev = adjustBtnFocus(dec), focusFirst = adjustBtnFocus(always(0)), focusLast = adjustBtnFocus(always(matches.length - 1));
    function handleKeyDown(evt) {
        var inputEle = evt.currentTarget, elToFocusText = matches.length && focusableBtnIndex !== null ? matches[focusableBtnIndex].displayName : null, endIndex = autoComplete && elToFocusText ? elToFocusText.length : value.length;
        switch (evt.key) {
            case 'Enter':
                if (focusableBtnIndex !== null) {
                    handleDropdownBtnClick(matches[focusableBtnIndex]);
                    inputEle.setSelectionRange(endIndex, endIndex);
                }
                evt.preventDefault();
                break;
            case 'Home':
                inputEle.setSelectionRange(0, 0);
                evt.preventDefault();
                break;
            case 'End':
                inputEle.setSelectionRange(endIndex, endIndex);
                evt.preventDefault();
                break;
            case 'ArrowDown':
                if (focusableBtnIndex === null || focusableBtnIndex === matches.length - 1) {
                    focusFirst();
                }
                else {
                    focusNext();
                }
                evt.preventDefault();
                break;
            case 'ArrowUp':
                if (focusableBtnIndex) {
                    focusPrev();
                }
                else {
                    focusLast();
                }
                evt.preventDefault();
                break;
            case 'Escape':
                setFocusableBtnIndex(null);
                // NxFilterInput handles this itself
                if (!filterInput) {
                    handleOnChange('');
                    if (value !== '') {
                        // only prevent default if the ESC actually made a difference here
                        evt.preventDefault();
                    }
                }
                break;
        }
    }
    function isInputFocused() {
        var input = inputRef.current;
        return input && document.activeElement === input;
    }
    // When autocomplete occurs we want to update the value to match the case (e.g. uppercase/lowercase) of the
    // corresponding part of the autocompleted option
    function updateValueCase() {
        if (focusableBtnIndex != null) {
            var newValue = matches[focusableBtnIndex].displayName.slice(0, value.length);
            if (newValue !== value) {
                onChange(newValue);
            }
        }
    }
    // We don't want to activate autocomplete when the user is backspacing or otherwise only deleting parts
    // of the value, so we must check when a new value is the same as the old one except with parts missing
    function isValueSameWithOmissions() {
        if (previousValue == null) {
            return false;
        }
        var remainingPrev = previousValue, remainingNew = value;
        for (; remainingPrev.length && remainingNew.length; remainingPrev = tail(remainingPrev)) {
            if (head(remainingNew) === head(remainingPrev)) {
                remainingNew = tail(remainingNew);
            }
        }
        return remainingNew.length === 0;
    }
    /*
     * Check that the user has not manually adjusted/cleared the text selection. If they have, update the
     * value to match the full text
     */
    function checkSelection() {
        var input = inputRef.current;
        if (input && (input.selectionStart !== value.length || input.selectionEnd !== inputVal.length)) {
            onChange(inputVal);
        }
    }
    useEffect(function () {
        // Highlight the portion of the selected suggestion that has not been typed by the user and display
        // a completion string inline after the input cursor in the input box.
        if (!loading && matches.length && autoComplete && focusableBtnIndex != null && isInputFocused()) {
            var input = inputRef.current, firstOptVal = matches[focusableBtnIndex].displayName, 
            // we only want to update the selection if nothing is currently selected and the caret is at
            // the end
            selectionIsAtEnd = (input === null || input === void 0 ? void 0 : input.selectionStart) === inputVal.length && (input === null || input === void 0 ? void 0 : input.selectionEnd) === inputVal.length;
            if (selectionIsAtEnd) {
                input === null || input === void 0 ? void 0 : input.setSelectionRange(value.length, firstOptVal.length);
                updateValueCase();
            }
        }
    }, [matches, value, autoComplete, loading, inputVal, focusableBtnIndex]);
    useEffect(function () {
        if (loading) {
            setFocusableBtnIndex(null);
        }
        else if (matches.length && autoComplete && !isValueSameWithOmissions() && isInputFocused()) {
            // Note: this needs to use the function setter syntax so that this useEffect is not dependent on
            // focusableBtnIndex - we don't want this logic executing every time focusableBtnIndex changes
            setFocusableBtnIndex(function (focusableBtnIndex) { return focusableBtnIndex !== null && focusableBtnIndex !== void 0 ? focusableBtnIndex : 0; });
        }
    }, [value, loading, matches, autoComplete]);
    useEffect(function () {
        var interval = null;
        if (value && autoComplete && focusableBtnIndex === 0 && value !== inputVal) {
            // Note: in upcoming specs and future browser versions there should be a selectionchange event that we can
            // listen to rather than polling
            interval = window.setInterval(checkSelection, SELECTION_POLL_INTERVAL);
        }
        return function () {
            if (interval !== null) {
                window.clearInterval(interval);
            }
        };
    }, [value, autoComplete, focusableBtnIndex, inputVal]);
    return (React.createElement("div", __assign({ className: className, onFocus: handleComponentFocus, onBlur: handleComponentBlur }, newAttrs),
        React.createElement(TextInput, __assign({ ref: function (div) { var _a; inputRef.current = ((_a = div === null || div === void 0 ? void 0 : div.querySelector('input')) !== null && _a !== void 0 ? _a : null); }, validationErrors: validationErrors, validatable: validatable, isPristine: !!isPristine, className: "nx-combobox__input", value: inputVal, onChange: handleOnChange, onClick: function () { return setHiddenBySelection(false); }, disabled: disabled || undefined, id: inputId, "aria-required": ariaRequired, "aria-describedby": inputDescribedby, inputAttributes: {
                role: 'combobox',
                onKeyDown: handleKeyDown,
                'aria-autocomplete': autoComplete ? 'both' : 'list',
                'aria-expanded': showDropdown,
                'aria-controls': showDropdown ? dropdownId : undefined,
                'aria-activedescendant': focusableBtnId,
                'aria-label': ariaLabel,
                // disable browser autocomplete
                autoComplete: 'off'
            } }, filterInputProps)),
        isAlert ?
            React.createElement("div", { id: alertDropdownId, role: "alert", ref: alertRef, "aria-busy": !!loading, "aria-live": "polite", className: alertClassName }, loadError ? React.createElement(NxLoadError, { role: "none", error: loadError, retryHandler: function () { return doSearch(value); } }) :
                loading ? React.createElement(NxLoadingSpinner, null) :
                    showEmptyMessage && React.createElement("div", { className: "nx-combobox__empty-message" }, emptyMessage || 'No Results Found'))
            : showDropdown &&
                React.createElement(NxDropdownMenu, { id: dropdownId, role: "listbox", ref: dropdownRef, className: "nx-combobox__menu", onClosing: function () { }, "aria-label": "listbox of combobox" }, matches.length && matches.map(function (match, i) {
                    var _a;
                    return React.createElement(NxTooltip, { key: match.id, title: (_a = itemTooltip === null || itemTooltip === void 0 ? void 0 : itemTooltip(match)) !== null && _a !== void 0 ? _a : '' },
                        React.createElement("button", { type: "button", id: getDropdownBtnIdForIndex(i), role: "option", "aria-selected": i === focusableBtnIndex, className: classnames('nx-dropdown-button', { 'selected': i === focusableBtnIndex }), tabIndex: -1, onClick: function () { return handleDropdownBtnClick(match); }, 
                            // In Safari, focus seems to be intended to strictly be a keyboard nav thing,
                            // and when you click a button, focus does NOT go to that button, it goes to the <body>.
                            // This messes up our idea of only showing the menu when something within the component has
                            // focus, because this means that the component loses focus in the middle of the click,
                            // causing the menu to hide while the user is in the middle of clicking,
                            // causing the click not to register at all.
                            // Using preventDefault on onMouseDown seem to have prevent the focus from going to the <body>.
                            onMouseDown: function (event) {
                                event.preventDefault();
                                event.currentTarget.focus();
                            } }, match.displayName));
                }))));
}
NxCombobox.propTypes = propTypes;
//# sourceMappingURL=NxCombobox.js.map