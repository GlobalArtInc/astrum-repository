/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import * as PropTypes from 'prop-types';
export var propTypes = {
    value: PropTypes.string.isRequired,
    loading: PropTypes.bool,
    loadError: PropTypes.node,
    matches: PropTypes.arrayOf(PropTypes.shape({
        id: PropTypes.oneOfType([PropTypes.string.isRequired, PropTypes.number.isRequired]).isRequired,
        displayName: PropTypes.string.isRequired
    }).isRequired).isRequired,
    onSearch: PropTypes.func.isRequired,
    onChange: PropTypes.func.isRequired,
    itemTooltip: PropTypes.func,
    disabled: PropTypes.bool,
    emptyMessage: PropTypes.node,
    autoComplete: PropTypes.bool,
    validatable: PropTypes.bool,
    isPristine: PropTypes.bool,
    validationErrors: PropTypes.oneOfType([PropTypes.arrayOf(PropTypes.string.isRequired), PropTypes.string]),
    filterInput: PropTypes.oneOf([true, false, 'search'])
};
//# sourceMappingURL=types.js.map