import React from 'react';
import './NxCombobox.scss';
import { Props } from './types';
import DataItem from '../../util/DataItem';
export { Props } from './types';
declare function NxCombobox<T extends string | number | DataItem<string | number, string> = string>(props: Props<T>): React.JSX.Element;
declare namespace NxCombobox {
    var propTypes: import("prop-types").ValidationMap<Props<DataItem<string | number, string>>>;
}
export default NxCombobox;
//# sourceMappingURL=NxCombobox.d.ts.map