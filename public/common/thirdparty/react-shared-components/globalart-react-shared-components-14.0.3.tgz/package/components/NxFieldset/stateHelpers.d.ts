import { RadioValidator, CheckboxValidator, TransferListValidator, RadioSetter, CheckboxState, CheckboxInitValues, CheckboxStates, RadioStateProps, CheckboxStateProps, TransferListStateProps, CheckboxGroupHookReturnValue, TransferListHookReturnValue } from './types';
export { RadioValidator, CheckboxValidator, TransferListValidator, RadioSetter, CheckboxState, CheckboxInitValues, CheckboxStates, RadioStateProps, CheckboxStateProps, TransferListStateProps, CheckboxGroupHookReturnValue, TransferListHookReturnValue };
/**
 * Create a RadioStateProps representing the initial state of a group of radio buttons based on the
 * specified initial value, and validated according to the specified validator
 */
export declare function radioGroupInitialState<T extends string = string>(value?: T, validator?: RadioValidator): RadioStateProps<T>;
/**
 * Create a RadioStateProps representing a non-initial state of a group of radio buttons based on the
 * specified value, and validated according to the specified validator
 */
export declare function radioGroupUserInput<T extends string = string>(value: T | null, validator?: RadioValidator): RadioStateProps<T>;
/**
 * A react hook to aid in managing the state of a radio group. Encapsulates tracking of pristine state and
 * validation errors
 */
export declare function useRadioGroupState<T extends string = string>(initialValue?: T, validator?: RadioValidator): [RadioStateProps<T>, RadioSetter<T>];
/**
 * Create a CheckboxStateProps representing the initial state of a group of checkboxes based on the
 * specified initial values, and validated according to the specified validator
 */
export declare function checkboxGroupInitialState<T extends string = string>(values?: T[], validator?: CheckboxValidator): CheckboxStateProps<T>;
/**
 * Create a CheckboxStateProps representing a non-initial state of a group of checkboxes based on the
 * specified value, and validated according to the specified validator
 */
export declare function checkboxGroupUserInput<T extends string = string>({ values }: CheckboxStateProps<T>, toggledValue: T, validator?: CheckboxValidator): CheckboxStateProps<T>;
/**
 * A react hook to aid in managing the state of a checkbox group. Takes an object mapping state names (i.e. checkbox
 * names) to the initial values for those checkboxes, along with an optional validator function, and returns
 * an object containing React state values and setters (as if from useState) for each checkbox along with isPristine and
 * validationErrors
 */
export declare function useCheckboxGroupState<K extends string>(initialValues: CheckboxInitValues<K>, validator?: CheckboxValidator): CheckboxGroupHookReturnValue<K>;
/**
 * Create a TransferListStateProps representing the initial state, selectedItem value,
 * and validated according to the specified validator
 */
export declare function transferListInitialState<K>(selectedItems: K, validator?: TransferListValidator<K>): TransferListStateProps<K>;
/**
 * Create a TransferListStateProps representing a non-initial selectedItems value
 * and validated according to the specified validator
 */
export declare function transferListUserInput<K>(newSelectedItems: K, validator?: TransferListValidator<K>): TransferListStateProps<K>;
export declare function useTransferListState<K>(initialValue: K, validator?: TransferListValidator<K>): TransferListHookReturnValue<K>;
//# sourceMappingURL=stateHelpers.d.ts.map