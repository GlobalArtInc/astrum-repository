/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import { useState } from 'react';
import { append, filter, head, map, toPairs, without } from 'ramda';
import useToggle from '../../util/useToggle';
/**
 * Create a RadioStateProps representing the initial state of a group of radio buttons based on the
 * specified initial value, and validated according to the specified validator
 */
export function radioGroupInitialState(value, validator) {
    var normalizedValue = value !== null && value !== void 0 ? value : null;
    return {
        value: normalizedValue,
        isPristine: true,
        validationErrors: validator ? validator(normalizedValue) : null
    };
}
/**
 * Create a RadioStateProps representing a non-initial state of a group of radio buttons based on the
 * specified value, and validated according to the specified validator
 */
export function radioGroupUserInput(value, validator) {
    return {
        value: value,
        isPristine: false,
        validationErrors: validator ? validator(value) : null
    };
}
/**
 * A react hook to aid in managing the state of a radio group. Encapsulates tracking of pristine state and
 * validation errors
 */
export function useRadioGroupState(initialValue, validator) {
    var _a = useState(radioGroupInitialState(initialValue, validator)), state = _a[0], setState = _a[1], setter = function (v) { setState(radioGroupUserInput(v, validator)); };
    return [state, setter];
}
/**
 * Create a CheckboxStateProps representing the initial state of a group of checkboxes based on the
 * specified initial values, and validated according to the specified validator
 */
export function checkboxGroupInitialState(values, validator) {
    if (values === void 0) { values = []; }
    return {
        values: values,
        isPristine: true,
        validationErrors: validator ? validator(values) : null
    };
}
/**
 * Create a CheckboxStateProps representing a non-initial state of a group of checkboxes based on the
 * specified value, and validated according to the specified validator
 */
export function checkboxGroupUserInput(_a, toggledValue, validator) {
    var values = _a.values;
    var newValues = values.includes(toggledValue) ?
        without([toggledValue], values) :
        append(toggledValue, values);
    return {
        values: newValues,
        isPristine: false,
        validationErrors: validator ? validator(newValues) : null
    };
}
// Helper to make TypeScript happy with reducing useToggle's 3-tuple to a 2-tuple
function _useToggle(initialValue) {
    var _a = useToggle(initialValue), state = _a[0], toggle = _a[1];
    return [state, toggle];
}
/**
 * A react hook to aid in managing the state of a checkbox group. Takes an object mapping state names (i.e. checkbox
 * names) to the initial values for those checkboxes, along with an optional validator function, and returns
 * an object containing React state values and setters (as if from useState) for each checkbox along with isPristine and
 * validationErrors
 */
export function useCheckboxGroupState(initialValues, validator) {
    function wrapState(_a) {
        var state = _a[0], toggler = _a[1];
        return [state, function () { setIsPristine(false); toggler(); }];
    }
    var rawStates = map(_useToggle, initialValues), _a = useState(true), isPristine = _a[0], setIsPristine = _a[1], values = map(head, filter(function (_a) {
        var isSet = _a[1][0];
        return isSet;
    }, toPairs(rawStates)));
    return {
        isPristine: isPristine,
        validationErrors: validator ? validator(values) : null,
        states: map(wrapState, rawStates)
    };
}
/**
 * Create a TransferListStateProps representing the initial state, selectedItem value,
 * and validated according to the specified validator
 */
export function transferListInitialState(selectedItems, validator) {
    return {
        selectedItems: selectedItems,
        isPristine: true,
        validationErrors: validator ? validator(selectedItems) : null
    };
}
/**
 * Create a TransferListStateProps representing a non-initial selectedItems value
 * and validated according to the specified validator
 */
export function transferListUserInput(newSelectedItems, validator) {
    return {
        selectedItems: newSelectedItems,
        isPristine: false,
        validationErrors: validator ? validator(newSelectedItems) : null
    };
}
export function useTransferListState(initialValue, validator) {
    var _a = useState(true), isPristine = _a[0], setIsPristine = _a[1];
    var _b = useState(initialValue), selectedItems = _b[0], _setSelectedItems = _b[1];
    var setSelectedItems = function (value) {
        setIsPristine(false);
        _setSelectedItems(value);
    };
    return {
        isPristine: isPristine,
        validationErrors: validator ? validator(selectedItems) : null,
        state: [selectedItems, setSelectedItems]
    };
}
//# sourceMappingURL=stateHelpers.js.map