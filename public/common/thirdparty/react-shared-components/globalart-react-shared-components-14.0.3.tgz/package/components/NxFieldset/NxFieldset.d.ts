import React from 'react';
import { Props } from './types';
export { Props };
import './NxFieldset.scss';
declare function NxFieldset(props: Props): React.JSX.Element;
declare namespace NxFieldset {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default NxFieldset;
//# sourceMappingURL=NxFieldset.d.ts.map