var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { useContext } from 'react';
import classnames from 'classnames';
import { propTypes } from './types';
import { getFirstValidationError, hasValidationErrors } from '../../util/validationUtil';
import { useUniqueId } from '../../util/idUtil';
import { FormAriaContext } from '../NxForm/context';
import './NxFieldset.scss';
export default function NxFieldset(props) {
    var className = props.className, label = props.label, sublabel = props.sublabel, children = props.children, isRequired = props.isRequired, validationErrors = props.validationErrors, isPristine = props.isPristine, attrs = __rest(props, ["className", "label", "sublabel", "children", "isRequired", "validationErrors", "isPristine"]), formShowValidationErrors = useContext(FormAriaContext).showValidationErrors, showValidationErrors = formShowValidationErrors || !isPristine, isInvalid = showValidationErrors && hasValidationErrors(validationErrors), classNames = classnames('nx-fieldset', className, {
        pristine: isPristine,
        valid: !isPristine && !isInvalid,
        invalid: isInvalid
    }), legendClassnames = classnames('nx-legend', { 'nx-legend--optional': !isRequired }), invalidMessageId = useUniqueId('nx-fieldset-invalid-message'), describedBy = isInvalid ? invalidMessageId : undefined;
    return (React.createElement("fieldset", __assign({ className: classNames, "aria-describedby": describedBy }, attrs),
        React.createElement("legend", { className: legendClassnames },
            React.createElement("span", { className: "nx-legend__text" }, label)),
        sublabel && React.createElement("div", { className: "nx-sub-label" }, sublabel),
        children,
        isInvalid &&
            React.createElement("div", { id: invalidMessageId, role: "alert", className: "nx-field-validation-message" }, getFirstValidationError(validationErrors))));
}
NxFieldset.propTypes = propTypes;
//# sourceMappingURL=NxFieldset.js.map