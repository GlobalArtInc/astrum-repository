import * as PropTypes from 'prop-types';
export var propTypes = {
    label: PropTypes.node.isRequired,
    sublabel: PropTypes.node,
    isRequired: PropTypes.bool,
    validationErrors: PropTypes.oneOfType([PropTypes.arrayOf(PropTypes.string.isRequired), PropTypes.string]),
    isPristine: PropTypes.bool
};
//# sourceMappingURL=types.js.map