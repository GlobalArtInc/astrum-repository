import { DOMAttributes, HTMLElementType, PropsWithChildren, ReactElement, RefAttributes } from 'react';
export interface Props<T extends HTMLElement> {
    children: ReactElement<PropsWithChildren & RefAttributes<T> & Pick<DOMAttributes<T>, 'onScroll'>>;
    reuseChildren?: boolean | null;
    initialChildCount?: number | null;
    spacerEl?: HTMLElementType | null;
}
//# sourceMappingURL=types.d.ts.map