/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import withClass from '../util/withClass';
// Simple convenience components that are just a particular tag with a particular classname, with the ability
// to add all attrs that you would normally be able to add to that tag (including more classnames)
export var AsP = withClass('p', 'as-p');
export var AsCode = withClass('code', 'as-code');
export var AsBlockquote = withClass('blockquote', 'as-blockquote');
export var AsPre = withClass('pre', 'as-pre');
export var AsFooter = withClass('footer', 'as-footer');
export var AsButtonBar = withClass('div', 'as-btn-bar');
export var AsCounter = withClass('span', 'as-counter');
export var AsThreatNumber = withClass('span', 'as-threat-number');
export var AsPageMain = withClass('main', 'as-page-main');
export var AsPageSidebar = withClass('aside', 'as-page-sidebar');
export var AsH1 = withClass('h1', 'as-h1');
export var AsH2 = withClass('h2', 'as-h2');
export var AsH3 = withClass('h3', 'as-h3');
export var AsH4 = withClass('h4', 'as-h4');
export var AsDivider = withClass('hr', 'as-divider');
export var AsFormRow = withClass('div', 'as-form-row');
export var AsGlobalFooter2 = Object.assign(withClass('footer', 'as-global-footer-2'), {
    Container: withClass('div', 'as-global-footer-2-container')
});
export var AsCard = Object.assign(withClass('section', 'as-card'), {
    Container: withClass('div', 'as-card-container'),
    Header: withClass('header', 'as-card__header'),
    Footer: withClass('footer', 'as-card__footer'),
    Content: withClass('div', 'as-card__content'),
    CallOut: withClass('div', 'as-card__call-out'),
    Text: withClass('div', 'as-card__text')
});
export var AsGrid = {
    Row: withClass('div', 'as-grid-row'),
    Column: withClass('section', 'as-grid-col'),
    ColumnSection: withClass('section', 'as-grid-col__section'),
    HorizontalKeyline: withClass('div', 'as-grid-h-keyline'),
    Header: withClass('div', 'as-grid-header'),
    HeaderHrule: withClass('hr', 'as-grid-header__hrule')
};
export var AsPageTitle = Object.assign(withClass('div', 'as-page-title'), {
    Headings: withClass('hgroup', 'as-page-title__headings'),
    Subtitle: withClass('h2', 'as-h2 as-page-title__sub-title'),
    Description: withClass('div', 'as-page-title__description'),
    Tags: withClass('div', 'as-page-title__tags')
});
export var AsReadOnly = Object.assign(withClass('dl', 'as-read-only'), {
    Label: withClass('dt', 'as-read-only__label'),
    Data: withClass('dd', 'as-read-only__data'),
    Item: withClass('div', 'as-read-only__item')
});
export var AsTableContainer = Object.assign(withClass('div', 'as-table-container'), {
    Footer: withClass('div', 'as-table-container__footer')
});
export var AsGlobalHeader = Object.assign(withClass('header', 'as-global-header'), {
    Actions: withClass('div', 'as-global-header__actions')
});
//# sourceMappingURL=SimpleComponents.js.map