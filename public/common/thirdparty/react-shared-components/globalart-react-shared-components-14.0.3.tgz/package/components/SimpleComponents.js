/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import withClass from '../util/withClass';
// Simple convenience components that are just a particular tag with a particular classname, with the ability
// to add all attrs that you would normally be able to add to that tag (including more classnames)
export var NxP = withClass('p', 'nx-p');
export var NxCode = withClass('code', 'nx-code');
export var NxBlockquote = withClass('blockquote', 'nx-blockquote');
export var NxPre = withClass('pre', 'nx-pre');
export var NxFooter = withClass('footer', 'nx-footer');
export var NxButtonBar = withClass('div', 'nx-btn-bar');
export var NxCounter = withClass('span', 'nx-counter');
export var NxThreatNumber = withClass('span', 'nx-threat-number');
export var NxPageMain = withClass('main', 'nx-page-main');
export var NxPageSidebar = withClass('aside', 'nx-page-sidebar');
export var NxH1 = withClass('h1', 'nx-h1');
export var NxH2 = withClass('h2', 'nx-h2');
export var NxH3 = withClass('h3', 'nx-h3');
export var NxH4 = withClass('h4', 'nx-h4');
export var NxDivider = withClass('hr', 'nx-divider');
export var NxFormRow = withClass('div', 'nx-form-row');
export var NxGlobalFooter2 = Object.assign(withClass('footer', 'nx-global-footer-2'), {
    Container: withClass('div', 'nx-global-footer-2-container')
});
export var NxCard = Object.assign(withClass('section', 'nx-card'), {
    Container: withClass('div', 'nx-card-container'),
    Header: withClass('header', 'nx-card__header'),
    Footer: withClass('footer', 'nx-card__footer'),
    Content: withClass('div', 'nx-card__content'),
    CallOut: withClass('div', 'nx-card__call-out'),
    Text: withClass('div', 'nx-card__text')
});
export var NxGrid = {
    Row: withClass('div', 'nx-grid-row'),
    Column: withClass('section', 'nx-grid-col'),
    ColumnSection: withClass('section', 'nx-grid-col__section'),
    HorizontalKeyline: withClass('div', 'nx-grid-h-keyline'),
    Header: withClass('div', 'nx-grid-header'),
    HeaderHrule: withClass('hr', 'nx-grid-header__hrule')
};
export var NxPageTitle = Object.assign(withClass('div', 'nx-page-title'), {
    Headings: withClass('hgroup', 'nx-page-title__headings'),
    Subtitle: withClass('h2', 'nx-h2 nx-page-title__sub-title'),
    Description: withClass('div', 'nx-page-title__description'),
    Tags: withClass('div', 'nx-page-title__tags')
});
export var NxReadOnly = Object.assign(withClass('dl', 'nx-read-only'), {
    Label: withClass('dt', 'nx-read-only__label'),
    Data: withClass('dd', 'nx-read-only__data'),
    Item: withClass('div', 'nx-read-only__item')
});
export var NxTableContainer = Object.assign(withClass('div', 'nx-table-container'), {
    Footer: withClass('div', 'nx-table-container__footer')
});
export var NxGlobalHeader = Object.assign(withClass('header', 'nx-global-header'), {
    Actions: withClass('div', 'nx-global-header__actions')
});
//# sourceMappingURL=SimpleComponents.js.map