import { ComponentPropsWithRef } from 'react';
import * as PropTypes from 'prop-types';
export type NxTileHeaderTitleProps = ComponentPropsWithRef<'div'>;
export declare const nxTileHeaderTitlePropTypes: PropTypes.WeakValidationMap<NxTileHeaderTitleProps>;
//# sourceMappingURL=types.d.ts.map