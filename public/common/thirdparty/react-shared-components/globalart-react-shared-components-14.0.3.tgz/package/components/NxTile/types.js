import * as PropTypes from 'prop-types';
export var nxTileHeaderTitlePropTypes = {
    children: PropTypes.node,
    className: PropTypes.string
};
//# sourceMappingURL=types.js.map