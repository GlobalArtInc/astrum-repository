var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import classnames from 'classnames';
import NxOverflowTooltip from '../NxTooltip/NxOverflowTooltip';
import withClass from '../../util/withClass';
import { nxTileHeaderTitlePropTypes } from './types';
function NxTileHeaderTitle(props) {
    var className = props.className, children = props.children, attrs = __rest(props, ["className", "children"]);
    var classes = classnames('nx-tile-header__title', className);
    return (React.createElement(NxOverflowTooltip, null,
        React.createElement("div", __assign({ className: classes }, attrs), children)));
}
NxTileHeaderTitle.propTypes = nxTileHeaderTitlePropTypes;
var NxTile = Object.assign(withClass('section', 'nx-tile'), {
    Header: withClass('header', 'nx-tile-header'),
    Headings: withClass('hgroup', 'nx-tile-header__headings'),
    HeaderTitle: NxTileHeaderTitle,
    HeaderSubtitle: withClass('h3', 'nx-tile-header__subtitle'),
    HeaderActions: withClass('div', 'nx-tile__actions'),
    Content: withClass('div', 'nx-tile-content'),
    Subsection: withClass('section', 'nx-tile-subsection'),
    SubsectionHeader: withClass('header', 'nx-tile-subsection__header'),
    HeaderTags: withClass('div', 'nx-tile__tags')
});
export default NxTile;
//# sourceMappingURL=NxTile.js.map