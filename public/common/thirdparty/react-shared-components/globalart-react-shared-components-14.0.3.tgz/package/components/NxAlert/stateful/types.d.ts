export declare const propTypes: Omit<import("prop-types").ValidationMap<import("../types").Props>, "onClose">;
export declare const nxStatefulAlertPropTypes: Omit<import("prop-types").ValidationMap<import("../types").NxAlertProps>, "onClose">;
//# sourceMappingURL=types.d.ts.map