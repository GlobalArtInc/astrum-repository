var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import classnames from 'classnames';
import { faCheckCircle, faExclamationTriangle, faExclamationCircle, faInfoCircle } from '@fortawesome/free-solid-svg-icons';
import NxCloseButton from '../NxCloseButton/NxCloseButton';
import NxFontAwesomeIcon from '../NxFontAwesomeIcon/NxFontAwesomeIcon';
import { propTypes, nxAlertPropTypes } from './types';
export { propTypes, nxAlertPropTypes } from './types';
/**
 * Base component that renders a standardized alert.
 * @param children VDOM nodes to be included after the icon.
 * @param className CSS class names to apply to the rendered component.
 * @param icon FontAwesome icon data to render
 */
function NxAlert(props) {
    var className = props.className, icon = props.icon, iconLabel = props.iconLabel, children = props.children, onClose = props.onClose, otherProps = __rest(props, ["className", "icon", "iconLabel", "children", "onClose"]), classes = classnames('nx-alert', className);
    return (React.createElement("div", __assign({}, otherProps, { className: classes, "aria-atomic": true }),
        React.createElement(NxFontAwesomeIcon, { "aria-label": iconLabel || undefined, "aria-hidden": !iconLabel, icon: icon }),
        React.createElement("div", { className: "nx-alert__content-wrap" },
            React.createElement("div", { className: "nx-alert__content" }, children)),
        onClose && React.createElement(NxCloseButton, { onClick: onClose })));
}
NxAlert.propTypes = nxAlertPropTypes;
export default NxAlert;
/**
 * Component that renders a standardized error alert.
 * @param children VDOM nodes to be included after the icon.
 */
export function NxErrorAlert(props) {
    var classes = classnames('nx-alert--error', props.className);
    return React.createElement(NxAlert, __assign({ role: "alert" }, props, { className: classes, icon: faExclamationCircle, iconLabel: "Error" }));
}
NxErrorAlert.propTypes = propTypes;
/**
 * Component that renders a standardized information alert.
 * @param children VDOM nodes to be included after the icon.
 */
export function NxInfoAlert(props) {
    var classes = classnames('nx-alert--info', props.className);
    return React.createElement(NxAlert, __assign({}, props, { className: classes, icon: faInfoCircle, iconLabel: "Info" }));
}
NxInfoAlert.propTypes = propTypes;
/**
 * Component that renders a standardized warning alert.
 * @param children VDOM nodes to be included after the icon.
 */
export function NxWarningAlert(props) {
    var classes = classnames('nx-alert--warning', props.className);
    return React.createElement(NxAlert, __assign({}, props, { className: classes, icon: faExclamationTriangle, iconLabel: "Warning" }));
}
NxWarningAlert.propTypes = propTypes;
/**
 * Component that renders a standardized success alert.
 * @param children VDOM nodes to be included after the icon.
 */
export function NxSuccessAlert(props) {
    var classes = classnames('nx-alert--success', props.className);
    return React.createElement(NxAlert, __assign({ role: "status" }, props, { className: classes, icon: faCheckCircle, iconLabel: "Success" }));
}
NxSuccessAlert.propTypes = propTypes;
//# sourceMappingURL=NxAlert.js.map