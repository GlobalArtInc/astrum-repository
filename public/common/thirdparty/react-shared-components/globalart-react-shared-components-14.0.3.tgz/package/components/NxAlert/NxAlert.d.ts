import React from 'react';
import { Props, NxAlertProps } from './types';
export { Props, propTypes, NxAlertProps, nxAlertPropTypes } from './types';
/**
 * Base component that renders a standardized alert.
 * @param children VDOM nodes to be included after the icon.
 * @param className CSS class names to apply to the rendered component.
 * @param icon FontAwesome icon data to render
 */
declare function NxAlert(props: NxAlertProps): React.JSX.Element;
declare namespace NxAlert {
    var propTypes: import("prop-types").ValidationMap<NxAlertProps>;
}
export default NxAlert;
/**
 * Component that renders a standardized error alert.
 * @param children VDOM nodes to be included after the icon.
 */
export declare function NxErrorAlert(props: Props): React.JSX.Element;
export declare namespace NxErrorAlert {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
/**
 * Component that renders a standardized information alert.
 * @param children VDOM nodes to be included after the icon.
 */
export declare function NxInfoAlert(props: Props): React.JSX.Element;
export declare namespace NxInfoAlert {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
/**
 * Component that renders a standardized warning alert.
 * @param children VDOM nodes to be included after the icon.
 */
export declare function NxWarningAlert(props: Props): React.JSX.Element;
export declare namespace NxWarningAlert {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
/**
 * Component that renders a standardized success alert.
 * @param children VDOM nodes to be included after the icon.
 */
export declare function NxSuccessAlert(props: Props): React.JSX.Element;
export declare namespace NxSuccessAlert {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
//# sourceMappingURL=NxAlert.d.ts.map