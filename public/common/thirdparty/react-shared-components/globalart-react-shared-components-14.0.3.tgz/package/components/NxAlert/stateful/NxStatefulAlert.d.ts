import React from 'react';
import { Props } from '../types';
declare const NxStatefulAlert: React.FunctionComponent<import("../types").NxAlertProps>;
export default NxStatefulAlert;
export declare const NxStatefulErrorAlert: React.FunctionComponent<Props>;
export declare const NxStatefulInfoAlert: React.FunctionComponent<Props>;
export declare const NxStatefulWarningAlert: React.FunctionComponent<Props>;
export declare const NxStatefulSuccessAlert: React.FunctionComponent<Props>;
//# sourceMappingURL=NxStatefulAlert.d.ts.map