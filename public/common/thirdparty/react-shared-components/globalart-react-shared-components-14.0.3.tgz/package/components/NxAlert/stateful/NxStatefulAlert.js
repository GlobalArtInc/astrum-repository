var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import NxAlert, { NxSuccessAlert, NxWarningAlert, NxInfoAlert, NxErrorAlert } from '../NxAlert';
import { nxStatefulAlertPropTypes, propTypes } from './types';
import useToggle from '../../../util/useToggle';
function mkStatefulAlertComponent(StatelessAlert) {
    return function NxStatefulAlertBase(props) {
        var _a = useToggle(true), isOpen = _a[0], onClose = _a[1];
        return isOpen ? React.createElement(StatelessAlert, __assign({}, __assign(__assign({}, props), { onClose: onClose }))) : null;
    };
}
var NxStatefulAlert = mkStatefulAlertComponent(NxAlert);
NxStatefulAlert.propTypes = nxStatefulAlertPropTypes;
export default NxStatefulAlert;
export var NxStatefulErrorAlert = mkStatefulAlertComponent(NxErrorAlert);
export var NxStatefulInfoAlert = mkStatefulAlertComponent(NxInfoAlert);
export var NxStatefulWarningAlert = mkStatefulAlertComponent(NxWarningAlert);
export var NxStatefulSuccessAlert = mkStatefulAlertComponent(NxSuccessAlert);
NxStatefulErrorAlert.propTypes = NxStatefulWarningAlert.propTypes = NxStatefulInfoAlert.propTypes =
    NxStatefulSuccessAlert.propTypes = propTypes;
//# sourceMappingURL=NxStatefulAlert.js.map