import React from 'react';
import { NxToastProps } from './types';
export { NxToastProps };
declare const NxToast: {
    (props: NxToastProps): React.JSX.Element;
    propTypes: import("prop-types").ValidationMap<NxToastProps>;
};
export default NxToast;
//# sourceMappingURL=NxToast.d.ts.map