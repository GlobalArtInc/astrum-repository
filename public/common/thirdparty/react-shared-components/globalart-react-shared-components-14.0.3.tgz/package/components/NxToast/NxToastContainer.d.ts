import React from 'react';
import { NxToastContainerProps } from './types';
export { NxToastContainerProps };
import './NxToast.scss';
declare const NxToastContainer: {
    (props: NxToastContainerProps): React.JSX.Element;
    propType: import("prop-types").ValidationMap<NxToastContainerProps>;
};
export default NxToastContainer;
//# sourceMappingURL=NxToastContainer.d.ts.map