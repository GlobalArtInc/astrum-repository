import { NxToastContainerContextType } from './types';
declare const NxToastContainerContext: import("react").Context<NxToastContainerContextType>;
export default NxToastContainerContext;
//# sourceMappingURL=contexts.d.ts.map