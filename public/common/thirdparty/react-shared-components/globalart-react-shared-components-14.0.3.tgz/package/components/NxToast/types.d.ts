import { ReactNode, ReactElement, ComponentPropsWithRef } from 'react';
import * as PropTypes from 'prop-types';
type CloseableElementWithRoleProps = Pick<ComponentPropsWithRef<'dialog'>, 'role' | 'onClose'>;
export interface NxToastProps extends ComponentPropsWithRef<'div'> {
    onClose: () => void;
    children: ReactElement<CloseableElementWithRoleProps> | ReactElement<CloseableElementWithRoleProps>[];
}
export declare const nxToastPropTypes: PropTypes.ValidationMap<NxToastProps>;
export type NxToastContainerContextType = {
    onToastClosing: (toast: HTMLElement | null) => void;
};
export interface NxToastContainerProps {
    children: ReactNode;
}
export declare const nxToastContainerPropTypes: PropTypes.ValidationMap<NxToastContainerProps>;
export {};
//# sourceMappingURL=types.d.ts.map