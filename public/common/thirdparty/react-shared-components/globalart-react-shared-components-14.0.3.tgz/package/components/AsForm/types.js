import * as PropTypes from 'prop-types';
import { propTypes as asTextInputPropTypes } from '../AsTextInput/types';
export var propTypes = {
    loading: PropTypes.bool,
    doLoad: PropTypes.func,
    onSubmit: PropTypes.func.isRequired,
    onCancel: PropTypes.func,
    loadError: PropTypes.string,
    submitError: PropTypes.string,
    submitErrorTitleMessage: PropTypes.string,
    validationErrors: asTextInputPropTypes.validationErrors,
    submitBtnClasses: PropTypes.string,
    submitBtnText: PropTypes.string,
    submitMaskState: PropTypes.bool,
    submitMaskMessage: PropTypes.string,
    submitMaskSuccessMessage: PropTypes.string,
    children: PropTypes.oneOfType([PropTypes.node, PropTypes.func]).isRequired,
    additionalFooterBtns: PropTypes.node
};
//# sourceMappingURL=types.js.map