import React from 'react';
import { Props, propTypes } from './types';
declare function AsForm(props: Props): React.JSX.Element;
declare namespace AsForm {
    var propTypes: import("prop-types").ValidationMap<Props>;
    var RequiredFieldNotice: () => React.JSX.Element;
}
export default AsForm;
export { Props, propTypes };
//# sourceMappingURL=AsForm.d.ts.map