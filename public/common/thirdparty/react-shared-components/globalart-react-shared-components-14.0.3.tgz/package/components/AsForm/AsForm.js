var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import { always } from 'ramda';
import classnames from 'classnames';
import AsLoadWrapper from '../AsLoadWrapper/AsLoadWrapper';
import AsLoadError from '../AsLoadError/AsLoadError';
import AsButton from '../AsButton/AsButton';
import AsSubmitMask from '../AsSubmitMask/AsSubmitMask';
import { propTypes } from './types';
import { FormAriaContext } from './context';
import { getFirstValidationError, hasValidationErrors } from '../../util/validationUtil';
import { AsErrorAlert } from '../AsAlert/AsAlert';
import { AsP } from '../SimpleComponents';
function RequiredFieldNotice() {
    return (React.createElement(AsP, { className: "as-form__required-field-notice" },
        React.createElement("span", { className: "as-form__required-field-asterisk" }, "*"),
        ' ',
        "Required fields are marked with an asterisk."));
}
export default function AsForm(props) {
    var className = props.className, loading = props.loading, doLoad = props.doLoad, onSubmitProp = props.onSubmit, onCancel = props.onCancel, loadError = props.loadError, submitError = props.submitError, submitErrorTitleMessage = props.submitErrorTitleMessage, validationErrors = props.validationErrors, submitBtnClassesProp = props.submitBtnClasses, submitBtnText = props.submitBtnText, submitMaskState = props.submitMaskState, submitMaskMessage = props.submitMaskMessage, submitMaskSuccessMessage = props.submitMaskSuccessMessage, children = props.children, additionalFooterBtns = props.additionalFooterBtns, showValidationErrors = props.showValidationErrors, formAttrs = __rest(props, ["className", "loading", "doLoad", "onSubmit", "onCancel", "loadError", "submitError", "submitErrorTitleMessage", "validationErrors", "submitBtnClasses", "submitBtnText", "submitMaskState", "submitMaskMessage", "submitMaskSuccessMessage", "children", "additionalFooterBtns", "showValidationErrors"]), formHasValidationErrors = hasValidationErrors(validationErrors), formClasses = classnames('as-form', className, {
        'as-form--show-validation-errors': showValidationErrors,
        'as-form--has-validation-errors': formHasValidationErrors,
        'as-form--has-submit-error': !!submitError
    }), getChildren = children instanceof Function ? children : always(children), submitBtnClasses = classnames('as-form__submit-btn', submitBtnClassesProp);
    if (showValidationErrors == null) {
        throw new Error('showValidationErrors is strictly required!');
    }
    function onSubmit(evt) {
        evt.preventDefault();
        onSubmitProp();
    }
    var renderForm = function () {
        return (React.createElement("form", __assign({ className: formClasses, onSubmit: onSubmit }, formAttrs),
            React.createElement(FormAriaContext.Provider, { value: { showValidationErrors: showValidationErrors } }, getChildren()),
            React.createElement("footer", { className: "as-footer" },
                React.createElement(AsLoadError, { titleMessage: submitErrorTitleMessage || 'An error occurred saving data.', error: submitError, submitOnRetry: true, "aria-label": "form saving errors" }),
                formHasValidationErrors && !submitError &&
                    React.createElement(AsErrorAlert, { className: "as-form__validation-errors", "aria-label": "form validation errors" },
                        "There were validation errors.",
                        ' ',
                        getFirstValidationError(validationErrors)),
                React.createElement("div", { className: "as-btn-bar" },
                    additionalFooterBtns,
                    onCancel &&
                        React.createElement(AsButton, { type: "button", onClick: onCancel, className: "as-form__cancel-btn" }, "Cancel"),
                    React.createElement(AsButton, { variant: "primary", className: submitBtnClasses }, submitBtnText || 'Submit'))),
            submitMaskState != null &&
                React.createElement(AsSubmitMask, { success: submitMaskState, message: submitMaskMessage, successMessage: submitMaskSuccessMessage, "aria-label": "form submit status" })));
    };
    return doLoad ? (React.createElement(AsLoadWrapper, { loading: loading, error: loadError, retryHandler: doLoad }, renderForm)) : renderForm();
}
AsForm.propTypes = propTypes;
AsForm.RequiredFieldNotice = RequiredFieldNotice;
export { propTypes };
//# sourceMappingURL=AsForm.js.map