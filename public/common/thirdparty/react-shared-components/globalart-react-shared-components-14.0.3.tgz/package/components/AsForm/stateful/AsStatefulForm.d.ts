import React from 'react';
import { StatefulProps as Props } from '../types';
export { Props };
export default function AsStatefulForm(props: Props): React.JSX.Element;
//# sourceMappingURL=AsStatefulForm.d.ts.map