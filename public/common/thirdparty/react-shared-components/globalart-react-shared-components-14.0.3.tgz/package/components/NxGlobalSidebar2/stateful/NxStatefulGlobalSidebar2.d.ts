import { FunctionComponent } from 'react';
import { Props } from './types';
declare const NxStatefulGlobalSidebar2: FunctionComponent<Props>;
export default NxStatefulGlobalSidebar2;
export { Props, propTypes } from './types';
//# sourceMappingURL=NxStatefulGlobalSidebar2.d.ts.map