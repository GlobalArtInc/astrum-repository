import { FunctionComponent } from 'react';
import { Props } from './types';
import './NxGlobalSidebar2.scss';
declare const NxGlobalSidebar2: FunctionComponent<Props>;
export default NxGlobalSidebar2;
export { Props, propTypes } from './types';
//# sourceMappingURL=NxGlobalSidebar2.d.ts.map