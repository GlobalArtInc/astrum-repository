import * as PropTypes from 'prop-types';
import { ComponentPropsWithRef, ReactNode } from 'react';
import { IconDefinition } from '@fortawesome/fontawesome-svg-core';
import RequiredReactNode from '../../util/RequiredReactNode';
export interface Props {
    isOpen: boolean;
    className?: string | null;
    toggleOpenIcon: IconDefinition;
    toggleCloseIcon: IconDefinition;
    onToggleClick: (() => void);
    children?: ReactNode | null;
}
export declare const propTypes: PropTypes.ValidationMap<Props>;
export interface NxGlobalSidebar2NavigationLinkProps extends ComponentPropsWithRef<'a'> {
    isSelected?: boolean | null;
    icon: IconDefinition;
    text: RequiredReactNode;
    href: string;
}
export declare const nxGlobalSidebar2NavigationLinkPropTypes: PropTypes.ValidationMap<NxGlobalSidebar2NavigationLinkProps>;
//# sourceMappingURL=types.d.ts.map