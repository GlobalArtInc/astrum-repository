/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import classnames from 'classnames';
import NxButton from '../NxButton/NxButton';
import NxOverflowTooltip from '../NxTooltip/NxOverflowTooltip';
import NxFontAwesomeIcon from '../NxFontAwesomeIcon/NxFontAwesomeIcon';
import { useUniqueId } from '../../util/idUtil';
import { propTypes } from './types';
import './NxGlobalSidebar2.scss';
var NxGlobalSidebar2 = function NxGlobalSidebar(props) {
    var isOpen = props.isOpen, children = props.children, className = props.className, toggleOpenIcon = props.toggleOpenIcon, toggleCloseIcon = props.toggleCloseIcon, onToggleClick = props.onToggleClick;
    var id = useUniqueId('nx-global-sidebar-2');
    var classes = classnames(className, 'nx-global-sidebar-2 nx-viewport-sized', {
        'open': isOpen,
        'closed': !isOpen
    });
    var toggleButtonIcon = isOpen ? toggleOpenIcon : toggleCloseIcon;
    return (React.createElement("div", { className: classes, id: id },
        React.createElement("nav", { className: "nx-global-sidebar-2__nav nx-scrollable nx-viewport-sized__scrollable", "aria-label": "global sidebar" }, children),
        React.createElement(NxOverflowTooltip, null,
            React.createElement(NxButton, { "aria-expanded": isOpen, "aria-controls": id, onClick: onToggleClick, className: "nx-global-sidebar-2__toggle" },
                React.createElement(NxFontAwesomeIcon, { icon: toggleButtonIcon, fixedWidth: true }),
                React.createElement("span", { className: "nx-global-sidebar-2__text" },
                    isOpen ? 'Collapse' : 'Expand',
                    " Menu")))));
};
NxGlobalSidebar2.propTypes = propTypes;
export default NxGlobalSidebar2;
export { propTypes } from './types';
//# sourceMappingURL=NxGlobalSidebar2.js.map