import { FunctionComponent } from 'react';
import { NxGlobalSidebar2NavigationLinkProps as Props } from './types';
export { NxGlobalSidebar2NavigationLinkProps } from './types';
import './NxGlobalSidebar2NavigationLink.scss';
declare const NxGlobalSidebarNavigationLink: FunctionComponent<Props>;
export default NxGlobalSidebarNavigationLink;
//# sourceMappingURL=NxGlobalSidebar2NavigationLink.d.ts.map