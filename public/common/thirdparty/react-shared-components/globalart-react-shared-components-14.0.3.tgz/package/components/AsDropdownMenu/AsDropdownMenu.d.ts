import React from 'react';
import { Props } from './types';
import './AsDropdownMenu.scss';
export { Props };
/**
 * This component is not currently intended for public export. It is a helper for AsDropdown and AsSegmentedButton
 * so they can reset focus when they close
 */
declare function AsDropdownMenu(props: Props): React.JSX.Element;
declare namespace AsDropdownMenu {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default AsDropdownMenu;
//# sourceMappingURL=AsDropdownMenu.d.ts.map