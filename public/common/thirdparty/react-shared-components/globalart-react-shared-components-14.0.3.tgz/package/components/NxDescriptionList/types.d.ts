import { ComponentPropsWithoutRef, ComponentPropsWithRef, ReactNode } from 'react';
import * as PropTypes from 'prop-types';
type AttributeOmissions = 'disabled' | 'className' | 'onClick' | 'href';
export interface ButtonItemProps extends ComponentPropsWithRef<'div'> {
    onClick: () => void;
    term: Exclude<ReactNode, undefined | null>;
    description: Exclude<ReactNode, undefined | null>;
    selected?: boolean | null;
    disabled?: boolean | null;
    buttonClassName?: string | null;
    buttonAttributes?: Omit<ComponentPropsWithoutRef<'button'>, AttributeOmissions> | null;
}
export interface LinkItemProps extends ComponentPropsWithRef<'div'> {
    href: string;
    term: Exclude<ReactNode, undefined | null>;
    description: Exclude<ReactNode, undefined | null>;
    selected?: boolean | null;
    disabled?: boolean | null;
    anchorClassName?: string | null;
    anchorAttributes?: Omit<ComponentPropsWithoutRef<'a'>, AttributeOmissions> | null;
}
export interface Props extends ComponentPropsWithRef<'dl'> {
    emptyMessage?: string | null;
}
export declare const buttonItemPropTypes: PropTypes.ValidationMap<ButtonItemProps>;
export declare const linkItemPropTypes: PropTypes.ValidationMap<LinkItemProps>;
export declare const propTypes: PropTypes.ValidationMap<Props>;
export {};
//# sourceMappingURL=types.d.ts.map