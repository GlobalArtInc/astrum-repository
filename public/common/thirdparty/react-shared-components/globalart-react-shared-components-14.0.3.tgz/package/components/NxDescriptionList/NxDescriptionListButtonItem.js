var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import classnames from 'classnames';
import { faAngleRight } from '@fortawesome/free-solid-svg-icons';
import NxFontAwesomeIcon from '../NxFontAwesomeIcon/NxFontAwesomeIcon';
import { useUniqueId } from '../../util/idUtil';
import { includesDisabledClass } from '../../util/classUtil';
import { buttonItemPropTypes } from './types';
export default function NxDescriptionListButtonItem(props) {
    var ref = props.ref, onClick = props.onClick, className = props.className, disabled = props.disabled, selectedProp = props.selected, buttonClassName = props.buttonClassName, buttonAttributes = props.buttonAttributes, term = props.term, description = props.description, attrs = __rest(props, ["ref", "onClick", "className", "disabled", "selected", "buttonClassName", "buttonAttributes", "term", "description"]), selected = selectedProp !== null && selectedProp !== void 0 ? selectedProp : undefined, buttonClassNames = classnames('nx-list__btn', buttonClassName, { selected: selected, disabled: disabled }), isDisabled = includesDisabledClass(buttonClassNames), divClassNames = classnames('nx-list__item', 'nx-list__item--clickable', className, {
        selected: selected,
        disabled: isDisabled
    }), descriptionId = useUniqueId('nx-list-description');
    return (React.createElement("div", __assign({ ref: ref, className: divClassNames }, attrs, { "aria-selected": selected, "aria-current": selected }),
        React.createElement("dt", { className: "nx-list__term" },
            React.createElement("button", __assign({}, buttonAttributes, { "aria-disabled": isDisabled, "aria-describedby": descriptionId, className: buttonClassNames, disabled: disabled ? true : false, onClick: function () { return onClick(); } }),
                React.createElement("span", { className: "nx-list__text" }, term))),
        React.createElement("dd", { className: "nx-list__description" },
            React.createElement("button", __assign({}, buttonAttributes, { onClick: function () { return onClick(); }, "aria-hidden": true, tabIndex: -1, className: buttonClassNames, disabled: disabled ? true : false }),
                React.createElement("span", { id: descriptionId, className: "nx-list__text" }, description),
                React.createElement(NxFontAwesomeIcon, { icon: faAngleRight, className: "nx-chevron" })))));
}
NxDescriptionListButtonItem.propTypes = buttonItemPropTypes;
//# sourceMappingURL=NxDescriptionListButtonItem.js.map