var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { useRef } from 'react';
import useMergedRef from '@react-hook/merged-ref';
import classnames from 'classnames';
import withClass from '../../util/withClass';
import useEmptyComponent from '../../util/useEmptyComponent';
import NxDescriptionListButtonItem from './NxDescriptionListButtonItem';
import NxDescriptionListLinkItem from './NxDescriptionListLinkItem';
import { propTypes } from './types';
import { ensureRef } from '../../util/reactUtil';
export default function NxDescriptionList(_a) {
    var externalRef = _a.ref, emptyMessage = _a.emptyMessage, className = _a.className, otherProps = __rest(_a, ["ref", "emptyMessage", "className"]);
    var emptyChildRef = useRef(null), listRef = useRef(null), ref = useMergedRef(ensureRef(externalRef), listRef), isEmpty = useEmptyComponent(listRef, emptyChildRef);
    var emptyList = (React.createElement("ul", __assign({ ref: ref, className: classnames(className, 'nx-list') }, otherProps),
        React.createElement("li", { ref: emptyChildRef, className: "nx-list__item nx-list__item--empty" },
            React.createElement("span", { className: "nx-list__text" }, emptyMessage || 'This list is empty.'))));
    return isEmpty ? emptyList :
        React.createElement("dl", __assign({ ref: ref, className: classnames(className, 'nx-list', 'nx-list--description-list') }, otherProps));
}
NxDescriptionList.propTypes = propTypes;
NxDescriptionList.Item = withClass('div', 'nx-list__item');
NxDescriptionList.Term = withClass('dt', 'nx-list__term');
NxDescriptionList.Description = withClass('dd', 'nx-list__description');
NxDescriptionList.ButtonItem = NxDescriptionListButtonItem;
NxDescriptionList.LinkItem = NxDescriptionListLinkItem;
//# sourceMappingURL=NxDescriptionList.js.map