var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import classnames from 'classnames';
import { faAngleRight } from '@fortawesome/free-solid-svg-icons';
import NxFontAwesomeIcon from '../NxFontAwesomeIcon/NxFontAwesomeIcon';
import { useUniqueId } from '../../util/idUtil';
import { includesDisabledClass } from '../../util/classUtil';
import { linkItemPropTypes } from './types';
export default function NxDescriptionListLinkItem(props) {
    var href = props.href, className = props.className, disabled = props.disabled, selectedProp = props.selected, anchorClassName = props.anchorClassName, anchorAttributes = props.anchorAttributes, term = props.term, description = props.description, attrs = __rest(props, ["href", "className", "disabled", "selected", "anchorClassName", "anchorAttributes", "term", "description"]), selected = selectedProp !== null && selectedProp !== void 0 ? selectedProp : undefined, linkClassNames = classnames('nx-list__link', anchorClassName, { selected: selected, disabled: disabled }), isDisabled = includesDisabledClass(linkClassNames), divClassNames = classnames('nx-list__item', 'nx-list__item--clickable', className, {
        selected: selected,
        disabled: isDisabled
    }), descriptionId = useUniqueId('nx-list-description');
    function preventMouseInteraction(evt) {
        if (disabled) {
            evt.preventDefault();
        }
    }
    return (React.createElement("div", __assign({ className: divClassNames }, attrs, { "aria-selected": selected, "aria-current": selected }),
        React.createElement("dt", { className: "nx-list__term" },
            React.createElement("a", __assign({}, anchorAttributes, { "aria-disabled": isDisabled, "aria-describedby": descriptionId, className: linkClassNames, href: href, onClick: preventMouseInteraction, onMouseDown: preventMouseInteraction, tabIndex: isDisabled ? -1 : 0 }),
                React.createElement("span", { className: "nx-list__text" }, term))),
        React.createElement("dd", { className: "nx-list__description" },
            React.createElement("a", __assign({}, anchorAttributes, { "aria-hidden": true, tabIndex: -1, className: linkClassNames, href: href, onClick: preventMouseInteraction, onMouseDown: preventMouseInteraction }),
                React.createElement("span", { id: descriptionId, className: "nx-list__text" }, description),
                React.createElement(NxFontAwesomeIcon, { icon: faAngleRight, className: "nx-chevron" })))));
}
NxDescriptionListLinkItem.propTypes = linkItemPropTypes;
//# sourceMappingURL=NxDescriptionListLinkItem.js.map