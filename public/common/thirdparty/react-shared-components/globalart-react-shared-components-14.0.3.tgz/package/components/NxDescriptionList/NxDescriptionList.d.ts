import React from 'react';
import NxDescriptionListButtonItem from './NxDescriptionListButtonItem';
import NxDescriptionListLinkItem from './NxDescriptionListLinkItem';
import { Props } from './types';
export { Props, ButtonItemProps, LinkItemProps } from './types';
declare function NxDescriptionList({ ref: externalRef, emptyMessage, className, ...otherProps }: Props): React.JSX.Element;
declare namespace NxDescriptionList {
    var propTypes: import("prop-types").ValidationMap<Props>;
    var Item: (props: React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => React.ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | React.JSXElementConstructor<any>>;
    var Term: (props: React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement>) => React.ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement>, "className">, string | React.JSXElementConstructor<any>>;
    var Description: (props: React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement>) => React.ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement>, "className">, string | React.JSXElementConstructor<any>>;
    var ButtonItem: typeof NxDescriptionListButtonItem;
    var LinkItem: typeof NxDescriptionListLinkItem;
}
export default NxDescriptionList;
//# sourceMappingURL=NxDescriptionList.d.ts.map