import React from 'react';
import { LinkItemProps } from './types';
declare function NxDescriptionListLinkItem(props: LinkItemProps): React.JSX.Element;
declare namespace NxDescriptionListLinkItem {
    var propTypes: import("prop-types").ValidationMap<LinkItemProps>;
}
export default NxDescriptionListLinkItem;
//# sourceMappingURL=NxDescriptionListLinkItem.d.ts.map