import * as PropTypes from 'prop-types';
export var buttonItemPropTypes = {
    onClick: PropTypes.func.isRequired,
    term: PropTypes.node.isRequired,
    description: PropTypes.node.isRequired,
    selected: PropTypes.bool,
    disabled: PropTypes.bool,
    buttonClassName: PropTypes.string,
    buttonAttributes: PropTypes.object
};
export var linkItemPropTypes = {
    href: PropTypes.string.isRequired,
    term: PropTypes.node.isRequired,
    description: PropTypes.node.isRequired,
    selected: PropTypes.bool,
    disabled: PropTypes.bool,
    anchorClassName: PropTypes.string,
    anchorAttributes: PropTypes.object
};
export var propTypes = {
    emptyMessage: PropTypes.string
};
//# sourceMappingURL=types.js.map