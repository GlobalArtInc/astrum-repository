import React from 'react';
import { ButtonItemProps } from './types';
declare function NxDescriptionListButtonItem(props: ButtonItemProps): React.JSX.Element;
declare namespace NxDescriptionListButtonItem {
    var propTypes: import("prop-types").ValidationMap<ButtonItemProps>;
}
export default NxDescriptionListButtonItem;
//# sourceMappingURL=NxDescriptionListButtonItem.d.ts.map