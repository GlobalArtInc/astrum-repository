var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { useEffect, useRef, useState } from 'react';
import { hasValidationErrors } from '../../../util/validationUtil';
import NxForm from '../NxForm';
export default function NxStatefulForm(props) {
    var onSubmitProp = props.onSubmit, validationErrors = props.validationErrors, _a = useState(false), showValidationErrors = _a[0], setShowValidationErrors = _a[1], previousValidationErrors = useRef(null);
    function onSubmit() {
        if (hasValidationErrors(validationErrors)) {
            setShowValidationErrors(true);
        }
        else {
            onSubmitProp();
        }
    }
    useEffect(function () {
        if (!hasValidationErrors(validationErrors) && hasValidationErrors(previousValidationErrors.current)) {
            setShowValidationErrors(false);
        }
        previousValidationErrors.current = validationErrors;
    }, [validationErrors]);
    return React.createElement(NxForm, __assign({}, props, { onSubmit: onSubmit, showValidationErrors: showValidationErrors }));
}
//# sourceMappingURL=NxStatefulForm.js.map