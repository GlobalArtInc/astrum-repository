var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import { always } from 'ramda';
import classnames from 'classnames';
import NxLoadWrapper from '../NxLoadWrapper/NxLoadWrapper';
import NxLoadError from '../NxLoadError/NxLoadError';
import NxButton from '../NxButton/NxButton';
import NxSubmitMask from '../NxSubmitMask/NxSubmitMask';
import { propTypes } from './types';
import { FormAriaContext } from './context';
import { getFirstValidationError, hasValidationErrors } from '../../util/validationUtil';
import { NxErrorAlert } from '../NxAlert/NxAlert';
import { NxP } from '../SimpleComponents';
function RequiredFieldNotice() {
    return (React.createElement(NxP, { className: "nx-form__required-field-notice" },
        React.createElement("span", { className: "nx-form__required-field-asterisk" }, "*"),
        ' ',
        "Required fields are marked with an asterisk."));
}
export default function NxForm(props) {
    var className = props.className, loading = props.loading, doLoad = props.doLoad, onSubmitProp = props.onSubmit, onCancel = props.onCancel, loadError = props.loadError, submitError = props.submitError, submitErrorTitleMessage = props.submitErrorTitleMessage, validationErrors = props.validationErrors, submitBtnClassesProp = props.submitBtnClasses, submitBtnText = props.submitBtnText, submitMaskState = props.submitMaskState, submitMaskMessage = props.submitMaskMessage, submitMaskSuccessMessage = props.submitMaskSuccessMessage, children = props.children, additionalFooterBtns = props.additionalFooterBtns, showValidationErrors = props.showValidationErrors, formAttrs = __rest(props, ["className", "loading", "doLoad", "onSubmit", "onCancel", "loadError", "submitError", "submitErrorTitleMessage", "validationErrors", "submitBtnClasses", "submitBtnText", "submitMaskState", "submitMaskMessage", "submitMaskSuccessMessage", "children", "additionalFooterBtns", "showValidationErrors"]), formHasValidationErrors = hasValidationErrors(validationErrors), formClasses = classnames('nx-form', className, {
        'nx-form--show-validation-errors': showValidationErrors,
        'nx-form--has-validation-errors': formHasValidationErrors,
        'nx-form--has-submit-error': !!submitError
    }), getChildren = children instanceof Function ? children : always(children), submitBtnClasses = classnames('nx-form__submit-btn', submitBtnClassesProp);
    if (showValidationErrors == null) {
        throw new Error('showValidationErrors is strictly required!');
    }
    function onSubmit(evt) {
        evt.preventDefault();
        onSubmitProp();
    }
    var renderForm = function () {
        return (React.createElement("form", __assign({ className: formClasses, onSubmit: onSubmit }, formAttrs),
            React.createElement(FormAriaContext.Provider, { value: { showValidationErrors: showValidationErrors } }, getChildren()),
            React.createElement("footer", { className: "nx-footer" },
                React.createElement(NxLoadError, { titleMessage: submitErrorTitleMessage || 'An error occurred saving data.', error: submitError, submitOnRetry: true, "aria-label": "form saving errors" }),
                formHasValidationErrors && !submitError &&
                    React.createElement(NxErrorAlert, { className: "nx-form__validation-errors", "aria-label": "form validation errors" },
                        "There were validation errors.",
                        ' ',
                        getFirstValidationError(validationErrors)),
                React.createElement("div", { className: "nx-btn-bar" },
                    additionalFooterBtns,
                    onCancel &&
                        React.createElement(NxButton, { type: "button", onClick: onCancel, className: "nx-form__cancel-btn" }, "Cancel"),
                    React.createElement(NxButton, { variant: "primary", className: submitBtnClasses }, submitBtnText || 'Submit'))),
            submitMaskState != null &&
                React.createElement(NxSubmitMask, { success: submitMaskState, message: submitMaskMessage, successMessage: submitMaskSuccessMessage, "aria-label": "form submit status" })));
    };
    return doLoad ? (React.createElement(NxLoadWrapper, { loading: loading, error: loadError, retryHandler: doLoad }, renderForm)) : renderForm();
}
NxForm.propTypes = propTypes;
NxForm.RequiredFieldNotice = RequiredFieldNotice;
export { propTypes };
//# sourceMappingURL=NxForm.js.map