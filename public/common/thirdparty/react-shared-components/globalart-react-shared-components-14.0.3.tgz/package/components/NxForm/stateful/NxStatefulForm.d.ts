import React from 'react';
import { StatefulProps as Props } from '../types';
export { Props };
export default function NxStatefulForm(props: Props): React.JSX.Element;
//# sourceMappingURL=NxStatefulForm.d.ts.map