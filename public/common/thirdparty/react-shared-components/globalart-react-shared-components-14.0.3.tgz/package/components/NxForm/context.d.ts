import React from 'react';
import { FormAriaContextType } from './types';
export declare const FormAriaContext: React.Context<FormAriaContextType>;
//# sourceMappingURL=context.d.ts.map