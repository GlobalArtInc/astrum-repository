import React from 'react';
import { Props, propTypes } from './types';
declare function NxForm(props: Props): React.JSX.Element;
declare namespace NxForm {
    var propTypes: import("prop-types").ValidationMap<Props>;
    var RequiredFieldNotice: () => React.JSX.Element;
}
export default NxForm;
export { Props, propTypes };
//# sourceMappingURL=NxForm.d.ts.map