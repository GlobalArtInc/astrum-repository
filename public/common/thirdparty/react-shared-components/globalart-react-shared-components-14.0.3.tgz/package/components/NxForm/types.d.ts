import { ComponentPropsWithRef, ReactNode } from 'react';
import * as PropTypes from 'prop-types';
import { ValidationErrors } from '../NxTextInput/types';
export interface FormAriaContextType {
    showValidationErrors: boolean;
}
export interface Props extends Omit<ComponentPropsWithRef<'form'>, 'children'> {
    loading?: boolean | null;
    doLoad?: (() => void) | null;
    onSubmit: () => void;
    onCancel?: (() => void) | null;
    loadError?: string | null;
    submitError?: string | null;
    submitErrorTitleMessage?: string | null;
    validationErrors?: ValidationErrors;
    submitBtnClasses?: string | null;
    submitBtnText?: string | null;
    submitMaskState?: boolean | null;
    submitMaskMessage?: string | null;
    submitMaskSuccessMessage?: string | null;
    children: ReactNode | (() => ReactNode);
    additionalFooterBtns?: ReactNode | null;
    showValidationErrors: boolean;
}
export type StatefulProps = Omit<Props, 'showValidationErrors'>;
export declare const propTypes: PropTypes.ValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map