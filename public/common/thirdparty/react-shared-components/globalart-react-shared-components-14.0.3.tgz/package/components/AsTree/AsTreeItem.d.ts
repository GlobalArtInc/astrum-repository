import React from 'react';
import { ItemProps } from './types';
declare function AsTreeItem(props: ItemProps): React.JSX.Element;
declare namespace AsTreeItem {
    var propTypes: {
        collapsible: import("prop-types").Requireable<boolean>;
        isOpen: import("prop-types").Requireable<boolean>;
        onToggleCollapse: import("prop-types").Requireable<(...args: any[]) => any>;
    };
}
export default AsTreeItem;
//# sourceMappingURL=AsTreeItem.d.ts.map