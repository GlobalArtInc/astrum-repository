import React from 'react';
import { StatefulItemProps } from '../types';
export { StatefulItemProps };
declare function AsTreeStatefulItem({ defaultOpen, ...otherProps }: StatefulItemProps): React.JSX.Element;
declare namespace AsTreeStatefulItem {
    var propTypes: import("prop-types").ValidationMap<StatefulItemProps>;
}
export default AsTreeStatefulItem;
//# sourceMappingURL=AsTreeStatefulItem.d.ts.map