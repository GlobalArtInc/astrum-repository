import React from 'react';
import { ItemLabelProps } from './types';
export default function AsTreeItemLabel(props: ItemLabelProps): React.JSX.Element;
//# sourceMappingURL=AsTreeItemLabel.d.ts.map