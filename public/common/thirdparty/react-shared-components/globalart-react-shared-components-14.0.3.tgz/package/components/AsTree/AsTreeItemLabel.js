var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { useContext } from 'react';
import classnames from 'classnames';
import { useUniqueId } from '../../util/idUtil';
import TreeKeyNavContext from './TreeKeyNavContext';
export default function AsTreeItemLabel(props) {
    var idProp = props.id, className = props.className, onFocusProp = props.onFocus, otherProps = __rest(props, ["id", "className", "onFocus"]), classes = classnames('as-tree__item-label', className), id = useUniqueId('as-tree-item-label', idProp), keyNavContext = useContext(TreeKeyNavContext);
    if (!keyNavContext) {
        throw new TypeError('AsTree.ItemLabel failed to retrieve context information. Was it used outside of an AsTree?');
    }
    var focusParent = keyNavContext.focusParent;
    // Nothing within the label should receive focus on click (or any other way). If something is about to, focus
    // the parent AsTreeItem instead
    function onFocus(evt) {
        if (onFocusProp) {
            onFocusProp(evt);
        }
        // wait until after all the onFocus handlers in ancestor tree elements are processed before we actually perform
        // the focus of the parent item
        Promise.resolve().then(focusParent);
    }
    return React.createElement("span", __assign({ id: id, className: classes, onFocus: onFocus }, otherProps));
}
//# sourceMappingURL=AsTreeItemLabel.js.map