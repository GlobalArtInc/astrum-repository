import React, { ComponentPropsWithRef } from 'react';
import { ItemProps } from './types';
import AsTreeItem from './AsTreeItem';
import AsTreeItemLabel from './AsTreeItemLabel';
import AsTreeStatefulItem from './stateful/AsTreeStatefulItem';
export { ItemProps };
import './AsTree.scss';
declare function AsTree(props: ComponentPropsWithRef<'ul'>): React.JSX.Element;
declare namespace AsTree {
    var Item: typeof AsTreeItem;
    var StatefulItem: typeof AsTreeStatefulItem;
    var ItemLabel: typeof AsTreeItemLabel;
}
export default AsTree;
//# sourceMappingURL=AsTree.d.ts.map