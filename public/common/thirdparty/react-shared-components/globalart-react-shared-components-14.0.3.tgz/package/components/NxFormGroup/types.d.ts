import { ReactNode, ReactElement, ComponentPropsWithRef } from 'react';
import * as PropTypes from 'prop-types';
interface ChildrenProps {
    id?: string | null;
    'aria-describedby'?: string | null;
    'aria-required'?: boolean | null;
}
export interface Props extends ComponentPropsWithRef<'div'> {
    label: Exclude<ReactNode, null | undefined>;
    sublabel?: ReactNode | null;
    isRequired?: boolean | null;
    children: ReactElement<ChildrenProps>;
}
export declare const propTypes: PropTypes.ValidationMap<Props>;
export {};
//# sourceMappingURL=types.d.ts.map