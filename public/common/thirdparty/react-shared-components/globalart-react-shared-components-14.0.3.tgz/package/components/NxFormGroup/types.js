import * as PropTypes from 'prop-types';
export var propTypes = {
    label: PropTypes.node.isRequired,
    sublabel: PropTypes.node,
    isRequired: PropTypes.bool
};
//# sourceMappingURL=types.js.map