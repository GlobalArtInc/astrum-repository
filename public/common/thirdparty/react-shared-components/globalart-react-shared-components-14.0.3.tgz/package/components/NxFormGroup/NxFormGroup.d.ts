import React from 'react';
import { Props } from './types';
export { Props };
declare function NxFormGroup({ className, label, sublabel, children, isRequired, ...attrs }: Props): React.JSX.Element;
declare namespace NxFormGroup {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default NxFormGroup;
//# sourceMappingURL=NxFormGroup.d.ts.map