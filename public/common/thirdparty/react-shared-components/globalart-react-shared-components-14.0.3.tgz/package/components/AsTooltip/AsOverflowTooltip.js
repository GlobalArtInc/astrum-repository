var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { useRef, useState, useEffect, useCallback } from 'react';
import useMergedRef from '@react-hook/merged-ref';
import { textContent } from '../../util/childUtil';
import useResizeObserver from '../../util/useResizeObserver';
import { overflowTooltipPropTypes } from './types';
import AsTooltip from './AsTooltip';
import { any, defaultTo, map, sum } from 'ramda';
import batch from './updateBatcher';
function parsePx(pxStr) {
    var _a;
    var unitStrippedStr = (_a = pxStr === null || pxStr === void 0 ? void 0 : pxStr.match(/(.*)px$/)) === null || _a === void 0 ? void 0 : _a[1];
    return unitStrippedStr == null ? null : parseFloat(unitStrippedStr);
}
// Rounding floats to a particular number of decimal places is an uncertain thing, since floats are internally
// coded in base 2 and not base 10. So instead we round to a "bicemals" place (not sure if that's the real world)
var ROUNDING_BICEMALS_PLACE = 5;
function roundTo5Bicemals(num) {
    var multiplier = 1 << ROUNDING_BICEMALS_PLACE;
    return Math.round(num * multiplier) / multiplier;
}
function sanityCheckParsedSizes(paddingRight, borderRightWidth) {
    // We know this happens in JSDOM; we don't need warnings about it there. The warnings are so we notice
    // if this ever happens in a real browser
    if (!navigator.userAgent.includes('jsdom')) {
        if (paddingRight == null) {
            console.warn('Got non-pixel computed value for padding-right, assuming 0');
        }
        if (borderRightWidth == null) {
            console.warn('Got non-pixel computed value for border-right-width, assuming 0');
        }
    }
}
function getContentBoxRight(el) {
    var boundingClientRect = el.getBoundingClientRect();
    if (el instanceof HTMLElement) {
        var _a = getComputedStyle(el), paddingRight = _a.paddingRight, borderRightWidth = _a.borderRightWidth, parsedSizes = map(parsePx, [paddingRight, borderRightWidth]), paddingBorderSum = sum(map(defaultTo(0), parsedSizes));
        // I've seen cases where paddings defined in % units don't get converted to px on inline elements.
        // This would be a very rare case where expected behavior is unclear, so just warn about it
        sanityCheckParsedSizes.apply(void 0, parsedSizes);
        return boundingClientRect.right - paddingBorderSum;
    }
    else {
        return boundingClientRect.right;
    }
}
// Get the rightmost edge of the bounding rectangles of all text content children of el
function getTextBoundingRectRight(el) {
    var nodeIterator = document.createNodeIterator(el, NodeFilter.SHOW_TEXT), range = new Range();
    var right;
    for (var node = nodeIterator.nextNode(); node != null; node = nodeIterator.nextNode()) {
        range.selectNode(node);
        var nodeBoundingBox = range.getBoundingClientRect();
        // accumulate farthest right
        right = right != null && right > nodeBoundingBox.right ? right : nodeBoundingBox.right;
    }
    return right;
}
// Note: this won't detect overflowing non-text content, but for the purpose of an overflow tooltip we
// only care about text content anyway
function isOverflowing(el) {
    var contentBoxRight = getContentBoxRight(el), textBoundingRectRight = getTextBoundingRectRight(el);
    // rounding due to discrepancies within the browser engine at non-100% zoom levels
    return textBoundingRectRight ? roundTo5Bicemals(contentBoxRight) < roundTo5Bicemals(textBoundingRectRight) : false;
}
function selfOrChildrenOverflowing(el) {
    return isOverflowing(el) || any(selfOrChildrenOverflowing, Array.from(el.children));
}
export default function AsOverflowTooltip(props) {
    var title = props.title, children = props.children, otherProps = __rest(props, ["title", "children"]), computedTitle = title || textContent(children), _a = useState(false), needsTooltip = _a[0], setNeedsTooltip = _a[1], ref = useRef(null), isUnmounted = useRef(false), childRef = children.props.ref, mergedRef = useMergedRef(ref, childRef !== null && childRef !== void 0 ? childRef : null), childrenWithRef = React.cloneElement(children, { ref: mergedRef });
    var updateNeedsTooltip = useCallback(function updateNeedsTooltip() {
        var el = ref.current;
        batch(function () {
            if (!isUnmounted.current) {
                setNeedsTooltip(!!el && selfOrChildrenOverflowing(el));
            }
        });
    }, []);
    // check the width on initial layout and any time computedTitle changes
    useEffect(updateNeedsTooltip, [computedTitle]);
    useEffect(function () { return function () { isUnmounted.current = true; }; }, []);
    // check the width any time the element resizes
    useResizeObserver(ref, updateNeedsTooltip);
    return (React.createElement(AsTooltip, __assign({}, otherProps, { title: needsTooltip ? computedTitle : '' }), childrenWithRef));
}
AsOverflowTooltip.propTypes = overflowTooltipPropTypes;
//# sourceMappingURL=AsOverflowTooltip.js.map