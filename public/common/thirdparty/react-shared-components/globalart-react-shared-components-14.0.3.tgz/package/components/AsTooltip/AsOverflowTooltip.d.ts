import React from 'react';
import { OverflowTooltipProps } from './types';
export { OverflowTooltipProps };
declare function AsOverflowTooltip<C extends HTMLElement = HTMLElement>(props: OverflowTooltipProps<C>): React.JSX.Element;
declare namespace AsOverflowTooltip {
    var propTypes: Omit<import("prop-types").ValidationMap<import("./types").Props<HTMLElement>>, "open">;
}
export default AsOverflowTooltip;
//# sourceMappingURL=AsOverflowTooltip.d.ts.map