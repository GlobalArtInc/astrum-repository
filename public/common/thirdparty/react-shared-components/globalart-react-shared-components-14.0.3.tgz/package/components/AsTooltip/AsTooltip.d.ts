import React, { FunctionComponent } from 'react';
import { Props } from './types';
export { Props, propTypes, TooltipPlacement } from './types';
import './AsToolTip.scss';
export declare const TooltipContext: React.Context<boolean>;
declare const AsTooltip: FunctionComponent<Props>;
export default AsTooltip;
//# sourceMappingURL=AsTooltip.d.ts.map