import React from 'react';
import { Props } from './types';
import './AsMeter.scss';
export { Props };
declare function AsMeter(props: Props): React.JSX.Element;
declare namespace AsMeter {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default AsMeter;
//# sourceMappingURL=AsMeter.d.ts.map