import { ComponentPropsWithoutRef, ComponentPropsWithRef } from 'react';
import * as PropTypes from 'prop-types';
export type InputAttributesProp = Omit<ComponentPropsWithoutRef<'input'>, 'disabled' | 'checked' | 'readonly' | 'onChange'>;
export interface Props extends Omit<ComponentPropsWithRef<'label'>, 'onChange'> {
    inputId?: string | null;
    onChange?: ((newVal: boolean) => void) | null;
    isChecked: boolean;
    disabled?: boolean | null;
    inputAttributes?: InputAttributesProp;
}
export type PropsWithAnyInputAttributes = Props & {
    inputAttributes?: {
        [key: string]: unknown;
    };
};
export declare const propTypes: PropTypes.ValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map