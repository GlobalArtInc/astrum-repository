import React from 'react';
import { Props } from './types';
export { Props } from './types';
declare function NxStatefulToggle({ defaultChecked, onChange, ...otherProps }: Props): React.JSX.Element;
declare namespace NxStatefulToggle {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default NxStatefulToggle;
//# sourceMappingURL=NxStatefulToggle.d.ts.map