import { ComponentPropsWithRef } from 'react';
import * as PropTypes from 'prop-types';
import { InputAttributesProp } from '../types';
export interface Props extends Omit<ComponentPropsWithRef<'label'>, 'onChange'> {
    inputId?: string | null;
    onChange?: ((isChecked: boolean) => void) | null;
    defaultChecked: boolean;
    disabled?: boolean | null;
    inputAttributes?: InputAttributesProp;
}
export declare const propTypes: PropTypes.ValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map