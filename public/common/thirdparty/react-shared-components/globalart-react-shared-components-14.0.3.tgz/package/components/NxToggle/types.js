import * as PropTypes from 'prop-types';
export var propTypes = {
    inputId: PropTypes.string,
    onChange: PropTypes.func,
    isChecked: PropTypes.bool.isRequired,
    disabled: PropTypes.bool,
    inputAttributes: PropTypes.object
};
//# sourceMappingURL=types.js.map