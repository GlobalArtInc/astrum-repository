import React from 'react';
import './NxToggle.scss';
import { Props } from './types';
export { Props } from './types';
declare function NxToggle(props: Props): React.JSX.Element;
declare namespace NxToggle {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default NxToggle;
//# sourceMappingURL=NxToggle.d.ts.map