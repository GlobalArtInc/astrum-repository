import React from 'react';
import { Props } from './types';
export { Props };
export default function AsScrollRender<T extends HTMLElement = HTMLElement>(props: Props<T>): React.ReactElement<{
    children?: React.ReactNode | undefined;
} & React.RefAttributes<T> & Pick<React.DOMAttributes<T>, "onScroll">, string | React.JSXElementConstructor<any>>;
//# sourceMappingURL=AsScrollRender.d.ts.map