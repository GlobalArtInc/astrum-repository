/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { useCallback, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { always, clamp, dec, identity, inc, isNil } from 'ramda';
import { useThrottleCallback } from '@react-hook/throttle';
import useResizeObserver from '../../util/useResizeObserver';
// intended to wrap division operations that may result in NaN, returns zero instead in that case
var divOrZero = function (x, y) { return x === 0 || y === 0 ? 0 : x / y; };
var DEFAULT_INITIAL_CHILD_COUNT = 40;
export default function AsScrollRender(props) {
    var _a;
    var children = props.children, reuseChildren = props.reuseChildren, initialChildCount = props.initialChildCount, spacerEl = props.spacerEl, fullParent = children, childArray = useMemo(function () { return React.Children.toArray(fullParent.props.children); }, [fullParent.props.children]), childCount = childArray.length, parentRef = useRef(null), leadingSpacerRef = useRef(null), leadingSpacerRefFn = function (e) { leadingSpacerRef.current = e; }, trailingSpacerRef = useRef(null), trailingSpacerRefFn = function (e) { trailingSpacerRef.current = e; }, _b = useState(null), parentHeight = _b[0], setParentHeight = _b[1], _c = useState(null), childHeight = _c[0], setChildHeight = _c[1], normalizedChildHeight = childHeight !== null && childHeight !== void 0 ? childHeight : 0, renderedChildCount = parentHeight == null || childHeight == null ?
        null : Math.min(Math.ceil(divOrZero(parentHeight, childHeight)) + 2, childCount), cloneWithKey = function (child, idx) {
        return React.cloneElement(child, { key: idx % renderedChildCount });
    }, keyedChildren = useMemo(function () { return reuseChildren === false || isNil(renderedChildCount) ? childArray : childArray.map(cloneWithKey); }, [childArray, reuseChildren, renderedChildCount]), sumChildHeight = normalizedChildHeight * childCount, renderedChildHeight = renderedChildCount == null ? 0 : normalizedChildHeight * renderedChildCount, _d = useState(0), firstRenderedChildIdx = _d[0], setFirstRenderedChildIdx = _d[1], renderedChildCountWithDefault = (_a = renderedChildCount !== null && renderedChildCount !== void 0 ? renderedChildCount : initialChildCount) !== null && _a !== void 0 ? _a : DEFAULT_INITIAL_CHILD_COUNT, renderedRealChildren = keyedChildren.slice(firstRenderedChildIdx, firstRenderedChildIdx + renderedChildCountWithDefault), sumSpacerHeight = sumChildHeight - renderedChildHeight, clampSpacerHeight = clamp(0, sumSpacerHeight), leadingSpacerHeight = clampSpacerHeight(firstRenderedChildIdx * normalizedChildHeight), trailingSpacerHeight = renderedChildCount == null ? 0 : clampSpacerHeight(sumChildHeight - (leadingSpacerHeight + renderedChildCount * normalizedChildHeight));
    var renderedChildren = childCount ? (React.createElement(React.Fragment, null,
        React.createElement(spacerEl !== null && spacerEl !== void 0 ? spacerEl : 'div', {
            ref: leadingSpacerRefFn,
            role: 'presentation',
            className: 'as-scroll-render__spacer',
            style: { height: leadingSpacerHeight }
        }),
        renderedRealChildren,
        React.createElement(spacerEl !== null && spacerEl !== void 0 ? spacerEl : 'div', {
            ref: trailingSpacerRefFn,
            role: 'presentation',
            className: 'as-scroll-render__spacer',
            style: { height: trailingSpacerHeight }
        }))) : null;
    var updateRendering = useThrottleCallback(useCallback(function updateRendering() {
        var _a, _b, _c, _d;
        var scrollTop = (_b = (_a = parentRef.current) === null || _a === void 0 ? void 0 : _a.scrollTop) !== null && _b !== void 0 ? _b : 0, parentTop = (_c = parentRef.current) === null || _c === void 0 ? void 0 : _c.getBoundingClientRect().top, leadingSpacerTop = (_d = leadingSpacerRef.current) === null || _d === void 0 ? void 0 : _d.getBoundingClientRect().top, topDifference = (parentTop !== null && parentTop !== void 0 ? parentTop : 0) - (leadingSpacerTop !== null && leadingSpacerTop !== void 0 ? leadingSpacerTop : 0), topTooClose = topDifference < normalizedChildHeight, topTooFar = topDifference > normalizedChildHeight * 2, adjust = topTooClose ? dec :
            topTooFar ? inc :
                identity, clampFirstRenderedChildIdx = renderedChildCount == null ? always(0) : clamp(0, childCount - renderedChildCount), newFirstRenderedChildIdx = clampFirstRenderedChildIdx(adjust(Math.floor(divOrZero(scrollTop, normalizedChildHeight)) - 2));
        setFirstRenderedChildIdx(newFirstRenderedChildIdx);
    }, [childCount, normalizedChildHeight, renderedChildCount, renderedChildHeight, sumChildHeight]), 15);
    var adjustedParent = React.cloneElement(fullParent, {
        ref: parentRef,
        children: renderedChildren,
        onScroll: updateRendering
    });
    useLayoutEffect(function () {
        var _a, _b, _c, _d;
        if (parentRef.current) {
            // note: not counting the spacer
            var firstChild = parentRef.current.children[1], secondChild = parentRef.current.children[2];
            if (!secondChild) {
                setChildHeight(0);
            }
            else {
                var firstChildTop = (_b = (_a = firstChild === null || firstChild === void 0 ? void 0 : firstChild.getBoundingClientRect()) === null || _a === void 0 ? void 0 : _a.top) !== null && _b !== void 0 ? _b : 0, secondChildTop = (_d = (_c = secondChild === null || secondChild === void 0 ? void 0 : secondChild.getBoundingClientRect()) === null || _c === void 0 ? void 0 : _c.top) !== null && _d !== void 0 ? _d : 0;
                setChildHeight(secondChildTop - firstChildTop);
            }
            setParentHeight(parentRef.current.clientHeight);
        }
    }, [childCount === 0]);
    useResizeObserver(parentRef, useCallback(function (_a) {
        var blockSize = _a.contentBoxSize[0].blockSize;
        setParentHeight(blockSize);
    }, []));
    return adjustedParent;
}
//# sourceMappingURL=AsScrollRender.js.map