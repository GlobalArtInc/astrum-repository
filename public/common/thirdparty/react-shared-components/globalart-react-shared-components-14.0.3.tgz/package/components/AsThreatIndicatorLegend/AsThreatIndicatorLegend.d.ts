import React from 'react';
import { AsThreatIndicatorLegendProps } from './types';
import './AsThreatIndicatorLegend.scss';
declare function AsThreatIndicatorLegend(props: AsThreatIndicatorLegendProps): React.JSX.Element | null;
declare namespace AsThreatIndicatorLegend {
    var propTypes: import("prop-types").ValidationMap<AsThreatIndicatorLegendProps>;
}
export default AsThreatIndicatorLegend;
export { AsThreatIndicatorLegendProps, asThreatIndicatorLegendPropTypes } from './types';
//# sourceMappingURL=AsThreatIndicatorLegend.d.ts.map