import { ComponentPropsWithRef } from 'react';
import { ValidationMap } from 'prop-types';
import { ThreatLevelCategory } from '../../util/threatLevels';
export interface AsThreatIndicatorLegendProps extends ComponentPropsWithRef<'div'> {
    critical?: boolean | null;
    severe?: boolean | null;
    moderate?: boolean | null;
    low?: boolean | null;
    none?: boolean | null;
    unspecified?: boolean | null;
    vertical?: boolean | null;
    header?: string | null;
}
export declare const asThreatIndicatorLegendPropTypes: ValidationMap<AsThreatIndicatorLegendProps>;
export interface ThreatProps {
    threatType: ThreatLevelCategory;
}
//# sourceMappingURL=types.d.ts.map