import * as PropTypes from 'prop-types';
export var propTypes = {
    criticalCount: PropTypes.number,
    severeCount: PropTypes.number,
    moderateCount: PropTypes.number,
    lowCount: PropTypes.number,
    noneCount: PropTypes.number,
    unspecifiedCount: PropTypes.number,
    maxDigits: PropTypes.number
};
//# sourceMappingURL=types.js.map