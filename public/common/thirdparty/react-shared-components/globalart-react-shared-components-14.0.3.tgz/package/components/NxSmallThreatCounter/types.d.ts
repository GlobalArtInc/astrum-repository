import { ComponentPropsWithRef, ReactNode } from 'react';
import * as PropTypes from 'prop-types';
import { ThreatLevelCategory } from '../../util/threatLevels';
export interface BaseCounterProps {
    category: ThreatLevelCategory;
    count: number;
    display: ReactNode;
    children?: ReactNode;
}
export type CounterProps = Omit<BaseCounterProps, 'children' | 'display'>;
export interface MaxDigitCounterProps extends CounterProps {
    maxDigits: number;
}
export interface Props extends Omit<ComponentPropsWithRef<'div'>, 'children'> {
    criticalCount?: number | null;
    severeCount?: number | null;
    moderateCount?: number | null;
    lowCount?: number | null;
    noneCount?: number | null;
    unspecifiedCount?: number | null;
    maxDigits?: number | null;
}
export declare const propTypes: PropTypes.ValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map