import React from 'react';
import { Props } from './types';
export { Props } from './types';
import './NxSmallThreatCounter.scss';
declare function NxSmallThreatCounter(props: Props): React.JSX.Element | null;
declare namespace NxSmallThreatCounter {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default NxSmallThreatCounter;
//# sourceMappingURL=NxSmallThreatCounter.d.ts.map