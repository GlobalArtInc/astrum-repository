import React from 'react';
import { Props } from './types';
import './NxSmallTag.scss';
export { Props } from './types';
declare function NxSmallTag(props: Props): React.JSX.Element;
declare namespace NxSmallTag {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default NxSmallTag;
//# sourceMappingURL=NxSmallTag.d.ts.map