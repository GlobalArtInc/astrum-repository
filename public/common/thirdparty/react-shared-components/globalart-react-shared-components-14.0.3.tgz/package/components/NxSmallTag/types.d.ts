import { ComponentPropsWithRef, ReactNode } from 'react';
import * as PropTypes from 'prop-types';
export declare const NX_SMALL_TAG_COLORS: readonly ["blue", "green", "indigo", "orange", "pink", "purple", "red", "teal", "turquoise"];
export type NX_SMALL_TAG_COLOR_TYPE = (typeof NX_SMALL_TAG_COLORS)[number];
export interface Props extends Omit<ComponentPropsWithRef<'label'>, 'color'> {
    children: ReactNode;
    color?: NX_SMALL_TAG_COLOR_TYPE | null;
}
export declare const propTypes: PropTypes.ValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map