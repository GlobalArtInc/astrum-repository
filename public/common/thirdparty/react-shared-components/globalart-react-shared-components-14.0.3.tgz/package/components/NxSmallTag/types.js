import * as PropTypes from 'prop-types';
export var NX_SMALL_TAG_COLORS = ['blue', 'green', 'indigo', 'orange', 'pink', 'purple', 'red', 'teal', 'turquoise'];
export var propTypes = {
    children: PropTypes.node.isRequired,
    color: PropTypes.oneOf(NX_SMALL_TAG_COLORS)
};
//# sourceMappingURL=types.js.map