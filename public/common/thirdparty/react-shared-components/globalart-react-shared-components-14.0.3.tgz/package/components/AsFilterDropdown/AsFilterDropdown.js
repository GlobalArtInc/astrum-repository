var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { useRef } from 'react';
import { propEq, any } from 'ramda';
import classnames from 'classnames';
import { faFilter } from '@fortawesome/free-solid-svg-icons';
import { propTypes } from './types';
import AsCheckbox from '../AsCheckbox/AsCheckbox';
import MultiSelectCounter from '../Counter/MultiSelectCounter';
import AsFontAwesomeIcon from '../AsFontAwesomeIcon/AsFontAwesomeIcon';
import AsDropdown from '../AsDropdown/AsDropdown';
import Close from '../../icons/Close';
import './AsFilterDropdown.scss';
export default function AsFilterDropdown(props) {
    var onChange = props.onChange, selectedIds = props.selectedIds, isOpen = props.isOpen, onToggleCollapse = props.onToggleCollapse, options = props.options, classNameProp = props.className, showReset = props.showReset, placeholder = props.placeholder, attrs = __rest(props, ["onChange", "selectedIds", "isOpen", "onToggleCollapse", "options", "className", "showReset", "placeholder"]), menuRef = useRef(null), className = classnames('as-filter-dropdown', classNameProp), hasSelection = !!selectedIds.size;
    // Throw an error if one of the selectedIds is not part of the available options
    selectedIds.forEach(function (itemId) {
        if (!any(propEq(itemId, 'id'), options)) {
            throw new Error("You are attempting to select \"".concat(itemId, "\", but it is not part of the available options"));
        }
    });
    function toggle(id) {
        var newSelected = new Set(selectedIds);
        if (newSelected.has(id)) {
            newSelected.delete(id);
        }
        else {
            newSelected.add(id);
        }
        onChange(newSelected, id);
    }
    // Avoid closing dropdown when a click occurs within it (e.g. when a checkbox is toggled)
    function onCloseClick(evt) {
        var target = evt.target, menuEl = menuRef.current;
        if (menuEl && target instanceof Element && menuEl.contains(target)) {
            evt.preventDefault();
        }
    }
    function onResetClick() {
        onChange(new Set());
    }
    var renderOption = function (_a) {
        var id = _a.id, displayName = _a.displayName;
        return (React.createElement(AsCheckbox, { key: id, onChange: function () { return toggle(id); }, isChecked: selectedIds.has(id) }, displayName));
    };
    var renderCounter = function () { return React.createElement(MultiSelectCounter, { options: options, selectedIds: selectedIds }); }, dropdownLabel = (React.createElement(React.Fragment, null,
        React.createElement(AsFontAwesomeIcon, { icon: faFilter }),
        hasSelection ? renderCounter() : React.createElement("span", null, placeholder !== null && placeholder !== void 0 ? placeholder : 'Filter')));
    var resetBtn = (React.createElement("button", { key: "reset-btn", disabled: !hasSelection, className: "as-dropdown-button as-filter-dropdown__reset", onClick: onResetClick },
        React.createElement(Close, null),
        React.createElement("span", null, "Reset")));
    var checkboxes = options.map(renderOption), children = showReset === false ? checkboxes : __spreadArray(__spreadArray([], checkboxes, true), [resetBtn], false);
    return (React.createElement(AsDropdown, __assign({ className: className, label: dropdownLabel, isOpen: isOpen, onToggleCollapse: onToggleCollapse, onCloseClick: onCloseClick, menuRef: menuRef }, attrs), children));
}
AsFilterDropdown.propTypes = propTypes;
//# sourceMappingURL=AsFilterDropdown.js.map