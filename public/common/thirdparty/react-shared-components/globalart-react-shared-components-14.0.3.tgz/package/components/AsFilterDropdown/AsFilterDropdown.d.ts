import React from 'react';
import { Props } from './types';
import './AsFilterDropdown.scss';
export { Props };
declare function AsFilterDropdown<T extends string | number = string>(props: Props<T>): React.JSX.Element;
declare namespace AsFilterDropdown {
    var propTypes: {
        isOpen: import("prop-types").Validator<boolean>;
        onToggleCollapse: import("prop-types").Validator<(...args: any[]) => any>;
        onChange: import("prop-types").Validator<(...args: any[]) => any>;
        showReset: import("prop-types").Requireable<boolean>;
        placeholder: import("prop-types").Requireable<string>;
    };
}
export default AsFilterDropdown;
//# sourceMappingURL=AsFilterDropdown.d.ts.map