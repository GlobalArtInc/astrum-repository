import { Props as AsFilterDropdownProps } from '../types';
declare const propsToOmit: readonly ["isOpen", "onToggleCollapse"];
export type Props<T extends string | number = string> = Omit<AsFilterDropdownProps<T>, (typeof propsToOmit)[number]>;
export declare const propTypes: Omit<{
    isOpen: import("prop-types").Validator<boolean>;
    onToggleCollapse: import("prop-types").Validator<(...args: any[]) => any>;
    onChange: import("prop-types").Validator<(...args: any[]) => any>;
    showReset: import("prop-types").Requireable<boolean>;
    placeholder: import("prop-types").Requireable<string>;
}, "isOpen" | "onToggleCollapse">;
export {};
//# sourceMappingURL=types.d.ts.map