var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import classnames from 'classnames';
import { propTypes } from './types';
import './NxGlobalHeader2.scss';
var defaultSonatypeLogoLight = require('../../assets/img/sonatype-header.svg'), defaultSonatypeLogoDark = require('../../assets/img/sonatype-header-dark-mode.svg'), defaultAltText = 'Sonatype';
export default function NxGlobalHeader2(_a) {
    var logoProps = _a.logoProps, homeHref = _a.homeHref, className = _a.className, children = _a.children, otherProps = __rest(_a, ["logoProps", "homeHref", "className", "children"]);
    var classes = classnames(className, 'nx-global-header-2'), _b = logoProps !== null && logoProps !== void 0 ? logoProps : {}, _c = _b.lightPath, lightPath = _c === void 0 ? defaultSonatypeLogoLight : _c, _d = _b.darkPath, darkPath = _d === void 0 ? defaultSonatypeLogoDark : _d, _e = _b.altText, altText = _e === void 0 ? defaultAltText : _e, isDefaultLogo = !logoProps, lightLogoClasses = classnames('nx-global-header-2__logo', 'nx-global-header-2__logo--light', {
        'nx-global-header-2__logo-light--default-logo': isDefaultLogo
    }), darkLogoClasses = classnames('nx-global-header-2__logo', 'nx-global-header-2__logo--dark', {
        'nx-global-header-2__logo-dark--default-logo': isDefaultLogo
    });
    return (React.createElement("header", __assign({ className: classes }, otherProps),
        React.createElement("a", { href: homeHref, className: "nx-global-header-2__home-link", "aria-label": "Home" },
            React.createElement("img", { src: lightPath, alt: altText, className: lightLogoClasses }),
            React.createElement("img", { src: darkPath, alt: altText, className: darkLogoClasses })),
        React.createElement("div", { className: "nx-global-header-2__actions" }, children)));
}
NxGlobalHeader2.propTypes = propTypes;
export { propTypes } from './types';
//# sourceMappingURL=NxGlobalHeader2.js.map