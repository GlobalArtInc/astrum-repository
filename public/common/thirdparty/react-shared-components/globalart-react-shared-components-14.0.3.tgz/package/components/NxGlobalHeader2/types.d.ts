import * as PropTypes from 'prop-types';
import { ComponentPropsWithRef } from 'react';
export interface LogoProps {
    lightPath: string;
    darkPath: string;
    altText: string;
}
export interface Props extends ComponentPropsWithRef<'header'> {
    logoProps?: LogoProps | null;
    homeHref: string;
}
export declare const propTypes: PropTypes.ValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map