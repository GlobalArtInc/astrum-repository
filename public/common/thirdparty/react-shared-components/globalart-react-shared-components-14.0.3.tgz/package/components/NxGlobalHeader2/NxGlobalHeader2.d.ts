import React from 'react';
import { Props } from './types';
import './NxGlobalHeader2.scss';
declare function NxGlobalHeader2({ logoProps, homeHref, className, children, ...otherProps }: Props): React.JSX.Element;
declare namespace NxGlobalHeader2 {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default NxGlobalHeader2;
export { Props, propTypes } from './types';
//# sourceMappingURL=NxGlobalHeader2.d.ts.map