import { ComponentPropsWithoutRef, Ref } from 'react';
import * as PropTypes from 'prop-types';
export interface SelectedFileProps {
    ref?: Ref<HTMLSpanElement>;
    descriptionId?: string;
    file: File;
    onDismiss: () => void;
}
export interface MultiSelectedFileProps extends Omit<SelectedFileProps, 'onDismiss'> {
    onDismiss: (fileObj: File) => void;
}
export interface StatefulProps extends Omit<ComponentPropsWithoutRef<'input'>, 'onChange' | 'multiple'> {
    onChange?: ((files: FileList | null) => void) | null;
    isRequired?: boolean | null;
    ref?: Ref<HTMLDivElement>;
}
export interface StateProps {
    files: FileList | null;
    isPristine?: boolean | null;
}
export type Props = StatefulProps & StateProps & {
    onChange: (files: FileList | null) => void;
};
export declare const statefulPropTypes: PropTypes.ValidationMap<StatefulProps>;
export declare const propTypes: PropTypes.ValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map