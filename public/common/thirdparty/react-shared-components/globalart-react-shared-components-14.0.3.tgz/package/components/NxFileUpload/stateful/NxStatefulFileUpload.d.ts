import React from 'react';
import { StatefulProps as Props } from '../types';
export { Props };
declare function NxStatefulFileUpload(props: Props): React.JSX.Element;
declare namespace NxStatefulFileUpload {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default NxStatefulFileUpload;
//# sourceMappingURL=NxStatefulFileUpload.d.ts.map