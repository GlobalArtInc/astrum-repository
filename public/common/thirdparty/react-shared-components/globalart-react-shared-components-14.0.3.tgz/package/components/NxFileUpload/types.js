var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
import * as PropTypes from 'prop-types';
export var statefulPropTypes = {
    onChange: PropTypes.func,
    isRequired: PropTypes.bool
};
export var propTypes = __assign(__assign({}, statefulPropTypes), { onChange: PropTypes.func.isRequired, files: PropTypes.object, isPristine: PropTypes.bool });
//# sourceMappingURL=types.js.map