import React from 'react';
import { Props } from '../types';
export { Props };
import './NxMultiFileUpload.scss';
declare function NxMultiFileUpload(props: Props): React.JSX.Element;
declare namespace NxMultiFileUpload {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default NxMultiFileUpload;
//# sourceMappingURL=NxMultiFileUpload.d.ts.map