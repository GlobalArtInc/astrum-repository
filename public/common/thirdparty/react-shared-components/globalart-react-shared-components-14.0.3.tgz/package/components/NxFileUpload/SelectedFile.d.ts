import React from 'react';
import { SelectedFileProps } from './types';
export { SelectedFileProps };
export default function SelectedFile({ ref, file, onDismiss, descriptionId }: SelectedFileProps): React.JSX.Element;
//# sourceMappingURL=SelectedFile.d.ts.map