import React from 'react';
import { Props } from './types';
export { Props };
import './NxFileUpload.scss';
declare function NxFileUpload(props: Props): React.JSX.Element;
declare namespace NxFileUpload {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default NxFileUpload;
//# sourceMappingURL=NxFileUpload.d.ts.map