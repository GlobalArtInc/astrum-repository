export function initialState(files) {
    return { isPristine: true, files: files };
}
export function userInput(files) {
    return { isPristine: false, files: files };
}
//# sourceMappingURL=stateHelpers.js.map