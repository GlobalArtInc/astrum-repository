import { StateProps } from './types';
export declare function initialState(files: FileList | null): StateProps;
export declare function userInput(files: FileList | null): StateProps;
//# sourceMappingURL=stateHelpers.d.ts.map