var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { useRef, useContext, useEffect } from 'react';
import { faExclamationCircle } from '@fortawesome/free-solid-svg-icons';
import classnames from 'classnames';
import { without, indexOf } from 'ramda';
import SelectedFile from '../SelectedFile';
import NxFontAwesomeIcon from '../../NxFontAwesomeIcon/NxFontAwesomeIcon';
import NxButton from '../../NxButton/NxButton';
import { FormAriaContext } from '../../NxForm/context';
import { useUniqueId } from '../../../util/idUtil';
import { propTypes } from '../types';
import './NxMultiFileUpload.scss';
function SelectedFileWrapper(_a) {
    var file = _a.file, onDismissProp = _a.onDismiss;
    var fileRef = useRef(null);
    function onDismiss() {
        onDismissProp(file);
    }
    useEffect(function () {
        if (fileRef.current) {
            fileRef.current.scrollIntoView({ block: 'nearest' });
        }
    }, []);
    return (React.createElement(SelectedFile, { file: file, onDismiss: onDismiss, ref: fileRef }));
}
export default function NxMultiFileUpload(props) {
    var ref = props.ref, classNameProp = props.className, onChangeProp = props.onChange, files = props.files, isRequired = props.isRequired, isPristine = props.isPristine, id = props.id, disabled = props.disabled, attrs = __rest(props, ["ref", "className", "onChange", "files", "isRequired", "isPristine", "id", "disabled"]), isFileSelected = !!(files === null || files === void 0 ? void 0 : files.length), formShowValidationErrors = useContext(FormAriaContext).showValidationErrors, showValidationErrors = formShowValidationErrors || !isPristine, showError = isRequired && showValidationErrors && !isFileSelected, className = classnames('nx-multi-file-upload', 'nx-file-upload', classNameProp), noFileMessageClassName = classnames('nx-file-upload__no-file-message', {
        'nx-file-upload__no-file-message--invalid': showError,
        'hidden': isFileSelected
    }), noFileMessageId = useUniqueId('nx-file-upload__no-file-message'), inputRef = useRef(null), inputId = useUniqueId('nx-multi-file-upload-input', id), selectedFilesContainerRef = useRef(null), selectedFilesContainerId = useUniqueId('nx-multi-file-upload-container-files'), totalFilesSelected = isFileSelected ? "".concat(files.length, " selected files") : 'No file selected', validationErrorId = useUniqueId('nx-multi-file-upload-validation-error'), 
    // Stable React key values for each File object
    fileKeys = useRef(new WeakMap()), nextKey = useRef(0);
    function getKey(file) {
        var existingKey = fileKeys.current.get(file);
        if (existingKey) {
            return existingKey;
        }
        else {
            var newKey = nextKey.current;
            nextKey.current++;
            fileKeys.current.set(file, newKey);
            return newKey;
        }
    }
    function combineFileLists() {
        var fileLists = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            fileLists[_i] = arguments[_i];
        }
        // DataTransfer has the only known API in which FileLists can be programatically constructed from various Files.
        var dataTransferObject = new DataTransfer();
        for (var _a = 0, fileLists_1 = fileLists; _a < fileLists_1.length; _a++) {
            var list = fileLists_1[_a];
            var listArray = Array.from(list);
            for (var _b = 0, listArray_1 = listArray; _b < listArray_1.length; _b++) {
                var file = listArray_1[_b];
                dataTransferObject.items.add(file);
            }
        }
        return dataTransferObject.files;
    }
    function onChange(evt) {
        var inputFiles = evt.currentTarget.files;
        // files refers to the previous file selection, which will be null the first time OnChange is called
        var returnedFileList = inputFiles ? combineFileLists(files !== null && files !== void 0 ? files : [], inputFiles) : null, normalizedFiles = (returnedFileList === null || returnedFileList === void 0 ? void 0 : returnedFileList.length) ? returnedFileList : null;
        onChangeProp(normalizedFiles);
    }
    function openPicker() {
        var _a;
        (_a = inputRef.current) === null || _a === void 0 ? void 0 : _a.click();
    }
    function onDismiss(fileObj) {
        var _a, _b, _c;
        var closeBtns = Array.from((_b = (_a = selectedFilesContainerRef.current) === null || _a === void 0 ? void 0 : _a.querySelectorAll('.nx-selected-file__dismiss-btn')) !== null && _b !== void 0 ? _b : []);
        if (files) {
            var filesArray = Array.from(files);
            var idx = indexOf(fileObj, filesArray);
            if (idx === files.length - 1) {
                // if the selected file is the last in the container, set the focus to the next last dismiss button
                // if selected file is only file, set focus on the input
                (_c = (closeBtns.length === 1 ? inputRef.current : closeBtns[idx - 1])) === null || _c === void 0 ? void 0 : _c.focus();
            }
            else {
                closeBtns[idx + 1].focus({ preventScroll: true });
            }
            var updatedSelectedFiles = without([fileObj], filesArray), returnedFileList = combineFileLists(updatedSelectedFiles), normalizedFiles = returnedFileList.length ? returnedFileList : null;
            onChangeProp(normalizedFiles);
        }
    }
    useEffect(function () {
        if (inputRef.current) {
            if (isFileSelected) {
                inputRef.current.files = files;
            }
            else {
                // there's no way to clear the list via the files prop, but this does it
                inputRef.current.value = '';
            }
        }
    }, [files]);
    return (React.createElement("div", { ref: ref, className: className },
        React.createElement("div", { className: "nx-multi-file-upload__container" },
            React.createElement("input", __assign({ ref: inputRef }, attrs, { disabled: disabled, onChange: onChange, id: inputId, className: "nx-file-upload__input", type: "file", "aria-describedby": noFileMessageId, "aria-required": isRequired !== null && isRequired !== void 0 ? isRequired : undefined, "aria-invalid": showError || undefined, "aria-errormessage": showError ? validationErrorId : undefined, "aria-controls": selectedFilesContainerId, multiple: true })),
            React.createElement(NxButton, { type: "button", "aria-hidden": true, disabled: disabled, variant: "tertiary", onClick: openPicker, tabIndex: -1, className: "nx-file-upload__select-btn" }, "Add Files"),
            React.createElement("ol", { ref: selectedFilesContainerRef, id: selectedFilesContainerId, className: "nx-multi-file-upload__container__files nx-scrollable" },
                isFileSelected &&
                    Array.from(files).map(function (file) {
                        return React.createElement("li", { key: getKey(file) },
                            React.createElement(SelectedFileWrapper, { file: file, onDismiss: onDismiss }));
                    }),
                React.createElement("li", { id: noFileMessageId, className: noFileMessageClassName },
                    React.createElement("span", null, totalFilesSelected),
                    React.createElement(NxFontAwesomeIcon, { icon: faExclamationCircle })))),
        showError &&
            React.createElement("div", { id: validationErrorId, role: "alert", className: "nx-field-validation-message" }, "This field is required!")));
}
NxMultiFileUpload.propTypes = propTypes;
//# sourceMappingURL=NxMultiFileUpload.js.map