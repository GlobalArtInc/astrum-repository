import React from 'react';
import { StatefulProps as Props } from '../../types';
export { Props };
declare function NxStatefulMultiFileUpload(props: Props): React.JSX.Element;
declare namespace NxStatefulMultiFileUpload {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default NxStatefulMultiFileUpload;
//# sourceMappingURL=NxStatefulMultiFileUpload.d.ts.map