import React from 'react';
import { Props } from './types';
export { Props };
declare function AsTextLink(props: Props): React.JSX.Element;
declare namespace AsTextLink {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default AsTextLink;
//# sourceMappingURL=AsTextLink.d.ts.map