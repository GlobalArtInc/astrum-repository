import React from 'react';
import { Props } from './types';
import './NxModal.scss';
declare function NxModal(props: Props): React.JSX.Element;
declare namespace NxModal {
    var propTypes: import("prop-types").ValidationMap<Props>;
    var Header: (props: React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement>) => React.ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement>, "className">, string | React.JSXElementConstructor<any>>;
    var Content: (props: React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => React.ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | React.JSXElementConstructor<any>>;
}
export default NxModal;
export { Props } from './types';
//# sourceMappingURL=NxModal.d.ts.map