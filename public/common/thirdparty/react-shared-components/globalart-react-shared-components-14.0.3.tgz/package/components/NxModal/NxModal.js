var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { useRef } from 'react';
import classnames from 'classnames';
import { pick, omit } from 'ramda';
import useMergedRef from '@react-hook/merged-ref';
import withClass from '../../util/withClass';
import AbstractDialog from '../AbstractDialog/AbstractDialog';
import { propTypes } from './types';
import './NxModal.scss';
import { useFocusTrap } from '../../util/FocusTrapManager';
import { ensureRef } from '../../util/reactUtil';
export default function NxModal(props) {
    var className = props.className, onClose = props.onClose, _a = props.onCancel, onCancel = _a === void 0 ? onClose : _a, variant = props.variant, role = props.role, externalRef = props.ref, attrs = __rest(props, ["className", "onClose", "onCancel", "variant", "role", "ref"]);
    var modalClasses = classnames('nx-modal', className, {
        'nx-modal--wide': variant === 'wide',
        'nx-modal--narrow': variant === 'narrow'
    });
    var ariaLabelAttrNames = ['aria-label', 'aria-labelledby'], ariaLabels = pick(ariaLabelAttrNames, attrs), attrsWithoutLabels = omit(ariaLabelAttrNames, attrs), internalRef = useRef(null), ref = useMergedRef(internalRef, ensureRef(externalRef));
    useFocusTrap(internalRef);
    return (React.createElement(AbstractDialog, __assign({ ref: ref, role: role, className: "nx-modal-backdrop", tabIndex: -1, onCancel: onCancel, isModal: true }, ariaLabels),
        React.createElement("div", __assign({ className: modalClasses }, attrsWithoutLabels))));
}
NxModal.propTypes = propTypes;
NxModal.Header = withClass('header', 'nx-modal-header');
NxModal.Content = withClass('div', 'nx-modal-content');
//# sourceMappingURL=NxModal.js.map