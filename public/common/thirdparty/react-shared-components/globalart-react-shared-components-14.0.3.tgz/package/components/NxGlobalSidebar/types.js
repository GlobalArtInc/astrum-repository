/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import * as PropTypes from 'prop-types';
export var propTypes = {
    isOpen: PropTypes.bool.isRequired,
    className: PropTypes.string,
    toggleOpenIcon: PropTypes.object.isRequired,
    toggleCloseIcon: PropTypes.object.isRequired,
    onToggleClick: PropTypes.func.isRequired,
    logoImg: PropTypes.string.isRequired,
    logoAltText: PropTypes.string.isRequired,
    logoLink: PropTypes.string.isRequired,
    children: PropTypes.node
};
export var nxGlobalSidebarNavigationPropTypes = {
    className: PropTypes.string
};
export var nxGlobalSidebarNavigationLinkPropTypes = {
    isSelected: PropTypes.bool,
    icon: PropTypes.object.isRequired,
    text: PropTypes.node.isRequired,
    href: PropTypes.string.isRequired
};
export var nxGlobalSidebarFooterPropTypes = {
    supportText: PropTypes.node,
    supportLink: PropTypes.string,
    releaseText: PropTypes.node,
    productTagLine: PropTypes.node,
    showCreatedBy: PropTypes.bool
};
//# sourceMappingURL=types.js.map