/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import classnames from 'classnames';
import NxButton from '../NxButton/NxButton';
import NxFontAwesomeIcon from '../NxFontAwesomeIcon/NxFontAwesomeIcon';
import { useUniqueId } from '../../util/idUtil';
import { propTypes } from './types';
import './NxGlobalSidebar.scss';
import { splitOutFirst } from '../../util/childUtil';
import NxGlobalSidebarFooter from './NxGlobalSidebarFooter';
var NxGlobalSidebar = function NxGlobalSidebar(props) {
    var isOpen = props.isOpen, children = props.children, className = props.className, toggleOpenIcon = props.toggleOpenIcon, toggleCloseIcon = props.toggleCloseIcon, onToggleClick = props.onToggleClick, logoImg = props.logoImg, logoAltText = props.logoAltText, logoLink = props.logoLink;
    var id = useUniqueId('nx-global-sidebar');
    var classes = classnames(className, 'nx-global-sidebar nx-viewport-sized', {
        'open': isOpen,
        'closed': !isOpen
    });
    var toggleButtonIcon = isOpen ? toggleOpenIcon : toggleCloseIcon;
    var toggleButtonTitle = isOpen ? 'Collapse Sidebar' : 'Expand Sidebar';
    var toggleButton = (React.createElement(NxButton, { "aria-expanded": isOpen, "aria-controls": id, variant: "icon-only", onClick: onToggleClick, className: "nx-global-sidebar__toggle", title: toggleButtonTitle },
        React.createElement(NxFontAwesomeIcon, { icon: toggleButtonIcon, fixedWidth: true })));
    var logo = React.createElement("img", { src: logoImg, alt: logoAltText, className: "nx-global-sidebar__logo" }), _a = splitOutFirst(NxGlobalSidebarFooter, children), footer = _a[0], otherChildren = _a[1];
    return (React.createElement("div", { className: classes, id: id },
        React.createElement("aside", { className: "nx-viewport-sized__container", "aria-label": "global sidebar" },
            React.createElement("div", { className: "nx-global-sidebar__header" },
                React.createElement("a", { className: "nx-global-sidebar__product-info", href: logoLink }, logo),
                toggleButton),
            otherChildren),
        footer));
};
NxGlobalSidebar.propTypes = propTypes;
export default NxGlobalSidebar;
export { propTypes } from './types';
//# sourceMappingURL=NxGlobalSidebar.js.map