import { FunctionComponent } from 'react';
import { NxGlobalSidebarNavigationLinkProps as Props } from './types';
export { NxGlobalSidebarNavigationLinkProps } from './types';
declare const NxGlobalSidebarNavigationLink: FunctionComponent<Props>;
export default NxGlobalSidebarNavigationLink;
//# sourceMappingURL=NxGlobalSidebarNavigationLink.d.ts.map