import * as PropTypes from 'prop-types';
import { ReactNode, ComponentPropsWithRef } from 'react';
import { IconDefinition } from '@fortawesome/fontawesome-svg-core';
import RequiredReactNode from '../../util/RequiredReactNode';
export interface Props {
    isOpen: boolean;
    className?: string | null;
    toggleOpenIcon: IconDefinition;
    toggleCloseIcon: IconDefinition;
    onToggleClick: (() => void);
    logoImg: string;
    logoAltText: string;
    logoLink: string;
    children?: ReactNode | null;
}
export declare const propTypes: PropTypes.ValidationMap<Props>;
export type NxGlobalSidebarNavigationProps = ComponentPropsWithRef<'div'>;
export declare const nxGlobalSidebarNavigationPropTypes: {
    className: PropTypes.Requireable<string>;
};
export interface NxGlobalSidebarNavigationLinkProps extends ComponentPropsWithRef<'a'> {
    isSelected?: boolean | null;
    icon: IconDefinition;
    text: RequiredReactNode;
    href: string;
}
export declare const nxGlobalSidebarNavigationLinkPropTypes: PropTypes.ValidationMap<NxGlobalSidebarNavigationLinkProps>;
export interface NxGlobalSidebarFooterProps extends ComponentPropsWithRef<'div'> {
    supportText?: ReactNode | null;
    supportLink?: string | null;
    releaseText?: ReactNode | null;
    productTagLine?: ReactNode | null;
    showCreatedBy?: boolean | null;
}
export declare const nxGlobalSidebarFooterPropTypes: PropTypes.ValidationMap<NxGlobalSidebarFooterProps>;
//# sourceMappingURL=types.d.ts.map