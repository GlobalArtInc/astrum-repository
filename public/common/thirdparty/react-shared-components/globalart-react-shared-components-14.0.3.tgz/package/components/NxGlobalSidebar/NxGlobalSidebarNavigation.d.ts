import { FunctionComponent } from 'react';
import { NxGlobalSidebarNavigationProps as Props } from './types';
export { NxGlobalSidebarNavigationProps } from './types';
declare const NxGlobalSidebarNavigation: FunctionComponent<Props>;
export default NxGlobalSidebarNavigation;
//# sourceMappingURL=NxGlobalSidebarNavigation.d.ts.map