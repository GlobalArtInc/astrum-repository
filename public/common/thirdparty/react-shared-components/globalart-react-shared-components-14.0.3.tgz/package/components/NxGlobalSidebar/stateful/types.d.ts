import * as PropTypes from 'prop-types';
import { Props as NxGlobalSidebarProps } from '../types';
export interface Props extends Omit<NxGlobalSidebarProps, 'isOpen' | 'onToggleClick'> {
    isDefaultOpen: boolean;
}
export declare const propTypes: PropTypes.ValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map