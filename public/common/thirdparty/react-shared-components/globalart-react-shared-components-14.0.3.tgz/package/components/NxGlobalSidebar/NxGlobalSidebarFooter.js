/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
import React from 'react';
import classnames from 'classnames';
import NxFontAwesomeIcon from '../NxFontAwesomeIcon/NxFontAwesomeIcon';
import NxTextLink from '../NxTextLink/NxTextLink';
import { nxGlobalSidebarFooterPropTypes } from './types';
import { faQuestionCircle } from '@fortawesome/free-solid-svg-icons';
var NxGlobalSidebarFooter = function NxGlobalSidebarFooter(props) {
    var className = props.className, supportText = props.supportText, supportLink = props.supportLink, releaseText = props.releaseText, productTagLine = props.productTagLine, showCreatedBy = props.showCreatedBy, otherProps = __rest(props, ["className", "supportText", "supportLink", "releaseText", "productTagLine", "showCreatedBy"]);
    var classes = classnames(className, 'nx-global-sidebar__footer');
    return (React.createElement("footer", __assign({ className: classes }, otherProps),
        supportLink &&
            React.createElement("div", { className: "nx-global-sidebar__support" },
                React.createElement(NxTextLink, { href: supportLink || undefined },
                    React.createElement(NxFontAwesomeIcon, { icon: faQuestionCircle }),
                    React.createElement("span", { className: "nx-global-sidebar__support-text nx-global-sidebar__expanded-content" }, supportText || 'Help and Support'))),
        releaseText &&
            React.createElement("div", { className: "nx-global-sidebar__release nx-global-sidebar__hide-when-collapsed" }, releaseText || undefined),
        productTagLine &&
            React.createElement("div", { className: "nx-global-sidebar__product-name nx-global-sidebar__hide-when-collapsed" }, productTagLine || undefined),
        showCreatedBy !== false &&
            React.createElement("div", { className: "nx-global-sidebar__created-by nx-global-sidebar__hide-when-collapsed" }, "Created by Sonatype")));
};
NxGlobalSidebarFooter.propTypes = nxGlobalSidebarFooterPropTypes;
export default NxGlobalSidebarFooter;
//# sourceMappingURL=NxGlobalSidebarFooter.js.map