import { FunctionComponent } from 'react';
import { NxGlobalSidebarFooterProps as Props } from './types';
export { NxGlobalSidebarFooterProps } from './types';
declare const NxGlobalSidebarFooter: FunctionComponent<Props>;
export default NxGlobalSidebarFooter;
//# sourceMappingURL=NxGlobalSidebarFooter.d.ts.map