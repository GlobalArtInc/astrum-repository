var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import classnames from 'classnames';
import NxFontAwesomeIcon from '../NxFontAwesomeIcon/NxFontAwesomeIcon';
import NxOverflowTooltip from '../NxTooltip/NxOverflowTooltip';
import { nxGlobalSidebarNavigationLinkPropTypes } from './types';
var NxGlobalSidebarNavigationLink = function NxNavigationSidebarLink(props) {
    var className = props.className, isSelected = props.isSelected, icon = props.icon, text = props.text, attrs = __rest(props, ["className", "isSelected", "icon", "text"]);
    var classes = classnames(className, 'nx-global-sidebar__navigation-link nx-text-link', {
        'selected': isSelected
    });
    var textClasses = 'nx-global-sidebar__navigation-text';
    return (React.createElement(NxOverflowTooltip, null,
        React.createElement("a", __assign({ className: classes }, attrs),
            React.createElement(NxFontAwesomeIcon, { icon: icon, fixedWidth: true }),
            React.createElement("span", { className: textClasses }, text))));
};
NxGlobalSidebarNavigationLink.propTypes = nxGlobalSidebarNavigationLinkPropTypes;
export default NxGlobalSidebarNavigationLink;
//# sourceMappingURL=NxGlobalSidebarNavigationLink.js.map