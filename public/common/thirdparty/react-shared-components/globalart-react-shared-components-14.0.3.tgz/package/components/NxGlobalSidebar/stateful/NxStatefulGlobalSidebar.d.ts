import { FunctionComponent } from 'react';
import { Props } from './types';
declare const NxStatefulGlobalSidebar: FunctionComponent<Props>;
export default NxStatefulGlobalSidebar;
export { Props, propTypes } from './types';
//# sourceMappingURL=NxStatefulGlobalSidebar.d.ts.map