import { FunctionComponent } from 'react';
import { Props } from './types';
import './NxGlobalSidebar.scss';
declare const NxGlobalSidebar: FunctionComponent<Props>;
export default NxGlobalSidebar;
export { Props, propTypes } from './types';
//# sourceMappingURL=NxGlobalSidebar.d.ts.map