var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import useToggle from '../../../util/useToggle';
import NxGlobalSidebar from '../NxGlobalSidebar';
import { propTypes } from './types';
var NxStatefulGlobalSidebar = function (props) {
    var isDefaultOpen = props.isDefaultOpen, children = props.children, otherProps = __rest(props, ["isDefaultOpen", "children"]);
    var _a = useToggle(isDefaultOpen), isOpen = _a[0], toggleOpen = _a[1];
    return (React.createElement(NxGlobalSidebar, __assign({ isOpen: isOpen, onToggleClick: toggleOpen }, otherProps), children));
};
NxStatefulGlobalSidebar.propTypes = propTypes;
export default NxStatefulGlobalSidebar;
export { propTypes } from './types';
//# sourceMappingURL=NxStatefulGlobalSidebar.js.map