import { FunctionComponent } from 'react';
import './AsBackButton.scss';
import { Props } from './types';
export { Props, propTypes } from './types';
/**
 * A standard UI element for navigating back to a previous page
 * @param targetPageTitle The name of the page to navigate to
 * @param text Optional custom text to override the back button's default text logic
 * @param href The URL to navigate to when the back button is clicked
 */
declare const AsBackButton: FunctionComponent<Props>;
export default AsBackButton;
//# sourceMappingURL=AsBackButton.d.ts.map