/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import { faChevronLeft } from '@fortawesome/free-solid-svg-icons';
import AsFontAwesomeIcon from '../AsFontAwesomeIcon/AsFontAwesomeIcon';
import './AsBackButton.scss';
import { propTypes } from './types';
export { propTypes } from './types';
/**
 * A standard UI element for navigating back to a previous page
 * @param targetPageTitle The name of the page to navigate to
 * @param text Optional custom text to override the back button's default text logic
 * @param href The URL to navigate to when the back button is clicked
 */
var AsBackButton = function AsBackButton(_a) {
    var targetPageTitle = _a.targetPageTitle, text = _a.text, href = _a.href;
    var linkText = text || (targetPageTitle ? "Back to ".concat(targetPageTitle) : 'Back');
    return (React.createElement("div", { className: "as-back-button tm-back-button" },
        React.createElement("a", { className: "as-text-link", href: href },
            React.createElement(AsFontAwesomeIcon, { icon: faChevronLeft }),
            React.createElement("span", null, linkText))));
};
AsBackButton.propTypes = propTypes;
export default AsBackButton;
//# sourceMappingURL=AsBackButton.js.map