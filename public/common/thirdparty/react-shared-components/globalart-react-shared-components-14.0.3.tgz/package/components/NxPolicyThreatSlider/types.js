/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import * as PropTypes from 'prop-types';
import { allThreatLevelNumbers } from '../../util/threatLevels';
export var propTypes = {
    className: PropTypes.string,
    onChange: PropTypes.func,
    disabled: PropTypes.bool,
    // cast necessary because PropTypes can't check array length
    value: PropTypes.arrayOf(PropTypes.oneOf(allThreatLevelNumbers).isRequired).isRequired
};
//# sourceMappingURL=types.js.map