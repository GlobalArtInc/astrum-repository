import * as PropTypes from 'prop-types';
import { ThreatLevelNumber } from '../../util/threatLevels';
export type PolicyThreatLevelRange = [ThreatLevelNumber, ThreatLevelNumber];
export interface Props {
    className?: string | null;
    onChange?: ((r: PolicyThreatLevelRange) => void) | null;
    value: PolicyThreatLevelRange;
    disabled?: boolean | null;
}
export declare const propTypes: PropTypes.ValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map