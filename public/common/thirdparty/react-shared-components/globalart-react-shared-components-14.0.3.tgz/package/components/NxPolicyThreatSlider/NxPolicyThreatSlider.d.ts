import { FunctionComponent } from 'react';
import { Props } from './types';
export { Props, PolicyThreatLevelRange, propTypes } from './types';
import './NxPolicyThreatSlider.scss';
declare const NxPolicyThreatSlider: FunctionComponent<Props>;
export default NxPolicyThreatSlider;
//# sourceMappingURL=NxPolicyThreatSlider.d.ts.map