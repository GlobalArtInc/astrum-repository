import { FunctionComponent } from 'react';
import { Props } from './types';
declare const NxStatefulIconDropdown: FunctionComponent<Props>;
export default NxStatefulIconDropdown;
export { Props, propTypes } from './types';
//# sourceMappingURL=NxStatefulIconDropdown.d.ts.map