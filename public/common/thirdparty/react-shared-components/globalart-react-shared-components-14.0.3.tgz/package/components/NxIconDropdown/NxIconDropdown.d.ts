import { FunctionComponent } from 'react';
import { Props } from './types';
import './NxIconDropdown.scss';
declare const NxIconDropdown: FunctionComponent<Props>;
export default NxIconDropdown;
export { Props, propTypes } from './types';
//# sourceMappingURL=NxIconDropdown.d.ts.map