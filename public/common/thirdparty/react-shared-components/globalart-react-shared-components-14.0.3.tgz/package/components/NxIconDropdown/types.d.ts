import { ComponentPropsWithRef, KeyboardEventHandler } from 'react';
import { IconDefinition } from '@fortawesome/free-solid-svg-icons';
import * as PropTypes from 'prop-types';
import { OptionalReactElement } from '../../util/reactUtil';
export interface Props extends ComponentPropsWithRef<'div'> {
    isOpen: boolean;
    children?: OptionalReactElement | OptionalReactElement[] | null;
    disabled?: boolean | null;
    onToggleCollapse?: (() => void) | null;
    onCloseKeyDown?: KeyboardEventHandler | null;
    onCloseClick?: ((e: MouseEvent) => void) | null;
    icon?: IconDefinition;
}
export declare const propTypes: PropTypes.WeakValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map