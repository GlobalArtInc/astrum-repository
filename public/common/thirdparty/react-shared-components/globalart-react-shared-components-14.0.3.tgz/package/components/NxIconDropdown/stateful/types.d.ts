import { ComponentPropsWithRef } from 'react';
import { IconDefinition } from '@fortawesome/free-solid-svg-icons';
import * as PropTypes from 'prop-types';
import { OptionalReactElement } from '../../../util/reactUtil';
export interface Props extends ComponentPropsWithRef<'div'> {
    children?: OptionalReactElement | OptionalReactElement[] | null;
    disabled?: boolean | null;
    icon?: IconDefinition;
}
export declare const propTypes: PropTypes.ValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map