import * as PropTypes from 'prop-types';
import { childrenPropTypes } from '../NxDropdown/types';
;
export var propTypes = {
    isOpen: PropTypes.bool.isRequired,
    children: childrenPropTypes,
    disabled: PropTypes.bool,
    onToggleCollapse: PropTypes.func,
    onCloseKeyDown: PropTypes.func,
    onCloseClick: PropTypes.func,
    icon: PropTypes.any
};
//# sourceMappingURL=types.js.map