import * as PropTypes from 'prop-types';
export var AS_DRAWER_VARIANTS = ['normal', 'narrow'];
export var propTypes = {
    open: PropTypes.bool.isRequired,
    onClose: PropTypes.func.isRequired,
    onCancel: PropTypes.func,
    variant: PropTypes.oneOf(AS_DRAWER_VARIANTS),
    closeDisabled: PropTypes.bool,
    closeBtnTooltip: PropTypes.string
};
export var asDrawerHeaderTitlePropTypes = {
    className: PropTypes.string,
    children: PropTypes.node
};
//# sourceMappingURL=types.js.map