var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { useContext, useEffect, useRef, useState } from 'react';
import classnames from 'classnames';
import AsOverflowTooltip from '../AsTooltip/AsOverflowTooltip';
import AbstractDialog from '../AbstractDialog/AbstractDialog';
import AsCloseButton from '../AsCloseButton/AsCloseButton';
import withClass from '../../util/withClass';
import { propTypes, asDrawerHeaderTitlePropTypes } from './types';
import './AsDrawer.scss';
import AsTooltip from '../AsTooltip/AsTooltip';
var AsDrawerContext = React.createContext({
    closeDrawer: function () { }
});
function AsDrawerHeaderTitle(props) {
    var className = props.className, children = props.children, attrs = __rest(props, ["className", "children"]);
    var classes = classnames('as-drawer-header__title', className);
    return (React.createElement(AsOverflowTooltip, null,
        React.createElement("h2", __assign({ className: classes }, attrs), children)));
}
AsDrawerHeaderTitle.propTypes = asDrawerHeaderTitlePropTypes;
var AsDrawerHeader = function (props) {
    var className = props.className, children = props.children, attrs = __rest(props, ["className", "children"]);
    var _a = useContext(AsDrawerContext), closeDrawer = _a.closeDrawer, closeDisabled = _a.closeDisabled, closeBtnTooltip = _a.closeBtnTooltip;
    var classes = classnames('as-drawer-header', className);
    var closeBtnClasses = classnames('as-drawer-header__close-button', { 'disabled': closeDisabled });
    return (React.createElement("header", __assign({ className: classes, role: "none" }, attrs),
        React.createElement(AsTooltip, { title: closeBtnTooltip ? closeBtnTooltip : 'Close' },
            React.createElement(AsCloseButton, { className: closeBtnClasses, type: "button", onClick: closeDrawer }, "Close")),
        children));
};
function AsDrawer(props) {
    var _a;
    var className = props.className, open = props.open, onClose = props.onClose, onCancel = props.onCancel, children = props.children, variant = props.variant, closeDisabled = props.closeDisabled, closeBtnTooltip = props.closeBtnTooltip, attrs = __rest(props, ["className", "open", "onClose", "onCancel", "children", "variant", "closeDisabled", "closeBtnTooltip"]);
    var _b = useState('closed'), openState = _b[0], setOpenState = _b[1];
    var dialogRef = useRef(null);
    var closeDrawer = closeDisabled ? function () { } : onClose;
    var handleAnimationEnd = function () {
        if (openState === 'closing') {
            setOpenState('closed');
            if (onCancel) {
                onCancel();
            }
        }
        else if (openState === 'opening') {
            setOpenState('open');
        }
        else {
            console.warn('Received animationEnd event when in unexpected openState', openState);
        }
    };
    useEffect(function () {
        if (open) {
            if (openState === 'closed') {
                setOpenState('opening');
            }
            var listener_1 = function (event) {
                var targetElement = event.target;
                if (dialogRef.current
                    && !dialogRef.current.contains(targetElement)
                    && !targetElement.closest('.as-toast')) {
                    closeDrawer();
                }
            };
            // to prevent the click event from being called before the drawer is rendered
            // https://github.com/facebook/react/issues/24657
            // https://github.com/reactwg/react-18/discussions/128
            var timeout_1 = setTimeout(function () {
                document.addEventListener('click', listener_1);
            }, 0);
            return function () {
                clearTimeout(timeout_1);
                document.removeEventListener('click', listener_1);
            };
        }
        else {
            if (openState === 'open') {
                setOpenState('closing');
            }
            return undefined;
        }
    }, [open, closeDisabled]);
    var classes = classnames('as-drawer', 'as-viewport-sized', (_a = {
            'as-drawer--narrow': variant === 'narrow'
        },
        _a["as-drawer--".concat(openState)] = openState !== 'open',
        _a), className);
    var drawerContextValue = { closeDrawer: closeDrawer, closeDisabled: closeDisabled, closeBtnTooltip: closeBtnTooltip };
    return (React.createElement(AsDrawerContext.Provider, { value: drawerContextValue },
        React.createElement(AbstractDialog, __assign({ ref: dialogRef, className: classes, onCancel: closeDrawer, isModal: false, onAnimationEnd: handleAnimationEnd, open: openState === 'open' }, attrs), children)));
}
export default Object.assign(AsDrawer, {
    propTypes: propTypes,
    Header: AsDrawerHeader,
    Content: withClass('div', 'as-drawer-content as-scrollable as-viewport-sized__scrollable'),
    HeaderTitle: AsDrawerHeaderTitle,
    HeaderSubtitle: withClass('h3', 'as-h3 as-drawer-header__subtitle'),
    HeaderDescription: withClass('p', 'as-p as-drawer-header__description')
});
//# sourceMappingURL=AsDrawer.js.map