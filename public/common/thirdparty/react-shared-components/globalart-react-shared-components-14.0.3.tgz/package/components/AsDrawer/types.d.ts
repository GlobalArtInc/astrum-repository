import { ComponentPropsWithRef, ReactNode } from 'react';
import * as PropTypes from 'prop-types';
export declare const AS_DRAWER_VARIANTS: readonly ["normal", "narrow"];
export type AS_DRAWER_VARIANT_TYPE = (typeof AS_DRAWER_VARIANTS)[number];
export type OpenState = 'open' | 'closed' | 'opening' | 'closing';
export interface Props extends Omit<ComponentPropsWithRef<'dialog'>, 'onCancel'> {
    open: boolean;
    onClose: () => void;
    onCancel?: (() => void) | null;
    children?: ReactNode;
    variant?: AS_DRAWER_VARIANT_TYPE | null;
    closeDisabled?: boolean | null;
    closeBtnTooltip?: string | null;
}
export type AsDrawerHeaderProps = ComponentPropsWithRef<'header'>;
export type AsDrawerHeaderTitleProps = ComponentPropsWithRef<'h2'>;
export interface AsDrawerContextValue {
    closeDrawer: () => void;
    closeDisabled?: boolean | null;
    closeBtnTooltip?: string | null;
}
export declare const propTypes: PropTypes.ValidationMap<Props>;
export declare const asDrawerHeaderTitlePropTypes: PropTypes.WeakValidationMap<AsDrawerHeaderTitleProps>;
//# sourceMappingURL=types.d.ts.map