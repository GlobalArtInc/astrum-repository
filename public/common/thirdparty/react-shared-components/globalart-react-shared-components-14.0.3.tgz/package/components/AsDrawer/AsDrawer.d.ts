import React from 'react';
import { AsDrawerHeaderProps, AsDrawerHeaderTitleProps, Props } from './types';
import './AsDrawer.scss';
declare function AsDrawerHeaderTitle(props: AsDrawerHeaderTitleProps): React.JSX.Element;
declare namespace AsDrawerHeaderTitle {
    var propTypes: import("prop-types").WeakValidationMap<React.DetailedHTMLProps<React.HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>>;
}
declare function AsDrawer(props: Props): React.JSX.Element;
declare const _default: typeof AsDrawer & {
    propTypes: import("prop-types").ValidationMap<Props>;
    Header: (props: AsDrawerHeaderProps) => React.JSX.Element;
    Content: (props: React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => React.ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | React.JSXElementConstructor<any>>;
    HeaderTitle: typeof AsDrawerHeaderTitle;
    HeaderSubtitle: (props: React.DetailedHTMLProps<React.HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>) => React.ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>, "className">, string | React.JSXElementConstructor<any>>;
    HeaderDescription: (props: React.DetailedHTMLProps<React.HTMLAttributes<HTMLParagraphElement>, HTMLParagraphElement>) => React.ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLParagraphElement>, HTMLParagraphElement>, "className">, string | React.JSXElementConstructor<any>>;
};
export default _default;
export { Props } from './types';
//# sourceMappingURL=AsDrawer.d.ts.map