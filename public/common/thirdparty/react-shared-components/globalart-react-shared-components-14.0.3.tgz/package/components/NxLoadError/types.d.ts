import { ReactNode } from 'react';
import * as PropTypes from 'prop-types';
import { Props as NxAlertProps } from '../NxAlert/types';
export type Props = NxAlertProps & {
    error?: ReactNode | null;
    titleMessage?: string | null;
    retryHandler?: (() => void) | null;
    submitOnRetry?: boolean | null;
};
export declare const propTypes: PropTypes.ValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map