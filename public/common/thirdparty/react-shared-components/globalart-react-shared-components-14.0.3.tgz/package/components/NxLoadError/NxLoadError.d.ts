import React from 'react';
import { Props } from './types';
export { Props, propTypes } from './types';
import './NxLoadError.scss';
/**
 * A component that conditionally renders standardized DOM for error messages, optionally with a retry button.
 * If there is no error, this component renders nothing.
 * @param error if defined/non-null, is a string error message
 * @param titleMessage An optional string to display before the actual error output.  If not defined, defaults
 * to "An error occurred loading data."
 * @param retryHandler If this is defined, a Retry button will be rendered with type attribute set to "button"
 * which executes this function when clicked
 * @param submitOnRetry If this is defined, a Retry button will be rendered with type attribute set to "submit".
 * it will also execute retryHandler if it is specified.
 */
declare function NxLoadError(props: Props): React.JSX.Element | null;
declare namespace NxLoadError {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default NxLoadError;
//# sourceMappingURL=NxLoadError.d.ts.map