import { FunctionComponent } from 'react';
import { Props } from '../NxSubmitMask';
declare const NxStatefulSubmitMask: FunctionComponent<Props>;
export default NxStatefulSubmitMask;
//# sourceMappingURL=NxStatefulSubmitMask.d.ts.map