import * as PropTypes from 'prop-types';
export interface Props {
    message?: string | null;
    successMessage?: string | null;
    success?: boolean | null;
    'aria-label'?: string;
}
export declare const propTypes: PropTypes.ValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map