/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import classnames from 'classnames';
import { faCheckCircle } from '@fortawesome/free-solid-svg-icons';
import NxFontAwesomeIcon from '../NxFontAwesomeIcon/NxFontAwesomeIcon';
import { propTypes } from './types';
export { propTypes } from './types';
import NxLoadingSpinner from '../NxLoadingSpinner/NxLoadingSpinner';
import './NxSubmitMask.scss';
export var SUCCESS_VISIBLE_TIME_MS = 800;
var NxSubmitMask = function NxSubmitMask(_a) {
    var message = _a.message, successMessage = _a.successMessage, success = _a.success, ariaLabel = _a["aria-label"];
    var classes = classnames('nx-submit-mask', {
        'nx-submit-mask--success': !!success
    });
    return (React.createElement("div", { className: classes },
        React.createElement("div", { className: "nx-submit-mask__message" }, success ?
            React.createElement(React.Fragment, null,
                React.createElement(NxFontAwesomeIcon, { icon: faCheckCircle, className: "nx-loading-spinner__icon" }),
                React.createElement("span", { role: "status", className: "nx-submit-mask__message-text", "aria-label": ariaLabel }, successMessage || 'Success!')) :
            React.createElement(NxLoadingSpinner, { "aria-label": ariaLabel }, message || 'Submitting…'))));
};
NxSubmitMask.propTypes = propTypes;
export default NxSubmitMask;
//# sourceMappingURL=NxSubmitMask.js.map