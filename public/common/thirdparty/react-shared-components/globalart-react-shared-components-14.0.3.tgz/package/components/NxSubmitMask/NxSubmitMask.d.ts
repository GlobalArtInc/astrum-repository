import { FunctionComponent } from 'react';
import { Props } from './types';
export { Props, propTypes } from './types';
import './NxSubmitMask.scss';
export declare const SUCCESS_VISIBLE_TIME_MS = 800;
declare const NxSubmitMask: FunctionComponent<Props>;
export default NxSubmitMask;
//# sourceMappingURL=NxSubmitMask.d.ts.map