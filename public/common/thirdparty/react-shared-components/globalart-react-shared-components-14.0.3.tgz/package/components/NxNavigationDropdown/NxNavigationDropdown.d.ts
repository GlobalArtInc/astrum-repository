import React from 'react';
import { Props } from '../NxIconDropdown/NxIconDropdown';
export { Props };
import './NxNavigationDropdown.scss';
declare function NxNavigationDropdown({ className, ...otherProps }: Props): React.JSX.Element;
declare namespace NxNavigationDropdown {
    var propTypes: import("prop-types").WeakValidationMap<Props>;
    var MenuHeader: (props: React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement>) => React.ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement>, "className">, string | React.JSXElementConstructor<any>>;
}
export default NxNavigationDropdown;
//# sourceMappingURL=NxNavigationDropdown.d.ts.map