import React from 'react';
import { Props } from './types';
export { Props };
declare function NxStatefulNavigationDropdown(props: Props): React.JSX.Element;
declare namespace NxStatefulNavigationDropdown {
    var propTypes: Omit<import("prop-types").WeakValidationMap<import("../NxNavigationDropdown").Props>, "isOpen" | "onToggleCollapse">;
}
export default NxStatefulNavigationDropdown;
//# sourceMappingURL=NxStatefulNavigationDropdown.d.ts.map