import { Props as StatelessProps } from '../NxNavigationDropdown';
export type Props = Omit<StatelessProps, 'isOpen' | 'onToggleCollapse'>;
export declare const propTypes: Omit<import("prop-types").WeakValidationMap<StatelessProps>, "isOpen" | "onToggleCollapse">;
//# sourceMappingURL=types.d.ts.map