var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
/* eslint react/prop-types: 0 */
import React from 'react';
import AsCollapsibleItems, { PrivateAsCollapsibleItems } from '../AsCollapsibleItems/AsCollapsibleItems';
import AsTooltip from '../AsTooltip/AsTooltip';
import AsFilterInput from '../AsFilterInput/AsFilterInput';
import { ensureStartEndElements } from '../../util/reactUtil';
import { useUniqueId } from '../../util/idUtil';
export function generateId(groupName, elementId) {
    return "as-collapsible-items-select-".concat(groupName, "-").concat(elementId).replace(' ', '-').toLowerCase();
}
function AbstractCollapsibleItemsSelect(props) {
    var _a;
    var options = props.options, onToggleCollapse = props.onToggleCollapse, filterPlaceholder = props.filterPlaceholder, children = props.children, idProp = props.id, filter = props.filter, onFilterChange = props.onFilterChange, disabledTooltip = props.disabledTooltip, optionTooltipGenerator = props.optionTooltipGenerator, tooltipModifierClass = props.tooltipModifierClass, name = props.name, renderOption = props.renderOption, renderToggleAllOption = props.renderToggleAllOption, renderCounter = props.renderCounter, filterThreshold = props.filterThreshold || 10, isOpen = !!props.isOpen, disabled = !!props.disabled || !options.length, id = useUniqueId('as-collapsible-items-select', idProp || undefined), menuId = useUniqueId('as-collapsible-items-children'), filteredOptions = props.filteredOptions || options;
    function getTooltipProps(title) {
        var tooltipProps = {
            title: title,
            placement: 'top'
        };
        if (tooltipModifierClass) {
            tooltipProps.className = tooltipModifierClass;
        }
        return tooltipProps;
    }
    var renderedOptions = filteredOptions.map(function (item) {
        var option = renderOption(item), key = "key-".concat(item.id);
        return optionTooltipGenerator ? (React.createElement(AsTooltip, __assign({ key: key }, getTooltipProps(optionTooltipGenerator(item))),
            React.createElement(AsCollapsibleItems.Child, null, option))) : React.createElement(AsCollapsibleItems.Child, { key: key }, option);
    });
    var wrappedTriggerContent = ensureStartEndElements(children);
    var counter = renderCounter && renderCounter();
    var triggerWithCounter = counter ? (React.createElement(React.Fragment, null,
        wrappedTriggerContent,
        counter)) : wrappedTriggerContent;
    var filterContent = onFilterChange && options.length > filterThreshold && (React.createElement(AsFilterInput, { disabled: disabled, placeholder: filterPlaceholder || 'filter', id: generateId(name, 'filter-input'), inputAttributes: { 'aria-controls': menuId }, onChange: onFilterChange, value: filter || '' }));
    var selectAllOption = renderToggleAllOption && renderToggleAllOption();
    var getTriggerTooltip = function () {
        if (disabled) {
            if (disabledTooltip) {
                return getTooltipProps(disabledTooltip);
            }
            else if (!options.length) {
                return getTooltipProps("There are no ".concat(name, " options"));
            }
        }
        return null;
    };
    return (React.createElement(PrivateAsCollapsibleItems, { onToggleCollapse: onToggleCollapse, isOpen: isOpen && options.length > 0, contentBeforeChildren: filterContent, id: id, role: "menu", triggerContent: triggerWithCounter, triggerTooltip: getTriggerTooltip(), disabled: disabled, className: "as-collapsible-items--select", "aria-describedby": (_a = (counter && counter.props.id)) !== null && _a !== void 0 ? _a : undefined, collapsibleChildrenId: menuId },
        selectAllOption && React.createElement(AsCollapsibleItems.Child, null, selectAllOption),
        renderedOptions));
}
export default AbstractCollapsibleItemsSelect;
//# sourceMappingURL=AbstractCollapsibleItemsSelect.js.map