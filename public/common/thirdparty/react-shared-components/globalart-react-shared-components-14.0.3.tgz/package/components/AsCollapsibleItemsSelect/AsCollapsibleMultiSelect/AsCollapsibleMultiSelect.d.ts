import React from 'react';
import { Props, Option } from './types';
export { Props, Option } from './types';
declare function AsCollapsibleMultiSelect<T extends Option>(props: Props<T>): React.JSX.Element;
declare namespace AsCollapsibleMultiSelect {
    var propTypes: import("prop-types").WeakValidationMap<Props<Option>>;
}
export default AsCollapsibleMultiSelect;
//# sourceMappingURL=AsCollapsibleMultiSelect.d.ts.map