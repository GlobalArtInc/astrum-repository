import React from 'react';
import { Props, Option } from './types';
export { Props, Option } from './types';
declare function AsCollapsibleRadioSelect<T extends Option>(props: Props<T>): React.JSX.Element;
declare namespace AsCollapsibleRadioSelect {
    var propTypes: import("prop-types").WeakValidationMap<Props<Option>>;
}
export default AsCollapsibleRadioSelect;
//# sourceMappingURL=AsCollapsibleRadioSelect.d.ts.map