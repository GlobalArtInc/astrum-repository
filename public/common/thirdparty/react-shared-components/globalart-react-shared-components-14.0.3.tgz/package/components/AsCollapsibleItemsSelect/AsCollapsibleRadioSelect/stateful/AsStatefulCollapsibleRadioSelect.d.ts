import React from 'react';
import { Props } from './types';
import { Option } from '../../commonTypes';
export { Props, Option } from './types';
declare function AsStatefulCollapsibleRadioSelect<T extends Option>(props: Props<T>): React.JSX.Element;
declare namespace AsStatefulCollapsibleRadioSelect {
    var propTypes: import("prop-types").ValidationMap<Props<Option>>;
}
export default AsStatefulCollapsibleRadioSelect;
//# sourceMappingURL=AsStatefulCollapsibleRadioSelect.d.ts.map