import React from 'react';
import { Props } from './types';
import { Option } from '../../commonTypes';
export { Props, Option } from './types';
declare function AsStatefulCollapsibleMultiSelect<T extends Option>(props: Props<T>): React.JSX.Element;
declare namespace AsStatefulCollapsibleMultiSelect {
    var propTypes: import("prop-types").ValidationMap<Props<Option>>;
}
export default AsStatefulCollapsibleMultiSelect;
//# sourceMappingURL=AsStatefulCollapsibleMultiSelect.d.ts.map