import React, { ComponentPropsWithRef } from 'react';
import * as PropTypes from 'prop-types';
declare function NxSystemNotice({ className, ...otherProps }: ComponentPropsWithRef<'div'>): React.JSX.Element;
declare namespace NxSystemNotice {
    var propTypes: {
        className: PropTypes.Requireable<string>;
    };
    var Container: (props: React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => React.ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | React.JSXElementConstructor<any>>;
}
export default NxSystemNotice;
//# sourceMappingURL=NxSystemNotice.d.ts.map