var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { useContext } from 'react';
import classnames from 'classnames';
import { faSort, faSortDown, faSortUp, faChevronRight } from '@fortawesome/free-solid-svg-icons';
import { ensureStartEndElements } from '../../util/reactUtil';
import AsFontAwesomeIcon from '../AsFontAwesomeIcon/AsFontAwesomeIcon';
import { asTableCellPropTypes } from './types';
import { HeaderContext, RowContext } from './contexts';
import AsTooltip from '../AsTooltip/AsTooltip';
import { textContent } from '../../util/childUtil';
var AsTableCell = function AsTableCell(props) {
    var _a = props.metaInfo, metaInfo = _a === void 0 ? false : _a, _b = props.isNumeric, isNumeric = _b === void 0 ? false : _b, _c = props.isSortable, isSortableProp = _c === void 0 ? false : _c, _d = props.hasIcon, hasIcon = _d === void 0 ? false : _d, _e = props.chevron, chevron = _e === void 0 ? false : _e, rowBtnIconProp = props.rowBtnIcon, sortDir = props.sortDir, className = props.className, children = props.children, attrs = __rest(props, ["metaInfo", "isNumeric", "isSortable", "hasIcon", "chevron", "rowBtnIcon", "sortDir", "className", "children"]), isHeader = useContext(HeaderContext), _f = useContext(RowContext), rowLabel = _f.label, isFilterHeader = _f.isFilterHeader, rowBtnIcon = rowBtnIconProp || (chevron ? faChevronRight : null), isSortable = isSortableProp && isHeader && !chevron;
    var classes = classnames('as-cell', className, {
        'as-cell--header': isHeader,
        'as-cell--meta-info': metaInfo,
        'as-cell--num': isNumeric,
        'as-cell--icon': hasIcon,
        'as-cell--row-btn': rowBtnIcon,
        'as-cell--sortable': isSortable
    });
    var maskedSort;
    var ariaSort;
    var ariaLabel;
    if (isSortable) {
        var text = textContent(children);
        if (sortDir === 'asc') {
            ariaSort = 'ascending';
            ariaLabel = "".concat(text, " ").concat(ariaSort);
            maskedSort = (React.createElement(React.Fragment, null,
                React.createElement(AsFontAwesomeIcon, { icon: faSortDown }),
                React.createElement(AsFontAwesomeIcon, { icon: faSortUp })));
        }
        else if (sortDir === 'desc') {
            ariaSort = 'descending';
            ariaLabel = "".concat(text, " ").concat(ariaSort);
            maskedSort = (React.createElement(React.Fragment, null,
                React.createElement(AsFontAwesomeIcon, { icon: faSortUp }),
                React.createElement(AsFontAwesomeIcon, { icon: faSortDown })));
        }
        else {
            ariaSort = 'none';
            ariaLabel = "".concat(text, " unsorted");
            maskedSort = React.createElement(AsFontAwesomeIcon, { icon: faSort });
        }
    }
    var Tag = isHeader && !isFilterHeader ? 'th' : 'td';
    var rowBtnCellContents = isHeader || !rowBtnIcon ? null : (React.createElement("button", { type: "button", className: "as-cell__row-btn", "aria-label": rowLabel },
        React.createElement(AsFontAwesomeIcon, { icon: rowBtnIcon })));
    var cellSortingContents = (React.createElement(AsTooltip, { title: ariaLabel, placement: isNumeric ? 'top-middle' : 'top' },
        React.createElement("button", { "aria-label": ariaLabel, type: "button", className: "as-cell__sort-btn" },
            ensureStartEndElements(children),
            React.createElement("span", { className: "as-cell__sort-icons fa-layers" }, maskedSort))));
    return (React.createElement(Tag, __assign({ className: classes, "aria-sort": ariaSort }, attrs),
        isSortable ? cellSortingContents :
            rowBtnIcon ? rowBtnCellContents :
                children,
        isHeader && rowBtnIcon && React.createElement("span", { className: "as-cell__row-btn-header-text" }, "Select Row")));
};
AsTableCell.propTypes = asTableCellPropTypes;
export default AsTableCell;
//# sourceMappingURL=AsTableCell.js.map