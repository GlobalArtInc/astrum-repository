var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { useEffect, useRef, useState, useCallback } from 'react';
import useMutationObserver from '@rooks/use-mutation-observer';
import classnames from 'classnames';
import AsTableHead from './AsTableHead';
import AsTableBody from './AsTableBody';
import AsTableRow from './AsTableRow';
import AsTableCell from './AsTableCell';
import { ColumnCountContext } from './contexts';
import { asTablePropTypes } from './types';
var mutationObserverConfig = { subtree: true, childList: true, attributes: false, characterData: false };
var AsTable = function AsTableElement(props) {
    var className = props.className, children = props.children, caption = props.caption, attrs = __rest(props, ["className", "children", "caption"]), tableRef = useRef(null), _a = useState(1), columnCount = _a[0], setColumnCount = _a[1], updateColumnCount = useCallback(function updateColumnCount() {
        if (tableRef.current) {
            setColumnCount(tableRef.current.querySelectorAll('thead > tr:first-child > th').length);
        }
    }, []);
    useEffect(updateColumnCount, []);
    useMutationObserver(tableRef, updateColumnCount, mutationObserverConfig);
    return (React.createElement("table", __assign({ ref: tableRef, className: classnames('as-table', className) }, attrs),
        caption && React.createElement("caption", { className: "as-h2" }, caption),
        React.createElement(ColumnCountContext.Provider, { value: columnCount }, children)));
};
AsTable.Body = AsTableBody;
AsTable.Head = AsTableHead;
AsTable.Row = AsTableRow;
AsTable.Cell = AsTableCell;
AsTable.propTypes = asTablePropTypes;
export default AsTable;
//# sourceMappingURL=AsTable.js.map