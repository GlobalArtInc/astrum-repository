import React from 'react';
import { AsTableRowProps } from './types';
export { AsTableRowProps };
declare function AsTableRow(props: AsTableRowProps): React.JSX.Element;
declare namespace AsTableRow {
    var propTypes: import("prop-types").ValidationMap<AsTableRowProps>;
}
export default AsTableRow;
//# sourceMappingURL=AsTableRow.d.ts.map