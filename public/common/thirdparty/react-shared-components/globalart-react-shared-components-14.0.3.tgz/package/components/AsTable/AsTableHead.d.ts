import React from 'react';
import { AsTableHeadProps } from './types';
export { AsTableHeadProps };
declare const AsTableHead: {
    (props: AsTableHeadProps): React.JSX.Element;
    propTypes: import("prop-types").ValidationMap<React.DetailedHTMLProps<React.HTMLAttributes<HTMLTableSectionElement>, HTMLTableSectionElement>>;
};
export default AsTableHead;
//# sourceMappingURL=AsTableHead.d.ts.map