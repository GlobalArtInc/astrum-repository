var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { useContext, useRef, useEffect, useState, useMemo } from 'react';
import classnames from 'classnames';
import { join, map, prop, filter } from 'ramda';
import useMergedRef from '@react-hook/merged-ref';
import { asTableRowPropTypes } from './types';
import { HeaderContext, RowContext } from './contexts';
import { ensureRef } from '../../util/reactUtil';
export default function AsTableRow(props) {
    var externalRef = props.ref, isFilterHeaderProp = props.isFilterHeader, _a = props.isClickable, isClickable = _a === void 0 ? false : _a, className = props.className, selected = props.selected, children = props.children, clickAccessibleLabel = props.clickAccessibleLabel, attrs = __rest(props, ["ref", "isFilterHeader", "isClickable", "className", "selected", "children", "clickAccessibleLabel"]), isFilterHeader = isFilterHeaderProp !== null && isFilterHeaderProp !== void 0 ? isFilterHeaderProp : false, isHeader = useContext(HeaderContext), 
    // For the default accessibility label on the chevron button, we need the text content of the row.
    // This component uses the DOM to retrieve that and provides it via RowContext
    _b = useState(''), rowTextContent = _b[0], setRowTextContent = _b[1], rowRef = useRef(null), ref = useMergedRef(rowRef, ensureRef(externalRef)), rowLabel = clickAccessibleLabel || rowTextContent, rowContext = useMemo(function () { return ({
        label: rowLabel,
        isFilterHeader: isFilterHeader
    }); }, [rowLabel, isFilterHeader]);
    var classes = classnames('as-table-row', className, {
        'as-table-row--header': isHeader,
        'as-clickable': isClickable,
        'as-table-row--filter-header': isFilterHeader,
        selected: selected
    });
    useEffect(function () {
        // unused if clickAccessibleLabel is set
        if (!clickAccessibleLabel && rowRef.current) {
            var row = rowRef.current, cells = Array.from(row.querySelectorAll('td, th')), cellTexts = filter(function (s) { return !!s; }, map(prop('textContent'), cells)), rowText = join('; ', cellTexts);
            setRowTextContent(rowText);
        }
    }, [clickAccessibleLabel, children]);
    return (React.createElement("tr", __assign({ ref: ref, className: classes }, attrs),
        React.createElement(RowContext.Provider, { value: rowContext }, children)));
}
AsTableRow.propTypes = asTableRowPropTypes;
//# sourceMappingURL=AsTableRow.js.map