import React from 'react';
import AsTableRow from './AsTableRow';
import { AsTableProps } from './types';
export { AsTableProps };
declare const AsTable: {
    (props: AsTableProps): React.JSX.Element;
    Body: {
        (props: import("./types").AsTableBodyProps): React.JSX.Element;
        propTypes: import("prop-types").ValidationMap<import("./types").AsTableBodyProps>;
    };
    Head: {
        (props: import("./types").AsTableHeadProps): React.JSX.Element;
        propTypes: import("prop-types").ValidationMap<React.DetailedHTMLProps<React.HTMLAttributes<HTMLTableSectionElement>, HTMLTableSectionElement>>;
    };
    Row: typeof AsTableRow;
    Cell: {
        (props: import("./types").AsTableCellProps): React.JSX.Element;
        propTypes: import("prop-types").ValidationMap<import("./types").AsTableCellProps>;
    };
    propTypes: import("prop-types").ValidationMap<AsTableProps>;
};
export default AsTable;
//# sourceMappingURL=AsTable.d.ts.map