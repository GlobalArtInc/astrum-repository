import PropTypes from 'prop-types';
;
export var asTablePropTypes = {
    children: PropTypes.node
};
export var asTableBodyPropTypes = {
    isLoading: PropTypes.bool,
    error: PropTypes.string,
    emptyMessage: PropTypes.node,
    retryHandler: PropTypes.func,
    children: PropTypes.node
};
export var asTableCellPropTypes = {
    metaInfo: PropTypes.bool,
    isNumeric: PropTypes.bool,
    isSortable: PropTypes.bool,
    isFilterHeader: PropTypes.bool,
    hasIcon: PropTypes.bool,
    chevron: PropTypes.bool,
    sortDir: PropTypes.oneOf(['asc', 'desc', null]),
    children: PropTypes.node
};
export var asTableHeadPropTypes = {
    children: PropTypes.node
};
export var asTableRowPropTypes = {
    isFilterHeader: PropTypes.bool,
    isClickable: PropTypes.bool,
    selected: PropTypes.bool,
    clickAccessibleLabel: PropTypes.string,
    children: PropTypes.node
};
//# sourceMappingURL=types.js.map