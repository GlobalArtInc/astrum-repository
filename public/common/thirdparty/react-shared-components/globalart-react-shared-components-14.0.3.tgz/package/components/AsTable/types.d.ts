import { ReactNode, ComponentPropsWithRef } from 'react';
import PropTypes from 'prop-types';
import { IconDefinition } from '@fortawesome/fontawesome-svg-core';
export interface AsTableProps extends ComponentPropsWithRef<'table'> {
    caption?: string | null;
}
export declare const asTablePropTypes: PropTypes.ValidationMap<AsTableProps>;
export type AsTableBodyProps = ComponentPropsWithRef<'tbody'> & {
    isLoading?: boolean | null;
    error?: string | null;
    emptyMessage?: ReactNode | null;
    retryHandler?: (() => void) | null;
};
export declare const asTableBodyPropTypes: PropTypes.ValidationMap<AsTableBodyProps>;
export type AsTableCellProps = (ComponentPropsWithRef<'th'> | ComponentPropsWithRef<'td'>) & {
    metaInfo?: boolean | null;
    isNumeric?: boolean | null;
    isSortable?: boolean | null;
    isFilterHeader?: boolean | null;
    hasIcon?: boolean | null;
    chevron?: boolean | null;
    rowBtnIcon?: IconDefinition | null;
    sortDir?: 'asc' | 'desc' | null;
};
export declare const asTableCellPropTypes: PropTypes.ValidationMap<AsTableCellProps>;
export type AsTableHeadProps = ComponentPropsWithRef<'thead'>;
export declare const asTableHeadPropTypes: PropTypes.ValidationMap<AsTableHeadProps>;
export type AsTableRowProps = ComponentPropsWithRef<'tr'> & {
    isFilterHeader?: boolean | null;
    isClickable?: boolean | null;
    selected?: boolean | null;
    clickAccessibleLabel?: string | null;
};
export declare const asTableRowPropTypes: PropTypes.ValidationMap<AsTableRowProps>;
//# sourceMappingURL=types.d.ts.map