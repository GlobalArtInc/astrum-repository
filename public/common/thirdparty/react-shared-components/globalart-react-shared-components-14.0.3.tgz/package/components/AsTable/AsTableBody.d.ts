import React from 'react';
import { AsTableBodyProps } from './types';
export { AsTableBodyProps };
declare const AsTableBody: {
    (props: AsTableBodyProps): React.JSX.Element;
    propTypes: import("prop-types").ValidationMap<AsTableBodyProps>;
};
export default AsTableBody;
//# sourceMappingURL=AsTableBody.d.ts.map