var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { useContext, useRef } from 'react';
import { asTableBodyPropTypes } from './types';
import AsTableRow from './AsTableRow';
import AsTableCell from './AsTableCell';
import { ColumnCountContext } from './contexts';
import AsLoadingSpinner from '../AsLoadingSpinner/AsLoadingSpinner';
import AsLoadError from '../AsLoadError/AsLoadError';
import useEmptyComponent from '../../util/useEmptyComponent';
var AsTableBody = function AsTableBody(props) {
    var _a = props.isLoading, isLoading = _a === void 0 ? false : _a, emptyMessage = props.emptyMessage, error = props.error, children = props.children, retryHandler = props.retryHandler, attrs = __rest(props, ["isLoading", "emptyMessage", "error", "children", "retryHandler"]), columns = useContext(ColumnCountContext), bodyRef = useRef(null), emptyRowRef = useRef(null), isEmpty = useEmptyComponent(bodyRef, emptyRowRef);
    if (isLoading && !columns) {
        console.warn('columns is required when isLoading is set, this should have been determined automatically');
    }
    if (error && !columns) {
        console.warn('columns is required when error is set, this should have been determined automatically');
    }
    if (isEmpty && !isLoading && !error) {
        if (!emptyMessage) {
            console.warn('emptyMessage is required when no rows are to be rendered');
        }
        else if (!columns) {
            console.warn('columns is required when emptyMessage is to be used, this should have been determined automatically');
        }
    }
    var loadingSpinnerRow = (React.createElement(AsTableRow, null,
        React.createElement(AsTableCell, { metaInfo: true, colSpan: columns || undefined },
            React.createElement(AsLoadingSpinner, null))));
    var errorRow = (React.createElement(AsTableRow, null,
        React.createElement(AsTableCell, { metaInfo: true, colSpan: columns || undefined },
            React.createElement(AsLoadError, { error: error, retryHandler: retryHandler }))));
    var emptyMessageRow = (React.createElement(AsTableRow, { ref: emptyRowRef },
        React.createElement(AsTableCell, { metaInfo: true, colSpan: columns || undefined }, emptyMessage)));
    return (React.createElement("tbody", __assign({ ref: bodyRef }, attrs),
        isLoading && loadingSpinnerRow,
        !!error && !isLoading && errorRow,
        !isLoading && !error && children,
        !(isLoading || error) && isEmpty && emptyMessageRow));
};
AsTableBody.propTypes = asTableBodyPropTypes;
export default AsTableBody;
//# sourceMappingURL=AsTableBody.js.map