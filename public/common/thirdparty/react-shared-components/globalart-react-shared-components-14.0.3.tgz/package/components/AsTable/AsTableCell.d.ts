import React from 'react';
import { AsTableCellProps } from './types';
export { AsTableCellProps };
declare const AsTableCell: {
    (props: AsTableCellProps): React.JSX.Element;
    propTypes: import("prop-types").ValidationMap<AsTableCellProps>;
};
export default AsTableCell;
//# sourceMappingURL=AsTableCell.d.ts.map