import React, { ComponentPropsWithRef } from 'react';
import * as PropTypes from 'prop-types';
import './NxCloseButton.scss';
declare function NxCloseButton({ className, ...otherProps }: ComponentPropsWithRef<'button'>): React.JSX.Element;
declare namespace NxCloseButton {
    var propTypes: {
        className: PropTypes.Requireable<string>;
    };
}
export default NxCloseButton;
//# sourceMappingURL=NxCloseButton.d.ts.map