import React from 'react';
import { Props } from './types';
export { Props, propTypes } from './types';
import './AsLoadError.scss';
/**
 * A component that conditionally renders standardized DOM for error messages, optionally with a retry button.
 * If there is no error, this component renders nothing.
 * @param error if defined/non-null, is a string error message
 * @param titleMessage An optional string to display before the actual error output.  If not defined, defaults
 * to "An error occurred loading data."
 * @param retryHandler If this is defined, a Retry button will be rendered with type attribute set to "button"
 * which executes this function when clicked
 * @param submitOnRetry If this is defined, a Retry button will be rendered with type attribute set to "submit".
 * it will also execute retryHandler if it is specified.
 */
declare function AsLoadError(props: Props): React.JSX.Element | null;
declare namespace AsLoadError {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default AsLoadError;
//# sourceMappingURL=AsLoadError.d.ts.map