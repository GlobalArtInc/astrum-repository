var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
import * as PropTypes from 'prop-types';
import { propTypes as asAlertPropTypes } from '../AsAlert/types';
// In a strictly typescript environment, PropTypes are mostly redundant.  However, they still provide safety when this
// project is consumed by javascript projects
export var propTypes = __assign(__assign({}, asAlertPropTypes), { error: PropTypes.node, titleMessage: PropTypes.string, retryHandler: PropTypes.func, submitOnRetry: PropTypes.bool });
//# sourceMappingURL=types.js.map