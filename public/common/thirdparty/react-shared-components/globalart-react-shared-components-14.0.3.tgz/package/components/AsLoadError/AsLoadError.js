var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import { faSync } from '@fortawesome/free-solid-svg-icons';
import classnames from 'classnames';
import AsFontAwesomeIcon from '../AsFontAwesomeIcon/AsFontAwesomeIcon';
import { AsErrorAlert } from '../AsAlert/AsAlert';
import AsButton from '../AsButton/AsButton';
import { propTypes } from './types';
export { propTypes } from './types';
import './AsLoadError.scss';
/**
 * A component that conditionally renders standardized DOM for error messages, optionally with a retry button.
 * If there is no error, this component renders nothing.
 * @param error if defined/non-null, is a string error message
 * @param titleMessage An optional string to display before the actual error output.  If not defined, defaults
 * to "An error occurred loading data."
 * @param retryHandler If this is defined, a Retry button will be rendered with type attribute set to "button"
 * which executes this function when clicked
 * @param submitOnRetry If this is defined, a Retry button will be rendered with type attribute set to "submit".
 * it will also execute retryHandler if it is specified.
 */
export default function AsLoadError(props) {
    var error = props.error, titleMessage = props.titleMessage, submitOnRetry = props.submitOnRetry, retryHandler = props.retryHandler, className = props.className, otherProps = __rest(props, ["error", "titleMessage", "submitOnRetry", "retryHandler", "className"]);
    var alertClasses = classnames('as-alert--load-error', className);
    return error != null && (React.createElement(AsErrorAlert, __assign({}, otherProps, { className: alertClasses }),
        React.createElement("div", { className: "as-load-error__content" },
            React.createElement("span", { className: "as-load-error__message" },
                titleMessage || 'An error occurred loading data.',
                ' ',
                error),
            (retryHandler || submitOnRetry) &&
                React.createElement(AsButton, { type: submitOnRetry ? 'submit' : 'button', variant: "error", onClick: retryHandler !== null && retryHandler !== void 0 ? retryHandler : undefined, 
                    // This is to prevent focus from going to the <body> in Safari
                    // and closing the dropdown menu prematurely inside AsCombobox.
                    onMouseDown: function (event) {
                        event.preventDefault();
                        event.currentTarget.focus();
                    }, className: "as-load-error__retry" },
                    React.createElement(AsFontAwesomeIcon, { icon: faSync }),
                    React.createElement("span", null, "Retry"))))) || null;
}
AsLoadError.propTypes = propTypes;
//# sourceMappingURL=AsLoadError.js.map