import { ReactNode } from 'react';
import * as PropTypes from 'prop-types';
import { Props as AsAlertProps } from '../AsAlert/types';
export type Props = AsAlertProps & {
    error?: ReactNode | null;
    titleMessage?: string | null;
    retryHandler?: (() => void) | null;
    submitOnRetry?: boolean | null;
};
export declare const propTypes: PropTypes.ValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map