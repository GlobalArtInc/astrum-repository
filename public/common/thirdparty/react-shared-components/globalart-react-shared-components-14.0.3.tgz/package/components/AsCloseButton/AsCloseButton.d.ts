import React, { ComponentPropsWithRef } from 'react';
import * as PropTypes from 'prop-types';
import './AsCloseButton.scss';
declare function AsCloseButton({ className, ...otherProps }: ComponentPropsWithRef<'button'>): React.JSX.Element;
declare namespace AsCloseButton {
    var propTypes: {
        className: PropTypes.Requireable<string>;
    };
}
export default AsCloseButton;
//# sourceMappingURL=AsCloseButton.d.ts.map