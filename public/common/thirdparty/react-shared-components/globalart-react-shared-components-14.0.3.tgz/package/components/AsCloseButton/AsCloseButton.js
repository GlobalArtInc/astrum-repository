var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import * as PropTypes from 'prop-types';
import classnames from 'classnames';
import Close from '../../icons/Close';
import { includesDisabledClass } from '../../util/classUtil';
import './AsCloseButton.scss';
export default function AsCloseButton(_a) {
    var className = _a.className, otherProps = __rest(_a, ["className"]);
    var btnClasses = classnames('as-btn as-btn--icon-only as-btn--close', className);
    // NOTE: not using AsButton because we don't want the tooltip that icon-only AsButtons require
    return (React.createElement("button", __assign({ "aria-disabled": includesDisabledClass(className), type: "button", className: btnClasses, "aria-label": "Close" }, otherProps),
        React.createElement(Close, null)));
}
AsCloseButton.propTypes = {
    className: PropTypes.string
};
//# sourceMappingURL=AsCloseButton.js.map