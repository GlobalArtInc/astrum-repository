var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { useMemo } from 'react';
import classnames from 'classnames';
import { pipe, split, map, join, toUpper, head, tail } from 'ramda';
import { faCheck } from '@fortawesome/free-solid-svg-icons';
import NxFontAwesomeIcon from '../NxFontAwesomeIcon/NxFontAwesomeIcon';
import NxTooltip from '../NxTooltip/NxTooltip';
import { selectableColors } from '../../util/selectableColors';
import { useUniqueId } from '../../util/idUtil';
import { textContent } from '../../util/childUtil';
import { propTypes } from './types';
import './NxColorPicker.scss';
import NxFieldset from '../NxFieldset/NxFieldset';
// convert a color name to a human-friendly string
// (i.e. spaced and capitalized)
var humanReadable = pipe(split('-'), map(function (s) { var _a; return "".concat(toUpper((_a = head(s)) !== null && _a !== void 0 ? _a : '')).concat(tail(s)); }), join(' '));
function ColorRadio(_a) {
    var pickerLabel = _a.pickerLabel, color = _a.color, value = _a.value, onChange = _a.onChange, name = _a.name;
    var selected = value === color, classes = classnames('nx-color-picker__label', "nx-selectable-color--".concat(color), { selected: selected }), humanReadableColor = useMemo(function () { return humanReadable(color); }, [color]), label = "".concat(pickerLabel, " ").concat(humanReadableColor);
    function inputOnChange() {
        if (onChange) {
            onChange(color);
        }
    }
    return (React.createElement(NxTooltip, { title: humanReadableColor },
        React.createElement("label", { "aria-label": label, className: classes },
            React.createElement("input", { className: "nx-color-picker__input", type: "radio", name: name, value: color, checked: color === value, onChange: inputOnChange }),
            React.createElement("svg", { className: "nx-color-picker__circles", viewBox: "-16 -16 32 32" },
                React.createElement("circle", { className: "nx-color-picker__outline", r: "15" }),
                React.createElement("circle", { className: "nx-color-picker__color" }),
                selected &&
                    React.createElement(NxFontAwesomeIcon, { className: "nx-color-picker__check", width: "16", height: "100%", x: "-8", y: "-16", icon: faCheck })))));
}
export default function NxColorPicker(_a) {
    var value = _a.value, onChange = _a.onChange, className = _a.className, label = _a.label, attrs = __rest(_a, ["value", "onChange", "className", "label"]);
    var name = useUniqueId('nx-color-picker'), classes = classnames('nx-color-picker', className), pickerLabel = textContent(label);
    return (React.createElement(NxFieldset, __assign({ label: label, className: classes }, attrs), selectableColors.map(function (color) {
        return React.createElement(ColorRadio, { key: color, pickerLabel: pickerLabel, color: color, name: name, value: value, onChange: onChange });
    })));
}
NxColorPicker.propTypes = propTypes;
//# sourceMappingURL=NxColorPicker.js.map