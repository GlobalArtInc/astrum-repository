import * as PropTypes from 'prop-types';
import { Props as NxFieldsetProps } from '../NxFieldset/types';
import { SelectableColor } from '../../util/selectableColors';
export interface Props extends Omit<NxFieldsetProps, 'onChange' | 'sublabel'> {
    value?: SelectableColor | null;
    onChange?: ((currentValue: SelectableColor) => void) | null;
}
export declare const propTypes: PropTypes.ValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map