import React from 'react';
import { Props } from './types';
export { Props } from './types';
import './NxColorPicker.scss';
declare function NxColorPicker({ value, onChange, className, label, ...attrs }: Props): React.JSX.Element;
declare namespace NxColorPicker {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default NxColorPicker;
//# sourceMappingURL=NxColorPicker.d.ts.map