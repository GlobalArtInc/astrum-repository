var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { useCallback, useEffect, useRef, useState } from 'react';
import useMergedRef from '@react-hook/merged-ref';
import classnames from 'classnames';
import { always, any, clamp, dec, inc, partial, pipe, prop } from 'ramda';
import './AsSearchDropdown.scss';
import { propTypes } from './types';
import AsFilterInput from '../AsFilterInput/AsFilterInput';
import AsDropdownMenu from '../AsDropdownMenu/AsDropdownMenu';
import AsLoadWrapper from '../AsLoadWrapper/AsLoadWrapper';
import { useUniqueId } from '../../util/idUtil';
import useMutationObserver from '@rooks/use-mutation-observer';
import { ensureRef } from '../../util/reactUtil';
export var SEARCH_DEBOUNCE_TIME = 500;
export default function AsSearchDropdown(props) {
    var classNameProp = props.className, loading = props.loading, error = props.error, matches = props.matches, onSelect = props.onSelect, searchText = props.searchText, onSearchTextChange = props.onSearchTextChange, onSearch = props.onSearch, long = props.long, disabled = props.disabled, emptyMessage = props.emptyMessage, externalRef = props.ref, attrs = __rest(props, ["className", "loading", "error", "matches", "onSelect", "searchText", "onSearchTextChange", "onSearch", "long", "disabled", "emptyMessage", "ref"]), isEmpty = !matches.length, showDropdown = !!(searchText && !disabled), ref = useRef(null), mergedRef = useMergedRef(ensureRef(externalRef), ref), menuRef = useRef(null), filterRef = useRef(null), elFocusedOnMostRecentRender = useRef(null), _a = useState(null), focusableBtnIndex = _a[0], setFocusableBtnIndex = _a[1], dropdownMenuId = useUniqueId('as-search-dropdown-menu'), dropdownMenuRole = error ? undefined : (loading || isEmpty) ? 'alert' : 'menu', filterClassName = classnames('as-search-dropdown__input', { 'as-text-input--long': long }), className = classnames('as-search-dropdown', classNameProp, {
        'as-search-dropdown--dropdown-showable': showDropdown
    }), menuClassName = classnames('as-search-dropdown__menu', {
        'as-search-dropdown__menu--error': !!error
    });
    // There is a requirement that when there is an error querying the data, if the user navigates away from
    // the component and then comes back to it the search should be retried automatically
    function handleComponentFocus(evt) {
        // check if this is focus coming into the component from somewhere else on the page, not just moving between
        // children of this component and not from focus coming into the browser from some other window
        var comingFromOutsidePage = evt.relatedTarget === null, comingFromChildNode = evt.relatedTarget instanceof Node && evt.currentTarget.contains(evt.relatedTarget);
        if (!(comingFromOutsidePage || comingFromChildNode) && error) {
            doSearch(searchText);
        }
    }
    function handleFilterChange(value) {
        onSearchTextChange(value);
        if (value.trim() !== searchText.trim()) {
            doSearch(value);
        }
    }
    // helper for focusing different buttons in the dropdown menu
    var adjustBtnFocus = function (adjust) { return function () {
        var _a;
        var newFocusableBtnIndex = adjust(focusableBtnIndex !== null && focusableBtnIndex !== void 0 ? focusableBtnIndex : 0), elToFocus = (_a = menuRef.current) === null || _a === void 0 ? void 0 : _a.children[newFocusableBtnIndex];
        if (elToFocus) {
            elToFocus.focus();
            setFocusableBtnIndex(newFocusableBtnIndex);
        }
    }; }, focusNext = adjustBtnFocus(inc), focusPrev = adjustBtnFocus(dec), focusFirst = adjustBtnFocus(always(0)), focusLast = adjustBtnFocus(always(matches.length - 1));
    function handleButtonKeyDown(evt) {
        switch (evt.key) {
            case 'Home':
                focusFirst();
                evt.preventDefault();
                break;
            case 'End':
                focusLast();
                evt.preventDefault();
                break;
            case 'ArrowDown':
                focusNext();
                evt.preventDefault();
                break;
            case 'ArrowUp':
                focusPrev();
                evt.preventDefault();
                break;
            case 'Escape':
                focusTextInput();
                handleFilterChange('');
                break;
        }
    }
    function handleKeyDown(evt) {
        if (evt.key === 'Escape') {
            handleFilterChange('');
        }
    }
    function doSearch(value) {
        focusTextInput();
        onSearch(value.trim());
    }
    var handleOnClick = function (match, evt) {
        focusTextInput();
        onSelect(match, evt);
    };
    function focusTextInput() {
        var _a, _b;
        (_b = (_a = filterRef.current) === null || _a === void 0 ? void 0 : _a.querySelector('input')) === null || _b === void 0 ? void 0 : _b.focus();
    }
    // Clamp or nullify focusableBtnIndex whenever the number of matches changes
    useEffect(function () {
        if (matches.length) {
            setFocusableBtnIndex(clamp(0, matches.length - 1, focusableBtnIndex !== null && focusableBtnIndex !== void 0 ? focusableBtnIndex : 0));
        }
        else {
            setFocusableBtnIndex(null);
        }
    }, [matches]);
    /*
     * Horrible Hack: When an element within the dropdown is removed from the DOM while it is focused, we want
     * to move focus to the text input.  It turns out that this is very difficult to track in React, since
     * useEffect and useLayoutEffect generally fire too late - after the element has already been removed and
     * lost whatever focus it might've had. The only other way to get this info is with a useLayoutEffect handler
     * _in the component that was unmounted_, e.g. in AsButton. That would require adding new props for a special use
     * case to not only AsButton, but also AsLoadWrapper and AsLoadError. Just querying who has focus on every render
     * seemed like the less bad option.
     */
    elFocusedOnMostRecentRender.current = typeof document === 'undefined' ? null : document.activeElement;
    var checkForRemovedFocusedEl = useCallback(function checkForRemovedFocusedEl(mutations) {
        var nodeContainedFocus = function (el) { return el.contains(elFocusedOnMostRecentRender.current); }, nodeListContainedFocus = pipe(Array.from, any(nodeContainedFocus)), focusedChildWasRemoved = any(pipe(prop('removedNodes'), nodeListContainedFocus), mutations);
        if (focusedChildWasRemoved) {
            focusTextInput();
        }
    }, []);
    useMutationObserver(menuRef, checkForRemovedFocusedEl, { childList: true });
    return (React.createElement("div", __assign({ role: "group", ref: mergedRef, className: className, onFocus: handleComponentFocus }, attrs),
        React.createElement(AsFilterInput, { ref: filterRef, className: filterClassName, value: searchText, onChange: handleFilterChange, disabled: disabled || undefined, placeholder: "Search", searchIcon: true, inputAttributes: {
                onKeyDown: handleKeyDown,
                role: 'searchbox',
                'aria-controls': showDropdown ? dropdownMenuId : undefined,
                'aria-haspopup': 'menu'
            } }),
        React.createElement(AsDropdownMenu, { id: dropdownMenuId, role: dropdownMenuRole, ref: menuRef, className: menuClassName, onClosing: function () { }, onKeyDown: handleButtonKeyDown, "aria-busy": !!loading, "aria-live": "polite", "aria-hidden": !showDropdown },
            React.createElement(AsLoadWrapper, { loading: loading, error: error, retryHandler: function () { return doSearch(searchText); } }, matches.length ? matches.map(function (match, i) {
                return React.createElement("button", { role: "menuitem", type: "button", className: "as-dropdown-button", disabled: disabled || undefined, key: match.id, tabIndex: i === focusableBtnIndex ? 0 : -1, onClick: partial(handleOnClick, [match]), onFocus: function () { return setFocusableBtnIndex(i); } }, match.displayName);
            }) :
                React.createElement("div", { className: "as-search-dropdown__empty-message" }, emptyMessage || 'No Results Found')))));
}
AsSearchDropdown.propTypes = propTypes;
//# sourceMappingURL=AsSearchDropdown.js.map