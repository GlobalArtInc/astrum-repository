import React from 'react';
import './AsSearchDropdown.scss';
import { Props } from './types';
export { Props } from './types';
export declare const SEARCH_DEBOUNCE_TIME = 500;
declare function AsSearchDropdown<T extends string | number = string>(props: Props<T>): React.JSX.Element;
declare namespace AsSearchDropdown {
    var propTypes: import("prop-types").ValidationMap<Props<string | number>>;
}
export default AsSearchDropdown;
//# sourceMappingURL=AsSearchDropdown.d.ts.map