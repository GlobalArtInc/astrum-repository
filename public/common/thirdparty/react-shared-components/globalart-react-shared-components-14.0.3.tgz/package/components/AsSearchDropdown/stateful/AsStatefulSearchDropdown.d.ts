import React from 'react';
import { StatefulProps as Props } from '../types';
declare function AsStatefulSearchDropdown<T extends string | number = string>({ defaultSearchText, onSelect: onSelectProp, ...otherProps }: Props<T>): React.JSX.Element;
declare namespace AsStatefulSearchDropdown {
    var propTypes: import("prop-types").ValidationMap<Props<string | number>>;
}
export default AsStatefulSearchDropdown;
export { Props };
//# sourceMappingURL=AsStatefulSearchDropdown.d.ts.map