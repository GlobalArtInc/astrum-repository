import * as PropTypes from 'prop-types';
import { FormEvent, ReactNode, ComponentPropsWithRef, ComponentPropsWithoutRef } from 'react';
/**
 * The valid values for the `type` Prop
 */
export declare const publicInputTypes: readonly ["textarea", "text", "password"];
export declare const inputTypes: readonly ["textarea", "text", "password", "date"];
export type AsTextInputType = (typeof inputTypes)[number];
export type PublicAsTextInputType = (typeof publicInputTypes)[number];
export type ValidationErrors = string | string[] | null;
export type Validator = ((val: string) => ValidationErrors) | null;
/**
 * Props whose value will typically change as the text input on the page is used, as opposed to props which
 * are typically constant for a given text input.
 */
export interface StateProps {
    value: string;
    trimmedValue: string;
    isPristine: boolean;
    validationErrors?: ValidationErrors;
}
type FusedProps = ComponentPropsWithoutRef<'input'> & ComponentPropsWithoutRef<'textarea'>;
export type InputAttrs = Omit<FusedProps, 'onChange' | 'onKeyPress' | 'type' | 'defaultValue' | 'disabled' | 'placeholder'>;
export type DivAttrs = Omit<ComponentPropsWithRef<'div'>, 'onChange' | 'onKeyPress' | 'defaultValue' | 'placeholder'>;
export type TextInputElement = HTMLInputElement | HTMLTextAreaElement;
export type Props = Omit<StateProps, 'trimmedValue'> & DivAttrs & {
    type?: AsTextInputType | null;
    onChange?: ((newVal: string, e?: FormEvent<TextInputElement>) => void) | null;
    onKeyPress?: ((keyCode: string) => void) | null;
    validatable?: boolean | null;
    disabled?: boolean | null;
    placeholder?: string | null;
    inputAttributes?: InputAttrs;
    prefixContent?: ReactNode | null;
    suffixContent?: ReactNode | null;
};
export interface PublicProps extends Omit<Props, 'prefixContent' | 'suffixContent'> {
    type?: PublicAsTextInputType | null;
}
export declare const propTypes: PropTypes.ValidationMap<PublicProps>;
export {};
//# sourceMappingURL=types.d.ts.map