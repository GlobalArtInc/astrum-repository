var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { useRef, useContext } from 'react';
import classnames from 'classnames';
import { omit } from 'ramda';
import { faExclamationCircle, faCheck } from '@fortawesome/free-solid-svg-icons';
import './AsTextInput.scss';
import AsFontAwesomeIcon from '../AsFontAwesomeIcon/AsFontAwesomeIcon';
import { propTypes } from './types';
import { hasValidationErrors, getFirstValidationError } from '../../util/validationUtil';
import { useUniqueId } from '../../util/idUtil';
import { FormAriaContext } from '../AsForm/context';
export { propTypes, inputTypes } from './types';
/*
 * The full implementation of AsTextInput including options that are only for use internally within
 * other RSC compoents
 */
export function PrivateAsTextInput(props) {
    var type = props.type, value = props.value, isPristine = props.isPristine, validatable = props.validatable, validationErrors = props.validationErrors, onChange = props.onChange, className = props.className, onKeyPress = props.onKeyPress, disabled = props.disabled, prefixContent = props.prefixContent, suffixContent = props.suffixContent, id = props.id, placeholder = props.placeholder, inputAttributes = props.inputAttributes, ariaRequired = props["aria-required"], ariaDescribedBy = props["aria-describedby"], attrs = __rest(props, ["type", "value", "isPristine", "validatable", "validationErrors", "onChange", "className", "onKeyPress", "disabled", "prefixContent", "suffixContent", "id", "placeholder", "inputAttributes", 'aria-required', 'aria-describedby']);
    /**
     * `trimmedValue` is a hidden property in `props`
     * We need to remove it so react doesn't complain when we pass the object
     * with the props to the `createElement` method below.
     * `title` is removed to prevent errors when `AsTextInput`, which itself uses` AsTooltip`, is wrapped
     * in another `AsTooltip`
     */
    /* eslint-disable-next-line @typescript-eslint/no-explicit-any */
    var newProps = omit(['trimmedValue', 'title'], attrs);
    var isTextArea = type === 'textarea', element = isTextArea ? 'textarea' : 'input', typeAttr = isTextArea ? undefined : (type || 'text'), formShowValidationErrors = useContext(FormAriaContext).showValidationErrors, showValidationErrors = formShowValidationErrors || !isPristine, isInvalid = validatable && showValidationErrors && hasValidationErrors(validationErrors), firstValidationError = validatable && getFirstValidationError(validationErrors), internalClassName = classnames('as-text-input', className, {
        pristine: isPristine,
        invalid: isInvalid,
        valid: !isPristine && validatable && !isInvalid,
        disabled: disabled,
        'as-text-input--textarea': isTextArea
    });
    var inputRef = useRef(null), invalidMessageId = useUniqueId('as-text-input-invalid-message');
    // when the box padding is clicked, set the focus to the <input> as that's what the user thought
    // they were clicking
    function setFocusToInput() {
        if (inputRef.current) {
            inputRef.current.focus();
        }
    }
    function inputOnChange(e) {
        if (onChange) {
            onChange(e.currentTarget.value, e);
        }
    }
    function inputOnKeyPress(e) {
        if (onKeyPress) {
            onKeyPress(e.key);
        }
    }
    return (React.createElement("div", __assign({ className: internalClassName }, newProps),
        React.createElement("div", { className: "as-text-input__box", onClick: setFocusToInput },
            prefixContent,
            React.createElement(element, __assign(__assign({}, inputAttributes), { value: value, id: id, disabled: disabled, placeholder: placeholder, ref: inputRef, type: typeAttr, onChange: inputOnChange, className: 'as-text-input__input', onKeyPress: inputOnKeyPress, 'aria-required': ariaRequired, 'aria-describedby': ariaDescribedBy, 'aria-invalid': isInvalid, 'aria-errormessage': disabled ? undefined : invalidMessageId })),
            suffixContent,
            React.createElement(AsFontAwesomeIcon, { icon: faCheck, className: "as-icon as-icon--valid" }),
            React.createElement(AsFontAwesomeIcon, { icon: faExclamationCircle, className: "as-icon as-icon--invalid" })),
        isInvalid && !disabled &&
            React.createElement("div", { id: invalidMessageId, role: "alert", className: "as-field-validation-message" }, firstValidationError)));
}
/*
 * The public version of AsTextInput
 */
var AsTextInput = PrivateAsTextInput;
export default AsTextInput;
AsTextInput.propTypes = propTypes;
//# sourceMappingURL=AsTextInput.js.map