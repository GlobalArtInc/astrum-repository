import React, { FunctionComponent } from 'react';
import './AsTextInput.scss';
import { Props, PublicProps } from './types';
export { Props, PublicProps, StateProps, Validator, propTypes, inputTypes } from './types';
export declare function PrivateAsTextInput(props: Props): React.JSX.Element;
declare const AsTextInput: FunctionComponent<PublicProps>;
export default AsTextInput;
//# sourceMappingURL=AsTextInput.d.ts.map