import React, { FunctionComponent } from 'react';
import { Props, PublicProps } from './types';
export { Props, PublicProps, propTypes } from './types';
export declare function PrivateAsStatefulTextInput(props: Props): React.JSX.Element;
declare const AsStatefulTextInput: FunctionComponent<PublicProps>;
export default AsStatefulTextInput;
//# sourceMappingURL=AsStatefulTextInput.d.ts.map