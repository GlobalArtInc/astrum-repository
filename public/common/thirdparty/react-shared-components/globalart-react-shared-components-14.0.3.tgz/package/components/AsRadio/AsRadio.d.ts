import React from 'react';
import './AsRadio.scss';
import { Props } from './types';
export { Props } from './types';
declare function AsRadio(props: Props): React.JSX.Element;
declare namespace AsRadio {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default AsRadio;
//# sourceMappingURL=AsRadio.d.ts.map