var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import classnames from 'classnames';
import { head, repeat, tail, toUpper } from 'ramda';
import { propTypes } from './types';
import './AsSmallThreatCounter.scss';
import AsTooltip from '../AsTooltip/AsTooltip';
function BaseCounter(_a) {
    var _b;
    var category = _a.category, count = _a.count, display = _a.display, children = _a.children;
    var categoryForDisplay = "".concat(toUpper((_b = head(category)) !== null && _b !== void 0 ? _b : '')).concat(tail(category)), className = classnames("as-small-threat-counter as-small-threat-counter--".concat(category), {
        'as-small-threat-counter--zero': count === 0
    });
    return (React.createElement(AsTooltip, { title: categoryForDisplay },
        React.createElement("div", { className: className },
            React.createElement("span", { className: "as-small-threat-counter__category" }, categoryForDisplay),
            React.createElement("span", { className: "as-small-threat-counter__count" }, display),
            children)));
}
function Counter(_a) {
    var category = _a.category, count = _a.count;
    return React.createElement(BaseCounter, { category: category, count: count, display: count });
}
function MaxDigitCounter(_a) {
    var category = _a.category, count = _a.count, maxDigits = _a.maxDigits;
    // If we want maxDigits = 3 that means we want room for three digits in addition to a plus sign so
    // that we can show e.g. "999+"
    var overflowDisplay = repeat('9', maxDigits).concat('+').join(''), maxValue = Math.pow(10, Math.floor(maxDigits)) - 1;
    return (React.createElement(BaseCounter, { category: category, count: count, display: count > maxValue ? overflowDisplay : count },
        React.createElement("div", { className: "as-small-threat-counter__sizer" }, overflowDisplay)));
}
export default function AsSmallThreatCounter(props) {
    var criticalCount = props.criticalCount, severeCount = props.severeCount, moderateCount = props.moderateCount, lowCount = props.lowCount, noneCount = props.noneCount, unspecifiedCount = props.unspecifiedCount, maxDigits = props.maxDigits, classNameProp = props.className, attrs = __rest(props, ["criticalCount", "severeCount", "moderateCount", "lowCount", "noneCount", "unspecifiedCount", "maxDigits", "className"]), hasMaxDigits = maxDigits !== Infinity, className = classnames('as-small-threat-counter-container', classNameProp, {
        'as-small-threat-counter-container--no-max': !hasMaxDigits
    });
    function renderCounter(category, count) {
        return hasMaxDigits ?
            React.createElement(MaxDigitCounter, { category: category, count: count, maxDigits: maxDigits || 3 }) :
            React.createElement(Counter, { category: category, count: count });
    }
    if (typeof maxDigits === 'number' && maxDigits < 1) {
        throw new Error('maxDigits must be positive');
    }
    if (typeof criticalCount !== 'number' &&
        typeof severeCount !== 'number' &&
        typeof moderateCount !== 'number' &&
        typeof lowCount !== 'number' &&
        typeof noneCount !== 'number' &&
        typeof unspecifiedCount !== 'number') {
        console.warn('No counts have been provided and so nothing will be rendered.');
        return null;
    }
    return (React.createElement("div", __assign({ className: className }, attrs),
        typeof criticalCount === 'number' && renderCounter('critical', criticalCount),
        typeof severeCount === 'number' && renderCounter('severe', severeCount),
        typeof moderateCount === 'number' && renderCounter('moderate', moderateCount),
        typeof lowCount === 'number' && renderCounter('low', lowCount),
        typeof noneCount === 'number' && renderCounter('none', noneCount),
        typeof unspecifiedCount === 'number' && renderCounter('unspecified', unspecifiedCount)));
}
AsSmallThreatCounter.propTypes = propTypes;
//# sourceMappingURL=AsSmallThreatCounter.js.map