import React from 'react';
import { Props } from './types';
export { Props } from './types';
import './AsSmallThreatCounter.scss';
declare function AsSmallThreatCounter(props: Props): React.JSX.Element | null;
declare namespace AsSmallThreatCounter {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default AsSmallThreatCounter;
//# sourceMappingURL=AsSmallThreatCounter.d.ts.map