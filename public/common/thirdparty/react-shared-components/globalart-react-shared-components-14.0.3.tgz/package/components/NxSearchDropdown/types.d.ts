import * as PropTypes from 'prop-types';
import { ReactNode, MouseEvent, ComponentPropsWithRef } from 'react';
import DataItem from '../../util/DataItem';
export interface Props<T extends string | number = string> extends Omit<ComponentPropsWithRef<'div'>, 'onSelect'> {
    searchText: string;
    onSearchTextChange: (s: string) => void;
    onSearch: (s: string) => void;
    loading?: boolean | null;
    error?: ReactNode;
    matches: DataItem<T>[];
    onSelect: (m: DataItem<T>, evt: MouseEvent<HTMLButtonElement>) => void;
    long?: boolean | null;
    disabled?: boolean | null;
    emptyMessage?: ReactNode;
}
export interface StatefulProps<T extends string | number = string> extends Omit<Props<T>, 'searchText' | 'onSearchTextChange'> {
    defaultSearchText?: string | null;
}
export declare const propTypes: PropTypes.ValidationMap<Props<string | number>>;
export declare const statefulPropTypes: PropTypes.ValidationMap<StatefulProps<string | number>>;
//# sourceMappingURL=types.d.ts.map