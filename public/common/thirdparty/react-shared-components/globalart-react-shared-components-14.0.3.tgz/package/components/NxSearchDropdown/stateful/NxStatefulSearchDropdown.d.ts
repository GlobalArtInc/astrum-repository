import React from 'react';
import { StatefulProps as Props } from '../types';
declare function NxStatefulSearchDropdown<T extends string | number = string>({ defaultSearchText, onSelect: onSelectProp, ...otherProps }: Props<T>): React.JSX.Element;
declare namespace NxStatefulSearchDropdown {
    var propTypes: import("prop-types").ValidationMap<Props<string | number>>;
}
export default NxStatefulSearchDropdown;
export { Props };
//# sourceMappingURL=NxStatefulSearchDropdown.d.ts.map