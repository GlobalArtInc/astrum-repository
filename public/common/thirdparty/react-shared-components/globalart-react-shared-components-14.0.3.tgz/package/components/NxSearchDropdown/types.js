var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import * as PropTypes from 'prop-types';
import { omit } from 'ramda';
export var propTypes = {
    loading: PropTypes.bool,
    error: PropTypes.node,
    matches: PropTypes.arrayOf(PropTypes.shape({
        id: PropTypes.oneOfType([PropTypes.string.isRequired, PropTypes.number.isRequired]).isRequired,
        displayName: PropTypes.node.isRequired
    }).isRequired).isRequired,
    onSelect: PropTypes.func.isRequired,
    onSearch: PropTypes.func.isRequired,
    long: PropTypes.bool,
    disabled: PropTypes.bool,
    emptyMessage: PropTypes.node
};
export var statefulPropTypes = __assign(__assign({}, omit(['searchText', 'onSearchTextChange'], propTypes)), { defaultSearchText: PropTypes.string });
//# sourceMappingURL=types.js.map