import React from 'react';
import './NxSearchDropdown.scss';
import { Props } from './types';
export { Props } from './types';
export declare const SEARCH_DEBOUNCE_TIME = 500;
declare function NxSearchDropdown<T extends string | number = string>(props: Props<T>): React.JSX.Element;
declare namespace NxSearchDropdown {
    var propTypes: import("prop-types").ValidationMap<Props<string | number>>;
}
export default NxSearchDropdown;
//# sourceMappingURL=NxSearchDropdown.d.ts.map