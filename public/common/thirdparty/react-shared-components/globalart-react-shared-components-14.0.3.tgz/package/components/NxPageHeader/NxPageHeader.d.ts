import React from 'react';
import { Props } from './types';
export { Props };
declare function NxPageHeader({ logo, productInfo, ...otherProps }: Props): React.JSX.Element;
declare namespace NxPageHeader {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default NxPageHeader;
//# sourceMappingURL=NxPageHeader.d.ts.map