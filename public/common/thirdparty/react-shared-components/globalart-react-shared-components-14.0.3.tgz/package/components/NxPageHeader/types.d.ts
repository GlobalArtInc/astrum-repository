import * as PropTypes from 'prop-types';
import { Props as AbstractNxPageHeaderProps } from '../AbstractNxPageHeader/types';
export interface ProductInfo {
    name: string;
    version?: string | null;
}
export interface LogoProps {
    path: string;
    alt: string;
    darkModePath?: string | null;
}
export interface Props extends Omit<AbstractNxPageHeaderProps, 'logo' | 'productInfoContent'> {
    productInfo?: ProductInfo | null;
    logo?: LogoProps | null;
}
export declare const propTypes: PropTypes.ValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map