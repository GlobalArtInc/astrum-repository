import React from 'react';
import { Props } from './types';
export { Props, PublicProps, StateProps, propTypes } from './types';
declare function AsDateInput(props: Props): React.JSX.Element;
declare namespace AsDateInput {
    var propTypes: Omit<import("prop-types").ValidationMap<import("../AsTextInput/types").PublicProps>, "type">;
}
export default AsDateInput;
//# sourceMappingURL=AsDateInput.d.ts.map