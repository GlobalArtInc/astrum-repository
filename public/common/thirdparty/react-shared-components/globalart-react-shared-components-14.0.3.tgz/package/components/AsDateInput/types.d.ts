import { Props as AsTextInputProps, PublicProps as AsTextInputPublicProps } from '../../components/AsTextInput/AsTextInput';
export { StateProps } from '../../components/AsTextInput/AsTextInput';
export type Props = Omit<AsTextInputProps, 'type'>;
export type PublicProps = Omit<AsTextInputPublicProps, 'type'>;
export declare const propTypes: Omit<import("prop-types").ValidationMap<AsTextInputPublicProps>, "type">;
//# sourceMappingURL=types.d.ts.map