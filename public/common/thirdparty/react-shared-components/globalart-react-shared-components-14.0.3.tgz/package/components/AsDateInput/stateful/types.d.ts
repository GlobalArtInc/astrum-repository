import * as PropTypes from 'prop-types';
import { Props as AsStatefulTextInputProps } from '../../AsTextInput/stateful/types';
export type Props = Omit<AsStatefulTextInputProps, 'type'>;
export declare const propTypes: PropTypes.ValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map