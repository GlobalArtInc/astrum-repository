import React from 'react';
import { Props } from './types';
export { Props, propTypes } from './types';
declare function AsStatefulDateInput(props: Props): React.JSX.Element;
declare namespace AsStatefulDateInput {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default AsStatefulDateInput;
//# sourceMappingURL=AsStatefulDateInput.d.ts.map