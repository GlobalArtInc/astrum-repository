import { omit } from 'ramda';
import { propTypes as AsStatefulTextInputPropTypes } from '../../AsTextInput/stateful/types';
export var propTypes = omit(['type'], AsStatefulTextInputPropTypes);
//# sourceMappingURL=types.js.map