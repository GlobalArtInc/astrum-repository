import PropTypes from 'prop-types';
// allowReordering, allItems, selectedItems
// are excluded in the propTypes due to clash with parametric Props;
export var propTypes = {
    availableItemsLabel: PropTypes.node,
    selectedItemsLabel: PropTypes.node,
    availableItemsCountFormatter: PropTypes.func,
    selectedItemsCountFormatter: PropTypes.func,
    showMoveAll: PropTypes.bool,
    onChange: PropTypes.func.isRequired,
    filterFn: PropTypes.func,
    availableItemsFilter: PropTypes.string.isRequired,
    selectedItemsFilter: PropTypes.string.isRequired,
    onAvailableItemsFilterChange: PropTypes.func,
    onSelectedItemsFilterChange: PropTypes.func
};
//# sourceMappingURL=types.js.map