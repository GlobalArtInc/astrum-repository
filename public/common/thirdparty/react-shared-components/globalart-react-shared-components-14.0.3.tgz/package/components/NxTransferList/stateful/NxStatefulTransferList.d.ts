import React from 'react';
import { StatefulProps } from '../types';
export { StatefulProps as Props };
export default function NxStatefulTransferList<T extends string | number = string>(props: StatefulProps<T>): React.JSX.Element;
//# sourceMappingURL=NxStatefulTransferList.d.ts.map