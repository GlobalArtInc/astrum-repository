var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { useCallback, useEffect, useMemo, useRef } from 'react';
import classnames from 'classnames';
import { chain, groupBy, indexOf, reject, uniq, without } from 'ramda';
import { propTypes } from './types';
import NxTransferListHalf from '../NxTransferListHalf/NxTransferListHalf';
import './NxTransferList.scss';
var defaultItemsCountFormatter = function (kind) { return function (n) { return "".concat(n, " item").concat(n === 1 ? '' : 's', " ").concat(kind); }; }, defaultAvailableItemsCountFormatter = defaultItemsCountFormatter('available'), defaultSelectedItemsCountFormatter = defaultItemsCountFormatter('transferred');
export default function NxTransferList(props) {
    var _a = props.allowReordering, allowReordering = _a === void 0 ? false : _a, allItems = props.allItems, selectedItems = props.selectedItems, availableItemsLabel = props.availableItemsLabel, selectedItemsLabel = props.selectedItemsLabel, showMoveAll = props.showMoveAll, availableItemsFilter = props.availableItemsFilter, selectedItemsFilter = props.selectedItemsFilter, availableItemsCountFormatterProp = props.availableItemsCountFormatter, selectedItemsCountFormatterProp = props.selectedItemsCountFormatter, onAvailableItemsFilterChange = props.onAvailableItemsFilterChange, onSelectedItemsFilterChange = props.onSelectedItemsFilterChange, classNameProp = props.className, onChangeProp = props.onChange, filterFn = props.filterFn, attrs = __rest(props, ["allowReordering", "allItems", "selectedItems", "availableItemsLabel", "selectedItemsLabel", "showMoveAll", "availableItemsFilter", "selectedItemsFilter", "availableItemsCountFormatter", "selectedItemsCountFormatter", "onAvailableItemsFilterChange", "onSelectedItemsFilterChange", "className", "onChange", "filterFn"]);
    if (allowReordering && !Array.isArray(selectedItems)) {
        throw new TypeError('selectedItems must be an array if allowReordering is true');
    }
    var selectedItemsArray = useMemo(function () { return selectedItems instanceof Array ? uniq(selectedItems) : Array.from(selectedItems); }, [selectedItems]);
    /*
     * Performance Hack: We need the memoized functions below (especially onChange and onReorderItem) to
     * remain stable as the selectedItems changes. This is because those functions get passed down into every
     * individual TransferListItem and we don't want them all to rerender every time a selection is made.
     * So to prevent those useCallbacks from having a dependency on selectedItemsArray, we additionally store the
     * selected items array in a ref which the handler functions can access without declaring it a dependency.
     * The ref must be kept in sync with selectedItemsArray manually.
     */
    var selectedItemsArrayRef = useRef(selectedItemsArray);
    useEffect(function () {
        selectedItemsArrayRef.current = selectedItemsArray;
    }, [selectedItemsArray]);
    var getSelectedItemsArray = function () { return selectedItemsArrayRef.current; };
    var availableItemsCountFormatter = availableItemsCountFormatterProp || defaultAvailableItemsCountFormatter, selectedItemsCountFormatter = selectedItemsCountFormatterProp || defaultSelectedItemsCountFormatter;
    var _b = useMemo(function () {
        var allItemsIdToItemLookUp = groupBy(function (item) { return item.id.toString(); }, allItems), selectedItemsSet = selectedItems instanceof Set ? selectedItems : new Set(selectedItems);
        return allowReordering
            ? {
                available: reject(function (item) { return selectedItemsSet.has(item.id); }, allItems),
                selected: chain(function (item) { var _a; return (_a = allItemsIdToItemLookUp[item.toString()]) !== null && _a !== void 0 ? _a : []; }, selectedItemsArray)
            }
            : groupBy(function (item) { return selectedItemsSet.has(item.id) ? 'selected' : 'available'; }, allItems);
    }, [allItems, selectedItems, allowReordering]), _c = _b.available, available = _c === void 0 ? [] : _c, _d = _b.selected, selected = _d === void 0 ? [] : _d;
    var selectedCount = selectedItemsArray.length, availableCount = allItems.length - selectedCount;
    var handleOnChangeProp = useCallback(function (array) {
        if (allowReordering) {
            onChangeProp(array);
        }
        else {
            onChangeProp(new Set(array));
        }
    }, [allowReordering, onChangeProp]);
    var onChange = useCallback(function onChange(checked, id) {
        var selectedItemsArray = getSelectedItemsArray(), newSelectedItemsArray = checked
            ? __spreadArray(__spreadArray([], selectedItemsArray, true), [id], false) : without([id], selectedItemsArray);
        handleOnChangeProp(newSelectedItemsArray);
    }, [handleOnChangeProp]);
    var onSelectAll = useCallback(function onSelectAll(idsToAdd) {
        var selectedItemsArray = getSelectedItemsArray();
        handleOnChangeProp(__spreadArray(__spreadArray([], selectedItemsArray, true), idsToAdd, true));
    }, [handleOnChangeProp]);
    var onUnselectAll = useCallback(function onUnselectAll(idsToRemove) {
        handleOnChangeProp(without(idsToRemove, getSelectedItemsArray()));
    }, [handleOnChangeProp]);
    var onReorderItem = useCallback(function onReorderItem(id, direction) {
        var selectedItemsArray = getSelectedItemsArray(), index = indexOf(id, selectedItemsArray);
        if (typeof selectedItemsArray[index + direction] === 'undefined') {
            return;
        }
        var newSelectedItems = __spreadArray([], selectedItemsArray, true);
        newSelectedItems[index] = selectedItemsArray[index + direction];
        newSelectedItems[index + direction] = selectedItemsArray[index];
        handleOnChangeProp(newSelectedItems);
    }, [handleOnChangeProp]);
    return (React.createElement("div", __assign({ role: "group", className: classnames('nx-transfer-list', classNameProp) }, attrs),
        React.createElement(NxTransferListHalf, { label: availableItemsLabel || 'Available Items', filterValue: availableItemsFilter, onFilterChange: onAvailableItemsFilterChange, showMoveAll: showMoveAll || false, onMoveAll: onSelectAll, isSelected: false, items: available, onItemChange: onChange, onReorderItem: onReorderItem, footerContent: availableItemsCountFormatter(availableCount), filterFn: filterFn, allowReordering: false }),
        React.createElement(NxTransferListHalf, { label: selectedItemsLabel || 'Transferred Items', filterValue: selectedItemsFilter, onFilterChange: onSelectedItemsFilterChange, showMoveAll: showMoveAll || false, onMoveAll: onUnselectAll, isSelected: true, items: selected, onItemChange: onChange, onReorderItem: onReorderItem, footerContent: selectedItemsCountFormatter(selectedCount), filterFn: filterFn, allowReordering: allowReordering })));
}
NxTransferList.propTypes = propTypes;
//# sourceMappingURL=NxTransferList.js.map