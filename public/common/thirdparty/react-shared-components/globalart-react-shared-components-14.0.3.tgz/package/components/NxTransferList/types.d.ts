import { ReactNode, ComponentPropsWithRef } from 'react';
import PropTypes from 'prop-types';
import { Props as NxFilterInputProps } from '../NxFilterInput/NxFilterInput';
import { NxTransferListDataItem } from '../NxTransferListHalf/types';
export type FilterFn<T extends string | number = string> = (d: NxTransferListDataItem<T>[]) => NxTransferListDataItem<T>[];
export interface BaseStatefulProps<T extends string | number = string> extends Omit<ComponentPropsWithRef<'div'>, 'children' | 'onChange'> {
    allItems: NxTransferListDataItem<T>[];
    availableItemsLabel?: ReactNode;
    selectedItemsLabel?: ReactNode;
    availableItemsCountFormatter?: ((n: number) => string) | null;
    selectedItemsCountFormatter?: ((n: number) => string) | null;
    showMoveAll?: boolean | null;
    filterFn?: ((filterStr: string, itemDisplayName: string) => boolean) | null;
}
interface UnorderedStatefulProps<T extends string | number = string> extends BaseStatefulProps<T> {
    allowReordering?: false | null;
    selectedItems: Set<T>;
    onChange: (newSelected: Set<T>) => void;
}
interface OrderedStatefulProps<T extends string | number = string> extends BaseStatefulProps<T> {
    allowReordering: true;
    selectedItems: T[];
    onChange: (newSelected: T[]) => void;
}
export type StatefulProps<T extends string | number = string> = UnorderedStatefulProps<T> | OrderedStatefulProps<T>;
export type Props<T extends string | number = string> = StatefulProps<T> & {
    availableItemsFilter: string;
    selectedItemsFilter: string;
    onAvailableItemsFilterChange: NxFilterInputProps['onChange'];
    onSelectedItemsFilterChange: NxFilterInputProps['onChange'];
};
export declare const propTypes: {
    availableItemsLabel: PropTypes.Requireable<PropTypes.ReactNodeLike>;
    selectedItemsLabel: PropTypes.Requireable<PropTypes.ReactNodeLike>;
    availableItemsCountFormatter: PropTypes.Requireable<(...args: any[]) => any>;
    selectedItemsCountFormatter: PropTypes.Requireable<(...args: any[]) => any>;
    showMoveAll: PropTypes.Requireable<boolean>;
    onChange: PropTypes.Validator<(...args: any[]) => any>;
    filterFn: PropTypes.Requireable<(...args: any[]) => any>;
    availableItemsFilter: PropTypes.Validator<string>;
    selectedItemsFilter: PropTypes.Validator<string>;
    onAvailableItemsFilterChange: PropTypes.Requireable<(...args: any[]) => any>;
    onSelectedItemsFilterChange: PropTypes.Requireable<(...args: any[]) => any>;
};
export {};
//# sourceMappingURL=types.d.ts.map