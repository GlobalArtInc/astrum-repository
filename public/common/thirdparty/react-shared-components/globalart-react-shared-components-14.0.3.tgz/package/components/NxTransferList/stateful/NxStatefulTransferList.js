var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { useState } from 'react';
import NxTransferList from '../NxTransferList';
export default function NxStatefulTransferList(props) {
    var _a = useState(''), availableItemsFilter = _a[0], setAvailableItemsFilter = _a[1], _b = useState(''), selectedItemsFilter = _b[0], setSelectedItemsFilter = _b[1];
    return React.createElement(NxTransferList, __assign({ onAvailableItemsFilterChange: setAvailableItemsFilter, onSelectedItemsFilterChange: setSelectedItemsFilter, availableItemsFilter: availableItemsFilter, selectedItemsFilter: selectedItemsFilter }, props));
}
//# sourceMappingURL=NxStatefulTransferList.js.map