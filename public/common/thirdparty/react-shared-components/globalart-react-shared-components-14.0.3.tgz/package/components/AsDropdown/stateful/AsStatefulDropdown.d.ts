import { FunctionComponent } from 'react';
import { Props } from './types';
declare const AsStatefulDropdown: FunctionComponent<Props>;
export default AsStatefulDropdown;
export { Props, propTypes } from './types';
//# sourceMappingURL=AsStatefulDropdown.d.ts.map