import React from 'react';
import { Props } from './types';
import './AsDropdown.scss';
declare function AsDropdown(props: Props): React.JSX.Element;
declare namespace AsDropdown {
    var propTypes: import("prop-types").WeakValidationMap<Props>;
    var Divider: (props: React.DetailedHTMLProps<React.HTMLAttributes<HTMLHRElement>, HTMLHRElement>) => React.ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLHRElement>, HTMLHRElement>, "className">, string | React.JSXElementConstructor<any>>;
}
export default AsDropdown;
export { Props, propTypes } from './types';
//# sourceMappingURL=AsDropdown.d.ts.map