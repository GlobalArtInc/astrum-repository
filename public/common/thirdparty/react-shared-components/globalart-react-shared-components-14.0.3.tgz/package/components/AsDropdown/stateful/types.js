import * as PropTypes from 'prop-types';
import { AS_BUTTON_VARIANTS } from '../../AsButton/types';
import { tooltipPropTypesShape } from '../../../util/tooltipUtils';
import { childrenPropTypes } from '../types';
;
export var propTypes = {
    label: PropTypes.oneOfType([
        PropTypes.node.isRequired,
        PropTypes.string.isRequired
    ]).isRequired,
    variant: PropTypes.oneOf(AS_BUTTON_VARIANTS),
    className: PropTypes.string,
    children: childrenPropTypes,
    disabled: PropTypes.bool,
    toggleTooltip: PropTypes.oneOfType([tooltipPropTypesShape, PropTypes.string])
};
//# sourceMappingURL=types.js.map