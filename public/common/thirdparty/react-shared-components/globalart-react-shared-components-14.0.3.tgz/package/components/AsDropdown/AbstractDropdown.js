var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import useMergedRef from '@react-hook/merged-ref';
import React from 'react';
import { useEffect, useRef } from 'react';
import AsDropdownMenu from '../AsDropdownMenu/AsDropdownMenu';
import { ensureRef } from '../../util/reactUtil';
/**
 * Abstracted Dropdown global event handling.
 * @param isOpen - a boolean to indicate if the dropdown is open or not.
 * @param className - a classname string for the div containing the toggle and dropdown.
 * @param disabled - If true disables toggling of dropdown.
 * @param onToggleCollapse - The onToggleCollapse function that was provided from outside of the component
 * @param onCloseClick - A callback that should fire when a click
 *    is detected that would result in the dropdown getting closed. The Mouse event is passed to this handler,
 *    and if the handler calls `preventDefault` on it, the close is cancelled
 * @param onCloseKeyDown - A callback provided that should fire when a key press
 *    is detected that would result in the dropdown getting closed. The Keyboard event is passed to this handler,
 *    and if the handler calls `preventDefault` on it, the close is cancelled
 * @param onToggleCollapse - The onToggleCollapse function that was provided from outside of the component
 * @param onKeyDown - Any onKeyDown function that might have been provided from outside of the component.
 *    Note that this fires after the close processing occurs
 * @return - A div with the toggle element and dropdown menu.
 */
export default function AbstractDropdown(props) {
    var className = props.className, isOpen = props.isOpen, disabled = props.disabled, renderToggleElement = props.renderToggleElement, children = props.children, onToggleCollapseProp = props.onToggleCollapse, onKeyDownProp = props.onKeyDown, onCloseClick = props.onCloseClick, onCloseKeyDownProp = props.onCloseKeyDown, menuRefProp = props.menuRef, attrs = __rest(props, ["className", "isOpen", "disabled", "renderToggleElement", "children", "onToggleCollapse", "onKeyDown", "onCloseClick", "onCloseKeyDown", "menuRef"]);
    var menuRef = useRef(null), mergedMenuRef = useMergedRef(menuRef, ensureRef(menuRefProp)), toggleRef = useRef(null), 
    // set in onToggleCollapse to signal to handleDocumentClick that the dropdown is opening and so shouldn't
    // immediately be closed
    openingRef = useRef(false);
    var onKeyDown = function (event) {
        if (isOpen && !disabled && event.key === 'Escape' && onToggleCollapseProp) {
            if (onCloseKeyDownProp) {
                onCloseKeyDownProp(event);
            }
            if (!event.defaultPrevented) {
                onToggleCollapseProp();
                // try to prevent the ESC from triggering multiple things, for instance closing a surrounding modal
                // in addition to the dropdown
                event.preventDefault();
            }
        }
        if (onKeyDownProp) {
            onKeyDownProp(event);
        }
    };
    var handleDocumentClick = function (event) {
        if (openingRef.current) {
            // Same event that caused the element to open in onToggleCollapse, don't immediately close
            openingRef.current = false;
        }
        else if (isOpen && onToggleCollapseProp) {
            var defaultPrevented_1 = false;
            if (onCloseClick) {
                /* when consuming code calls preventDefault on the event, we only want that to affect this dropdown.
                * Since the mouse clicks are captured at the document level, calling preventDefault on the actual
                * native event could have a wide variety of other effects, so we proxy the event object overriding
                * preventDefault with our own impl that only affects a locally-scoped variable
                */
                var proxiedClickEvent = new Proxy(event, {
                    get: function (target, prop) {
                        if (prop === 'preventDefault') {
                            return function () { defaultPrevented_1 = true; };
                        }
                        else {
                            return Reflect.get(target, prop);
                        }
                    }
                });
                onCloseClick(proxiedClickEvent);
            }
            if (!defaultPrevented_1) {
                onToggleCollapseProp();
            }
        }
    };
    function onToggleCollapse() {
        // When closing, this is handled by handlDocumentClick. So only do it here when opening
        // (i.e. when not already open)
        if (!isOpen && onToggleCollapseProp) {
            onToggleCollapseProp();
            openingRef.current = true;
        }
    }
    useEffect(function () {
        if (disabled) {
            return;
        }
        document.addEventListener('click', handleDocumentClick);
        return function cleanup() {
            document.removeEventListener('click', handleDocumentClick);
        };
    }, [disabled, isOpen]);
    // When the dropdown is closed while focus is within it, set focus back to the dropdown toggle. Otherwise
    // it goes back to the <body> which is less helpful especially when within a modal
    function onMenuClosing() {
        var focusedEl = document.activeElement, menuEl = menuRef.current, toggleEl = toggleRef.current;
        if (menuEl && menuEl.contains(focusedEl)) {
            toggleEl === null || toggleEl === void 0 ? void 0 : toggleEl.focus();
        }
    }
    return (React.createElement("div", __assign({ className: className, onKeyDown: onKeyDown }, attrs),
        renderToggleElement(toggleRef, onToggleCollapse),
        isOpen &&
            React.createElement(AsDropdownMenu, { ref: mergedMenuRef, onClosing: onMenuClosing }, children)));
}
//# sourceMappingURL=AbstractDropdown.js.map