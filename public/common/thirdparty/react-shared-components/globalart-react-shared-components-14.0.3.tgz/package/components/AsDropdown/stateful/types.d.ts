import { ReactNode, ComponentPropsWithRef } from 'react';
import * as PropTypes from 'prop-types';
import { AS_BUTTON_VARIANT_TYPE } from '../../AsButton/types';
import { TooltipConfigProps } from '../../../util/tooltipUtils';
import { OptionalReactElement } from '../../../util/reactUtil';
export interface Props extends ComponentPropsWithRef<'div'> {
    label: ReactNode | string;
    variant?: AS_BUTTON_VARIANT_TYPE | null;
    children?: OptionalReactElement | OptionalReactElement[] | null;
    disabled?: boolean | null;
    toggleTooltip?: TooltipConfigProps | string | null;
}
export declare const propTypes: PropTypes.WeakValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map