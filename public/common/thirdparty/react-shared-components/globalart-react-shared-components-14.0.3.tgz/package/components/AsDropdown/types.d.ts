import { RefObject, ReactNode, KeyboardEventHandler, Ref, ComponentPropsWithRef } from 'react';
import * as PropTypes from 'prop-types';
import { AS_BUTTON_VARIANT_TYPE } from '../AsButton/types';
import { TooltipConfigProps } from '../../util/tooltipUtils';
import { OptionalReactElement } from '../../util/reactUtil';
export type AbstractDropdownRenderToggleElement = (toggleRef: RefObject<HTMLButtonElement | null>, onToggleCollapse: (() => void)) => ReactNode;
export interface AbstractDropdownProps extends ComponentPropsWithRef<'div'> {
    isOpen: boolean;
    disabled?: boolean | null;
    renderToggleElement: AbstractDropdownRenderToggleElement;
    children?: OptionalReactElement | OptionalReactElement[] | null;
    onToggleCollapse?: (() => void) | null;
    onCloseKeyDown?: KeyboardEventHandler | null;
    onCloseClick?: ((e: MouseEvent) => void) | null;
    menuRef?: Ref<HTMLDivElement>;
}
export type Props = Omit<ComponentPropsWithRef<'div'>, 'className'> & {
    label: ReactNode | string;
    isOpen: boolean;
    variant?: AS_BUTTON_VARIANT_TYPE | null;
    className?: string | null;
    children?: OptionalReactElement | OptionalReactElement[] | null;
    disabled?: boolean | null;
    onToggleCollapse?: (() => void) | null;
    onCloseKeyDown?: KeyboardEventHandler | null;
    onCloseClick?: ((e: MouseEvent) => void) | null;
    toggleTooltip?: TooltipConfigProps | string | null;
    menuRef?: Ref<HTMLDivElement>;
};
export declare const childrenPropTypes: PropTypes.Validator<Props["children"]>;
export declare const propTypes: PropTypes.WeakValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map