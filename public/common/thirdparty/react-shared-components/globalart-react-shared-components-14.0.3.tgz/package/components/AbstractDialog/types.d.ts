import { ComponentPropsWithRef } from 'react';
export type CancelHandler = (evt: Event) => void;
export interface Props extends Omit<ComponentPropsWithRef<'dialog'>, 'open' | 'onCancel'> {
    onCancel: CancelHandler;
    useNativeCancelOnEscape?: boolean | null;
    isModal?: boolean | null;
    open?: boolean | null;
}
export interface DialogContextValue {
    dialog: HTMLDialogElement | null;
    onCancel?: CancelHandler;
}
//# sourceMappingURL=types.d.ts.map