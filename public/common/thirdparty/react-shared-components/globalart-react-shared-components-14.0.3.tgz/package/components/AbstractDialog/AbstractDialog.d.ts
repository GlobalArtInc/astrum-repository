import React from 'react';
import { Props, DialogContextValue } from './types';
export declare const DialogContext: React.Context<DialogContextValue | null>;
/**
 * Abstracted Dialog element implementation and behaviors.
 * @param className - A classname string for the dialog element.
 * @param onCancel - A callback function that gets called when the dialog is canceled.
 * @return - Abstracted dialog element.
 */
export default function AbstractDialog(props: Props): React.JSX.Element;
export { Props } from './types';
//# sourceMappingURL=AbstractDialog.d.ts.map