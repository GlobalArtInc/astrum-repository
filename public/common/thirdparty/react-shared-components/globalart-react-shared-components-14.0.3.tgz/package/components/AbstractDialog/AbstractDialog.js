var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { useEffect, useRef, useState } from 'react';
import useMergedRef from '@react-hook/merged-ref';
import { getFirstVisibleFocusableElement } from '../../util/focusUtil';
import { ensureRef } from '../../util/reactUtil';
// https://html.spec.whatwg.org/multipage/interactive-elements.html#the-dialog-element
export var DialogContext = React.createContext(null);
// Typescript has rather obnoxiously partially removed support for HTMLDialogElement.
// See https://github.com/microsoft/TypeScript-DOM-lib-generator/issues/1029#issuecomment-907490128 and
// https://github.com/microsoft/TypeScript-DOM-lib-generator/issues/1029#issuecomment-968299542 . This even though
// Firefox appears to intend to finally add support in v98. Until TS restores this, we'll have to jump
// through some hoops...
var hasWindow = typeof window !== 'undefined', 
// eslint-disable-next-line @typescript-eslint/no-explicit-any
dynamicallyTypedWindow = hasWindow && window, hasNativeModalSupport = !!(hasWindow && dynamicallyTypedWindow.HTMLDialogElement
    && dynamicallyTypedWindow.HTMLDialogElement.prototype.show);
var createCancelEvent = function () { return new Event('cancel', { cancelable: true }); };
/**
 * Abstracted Dialog element implementation and behaviors.
 * @param className - A classname string for the dialog element.
 * @param onCancel - A callback function that gets called when the dialog is canceled.
 * @return - Abstracted dialog element.
 */
export default function AbstractDialog(props) {
    var ref = props.ref, className = props.className, children = props.children, onCancel = props.onCancel, role = props.role, isModal = props.isModal, open = props.open, attrs = __rest(props, ["ref", "className", "children", "onCancel", "role", "isModal", "open"]);
    var dialogRef = useRef(null);
    // The dialogRef value needs to get passed down in a context. But the context needs to know when the ref
    // value has updated, and refs aren't tracked like state values. So we have to copy the ref value into a state
    // value in order for it to be tracked.
    var _a = useState(null), dialogRefState = _a[0], setDialogRefState = _a[1];
    var previouslyFocusedElementRef = useRef(null);
    var mergedRef = useMergedRef(dialogRef, ensureRef(ref));
    // Handle open and close logic.
    useEffect(function () {
        /* eslint-disable-next-line @typescript-eslint/no-non-null-assertion */
        var dialogEl = dialogRef.current;
        setDialogRefState(dialogEl);
        // Open Dialog
        if (open == null || open) {
            previouslyFocusedElementRef.current = document.activeElement;
            // Use dialog method
            // We do not use showModal because it moves
            // the dialog to top-level and it overlaps
            // popovers generated from password managers.
            if (hasNativeModalSupport) {
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                dialogEl.show();
            }
            else { // Use attribute
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                dialogEl.open = true;
            }
            // Modal autofocus is not implemented because of:
            // https://stackoverflow.com/questions/60216787/react-autofocus-attribute-is-not-rendered
            getFirstVisibleFocusableElement(dialogEl).focus();
            // Focus on previously focused element.
            return function () {
                if (previouslyFocusedElementRef.current && previouslyFocusedElementRef.current instanceof HTMLElement) {
                    // The useEffect cleanup executes while the dialog is still present (in React 16 at least). While the dialog
                    // still exists, the document is still "blocked by the modal dialog" so trying to focus elements outside of
                    // it won't work. So we have to wait until the next cycle of the event loop when it's gone
                    Promise.resolve().then(function () {
                        if (previouslyFocusedElementRef.current) {
                            previouslyFocusedElementRef.current.focus();
                            previouslyFocusedElementRef.current = null;
                        }
                    });
                }
            };
        }
        // Close Dialog
        else if (open === false) {
            if (hasNativeModalSupport) { // Use dialog method
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                dialogEl.close();
            }
            else { // Use open attribute
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                dialogEl.open = false;
            }
            return undefined;
        }
        else {
            return undefined;
        }
    }, [open, isModal]);
    // Listen to the native HTMLDialogElement cancel event
    // which supporting browsers fire when the dialog is closed via ESC
    useEffect(function () {
        var dialog = dialogRef.current;
        if (dialog && hasNativeModalSupport) {
            /* eslint-disable @typescript-eslint/no-non-null-assertion */
            dialog.addEventListener('cancel', onCancel);
            return function () { dialog.removeEventListener('cancel', onCancel); };
            /* eslint-enable @typescript-eslint/no-non-null-assertion */
        }
        else {
            return undefined;
        }
    }, [onCancel]);
    function dialogKeydownListener(event) {
        if (event.key === 'Escape' || event.key === 'Esc') {
            // HACK for backwards compatibility: it is known that some downstream uses of NxModal do not provide
            // the onCancel/onCancel handler despite it being required. It is also known that these downstream uses
            // have some logic which globally manages ESC handlers for a variety of things including modals. To keep that
            // working, only stopPropagation if the onCancel callback is defined. If it isn't defined, tenuously assume
            // that the ESC handling is implemented externall and do nothing here.
            if (onCancel) {
                // prevent visibility of the keydown outside of the dialog, so that global ESC listeners on the
                // document don't pick it up
                event.stopPropagation();
                // prevent visibility to manually-registered native event listeners on the document too.
                // NOTE: this only works on listeners added after this one, which is believed to include any
                // registered in useEffect calls on components rendered simultaneously with the dialog
                event.nativeEvent.stopImmediatePropagation();
                if (!event.defaultPrevented) {
                    event.preventDefault();
                    onCancel(createCancelEvent());
                }
            }
        }
    }
    var dialogContextValue = {
        dialog: dialogRefState
    };
    return (
    // Provide the dialog element to descendants so that tooltips can attach to it instead of the body,
    // which is necessary so that they end up in the top layer rather than behind the modal
    React.createElement(DialogContext.Provider, { value: dialogContextValue },
        React.createElement("dialog", __assign({ ref: mergedRef, role: role || 'dialog', "aria-modal": !!isModal, onKeyDown: dialogKeydownListener, className: className }, attrs, { tabIndex: -1 }), children)));
}
//# sourceMappingURL=AbstractDialog.js.map