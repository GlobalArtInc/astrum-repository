import * as PropTypes from 'prop-types';
import { tooltipPropTypesShape } from '../../util/tooltipUtils';
export var propTypes = {
    onToggleCollapse: PropTypes.func,
    isOpen: PropTypes.bool.isRequired,
    disabled: PropTypes.bool,
    triggerContent: PropTypes.oneOfType([
        PropTypes.arrayOf(PropTypes.node),
        PropTypes.node
    ]),
    actionContent: PropTypes.element,
    triggerTooltip: PropTypes.oneOfType([tooltipPropTypesShape, PropTypes.string]),
    children: PropTypes.oneOfType([
        PropTypes.arrayOf(PropTypes.node),
        PropTypes.node
    ])
};
export var childPropTypes = {
    children: PropTypes.any // there isn't a proptype that quite matches/typechecks against ReactChild
};
//# sourceMappingURL=types.js.map