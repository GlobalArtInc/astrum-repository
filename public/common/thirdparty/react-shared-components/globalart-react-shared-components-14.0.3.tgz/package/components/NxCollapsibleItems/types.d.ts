import { ReactNode, ReactElement, HTMLAttributes, RefAttributes, Ref, ComponentPropsWithRef } from 'react';
import * as PropTypes from 'prop-types';
import { TooltipConfigProps } from '../../util/tooltipUtils';
export interface PublicProps extends ComponentPropsWithRef<'div'> {
    onToggleCollapse?: (() => void) | null;
    isOpen: boolean;
    disabled?: boolean | null;
    triggerContent: ReactNode;
    triggerTooltip?: TooltipConfigProps | string | null;
    actionContent?: ReactElement | null;
    children?: ReactNode;
}
export interface Props extends PublicProps {
    contentBeforeChildren?: ReactNode;
    collapsibleChildrenId?: string | null;
}
export type NxCollapsibleItemsChildElement = ReactElement<HTMLAttributes<Element> & RefAttributes<Element | null>>;
export interface NxCollapsibleItemsChildProps extends HTMLAttributes<Element> {
    ref?: Ref<Element>;
    children: NxCollapsibleItemsChildElement | string | number;
}
export declare const propTypes: PropTypes.ValidationMap<PublicProps>;
export declare const childPropTypes: PropTypes.WeakValidationMap<NxCollapsibleItemsChildProps>;
//# sourceMappingURL=types.d.ts.map