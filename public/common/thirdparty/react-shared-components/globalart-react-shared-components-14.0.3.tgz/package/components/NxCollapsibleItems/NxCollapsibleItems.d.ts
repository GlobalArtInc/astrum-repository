import React, { FC } from 'react';
import { Props, PublicProps, NxCollapsibleItemsChildProps } from './types';
export { Props, PublicProps, NxCollapsibleItemsChildProps } from './types';
import './NxCollapsibleItems.scss';
type NxCollapsibleItemsFC = FC<PublicProps> & {
    Child: FC<NxCollapsibleItemsChildProps>;
};
export declare function PrivateNxCollapsibleItems(props: Props): React.JSX.Element;
/**
 * All individual treeview children should be wrapped in this component. When the child is an element,
 * this does not actually add another element to the DOM (as doing so would cause styling and screenreading
 * challenges) but instead adds the needed class and role to its child. If on the other hand the child is text,
 * this wraps it in a div
 */
export declare function NxCollapsibleItemsChild({ children, className, ...otherProps }: NxCollapsibleItemsChildProps): React.JSX.Element;
export declare namespace NxCollapsibleItemsChild {
    var propTypes: import("prop-types").WeakValidationMap<NxCollapsibleItemsChildProps>;
}
declare const NxCollapsibleItems: NxCollapsibleItemsFC;
export default NxCollapsibleItems;
//# sourceMappingURL=NxCollapsibleItems.d.ts.map