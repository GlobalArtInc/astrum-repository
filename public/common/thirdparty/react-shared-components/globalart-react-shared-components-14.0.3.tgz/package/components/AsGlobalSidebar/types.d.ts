import * as PropTypes from 'prop-types';
import { ReactNode, ComponentPropsWithRef } from 'react';
import { IconDefinition } from '@fortawesome/fontawesome-svg-core';
import RequiredReactNode from '../../util/RequiredReactNode';
export interface Props {
    isOpen: boolean;
    className?: string | null;
    toggleOpenIcon: IconDefinition;
    toggleCloseIcon: IconDefinition;
    onToggleClick: (() => void);
    logoImg: string;
    logoAltText: string;
    logoLink: string;
    children?: ReactNode | null;
}
export declare const propTypes: PropTypes.ValidationMap<Props>;
export type AsGlobalSidebarNavigationProps = ComponentPropsWithRef<'div'>;
export declare const asGlobalSidebarNavigationPropTypes: {
    className: PropTypes.Requireable<string>;
};
export interface AsGlobalSidebarNavigationLinkProps extends ComponentPropsWithRef<'a'> {
    isSelected?: boolean | null;
    icon: IconDefinition;
    text: RequiredReactNode;
    href: string;
}
export declare const asGlobalSidebarNavigationLinkPropTypes: PropTypes.ValidationMap<AsGlobalSidebarNavigationLinkProps>;
export interface AsGlobalSidebarFooterProps extends ComponentPropsWithRef<'div'> {
    supportText?: ReactNode | null;
    supportLink?: string | null;
    releaseText?: ReactNode | null;
    productTagLine?: ReactNode | null;
    showCreatedBy?: boolean | null;
}
export declare const asGlobalSidebarFooterPropTypes: PropTypes.ValidationMap<AsGlobalSidebarFooterProps>;
//# sourceMappingURL=types.d.ts.map