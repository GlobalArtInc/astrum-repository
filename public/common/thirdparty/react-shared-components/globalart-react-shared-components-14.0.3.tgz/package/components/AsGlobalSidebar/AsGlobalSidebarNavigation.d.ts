import { FunctionComponent } from 'react';
import { AsGlobalSidebarNavigationProps as Props } from './types';
export { AsGlobalSidebarNavigationProps } from './types';
declare const AsGlobalSidebarNavigation: FunctionComponent<Props>;
export default AsGlobalSidebarNavigation;
//# sourceMappingURL=AsGlobalSidebarNavigation.d.ts.map