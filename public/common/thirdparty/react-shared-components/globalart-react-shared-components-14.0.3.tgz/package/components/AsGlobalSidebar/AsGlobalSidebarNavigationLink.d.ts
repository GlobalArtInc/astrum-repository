import { FunctionComponent } from 'react';
import { AsGlobalSidebarNavigationLinkProps as Props } from './types';
export { AsGlobalSidebarNavigationLinkProps } from './types';
declare const AsGlobalSidebarNavigationLink: FunctionComponent<Props>;
export default AsGlobalSidebarNavigationLink;
//# sourceMappingURL=AsGlobalSidebarNavigationLink.d.ts.map