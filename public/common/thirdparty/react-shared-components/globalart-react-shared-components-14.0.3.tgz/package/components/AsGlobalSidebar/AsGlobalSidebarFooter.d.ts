import { FunctionComponent } from 'react';
import { AsGlobalSidebarFooterProps as Props } from './types';
export { AsGlobalSidebarFooterProps } from './types';
declare const AsGlobalSidebarFooter: FunctionComponent<Props>;
export default AsGlobalSidebarFooter;
//# sourceMappingURL=AsGlobalSidebarFooter.d.ts.map