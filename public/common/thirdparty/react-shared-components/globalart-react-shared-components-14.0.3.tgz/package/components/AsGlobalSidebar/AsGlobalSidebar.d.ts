import { FunctionComponent } from 'react';
import { Props } from './types';
import './AsGlobalSidebar.scss';
declare const AsGlobalSidebar: FunctionComponent<Props>;
export default AsGlobalSidebar;
export { Props, propTypes } from './types';
//# sourceMappingURL=AsGlobalSidebar.d.ts.map