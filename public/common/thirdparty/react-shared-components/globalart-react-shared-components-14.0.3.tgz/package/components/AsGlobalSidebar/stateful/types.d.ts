import * as PropTypes from 'prop-types';
import { Props as AsGlobalSidebarProps } from '../types';
export interface Props extends Omit<AsGlobalSidebarProps, 'isOpen' | 'onToggleClick'> {
    isDefaultOpen: boolean;
}
export declare const propTypes: PropTypes.ValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map