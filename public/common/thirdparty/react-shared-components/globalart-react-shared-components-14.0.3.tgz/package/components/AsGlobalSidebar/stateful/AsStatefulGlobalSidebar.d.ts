import { FunctionComponent } from 'react';
import { Props } from './types';
declare const AsStatefulGlobalSidebar: FunctionComponent<Props>;
export default AsStatefulGlobalSidebar;
export { Props, propTypes } from './types';
//# sourceMappingURL=AsStatefulGlobalSidebar.d.ts.map