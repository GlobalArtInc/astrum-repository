/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import classnames from 'classnames';
import AsButton from '../AsButton/AsButton';
import AsFontAwesomeIcon from '../AsFontAwesomeIcon/AsFontAwesomeIcon';
import { useUniqueId } from '../../util/idUtil';
import { propTypes } from './types';
import './AsGlobalSidebar.scss';
import { splitOutFirst } from '../../util/childUtil';
import AsGlobalSidebarFooter from './AsGlobalSidebarFooter';
var AsGlobalSidebar = function AsGlobalSidebar(props) {
    var isOpen = props.isOpen, children = props.children, className = props.className, toggleOpenIcon = props.toggleOpenIcon, toggleCloseIcon = props.toggleCloseIcon, onToggleClick = props.onToggleClick, logoImg = props.logoImg, logoAltText = props.logoAltText, logoLink = props.logoLink;
    var id = useUniqueId('as-global-sidebar');
    var classes = classnames(className, 'as-global-sidebar as-viewport-sized', {
        'open': isOpen,
        'closed': !isOpen
    });
    var toggleButtonIcon = isOpen ? toggleOpenIcon : toggleCloseIcon;
    var toggleButtonTitle = isOpen ? 'Collapse Sidebar' : 'Expand Sidebar';
    var toggleButton = (React.createElement(AsButton, { "aria-expanded": isOpen, "aria-controls": id, variant: "icon-only", onClick: onToggleClick, className: "as-global-sidebar__toggle", title: toggleButtonTitle },
        React.createElement(AsFontAwesomeIcon, { icon: toggleButtonIcon, fixedWidth: true })));
    var logo = React.createElement("img", { src: logoImg, alt: logoAltText, className: "as-global-sidebar__logo" }), _a = splitOutFirst(AsGlobalSidebarFooter, children), footer = _a[0], otherChildren = _a[1];
    return (React.createElement("div", { className: classes, id: id },
        React.createElement("aside", { className: "as-viewport-sized__container", "aria-label": "global sidebar" },
            React.createElement("div", { className: "as-global-sidebar__header" },
                React.createElement("a", { className: "as-global-sidebar__product-info", href: logoLink }, logo),
                toggleButton),
            otherChildren),
        footer));
};
AsGlobalSidebar.propTypes = propTypes;
export default AsGlobalSidebar;
export { propTypes } from './types';
//# sourceMappingURL=AsGlobalSidebar.js.map