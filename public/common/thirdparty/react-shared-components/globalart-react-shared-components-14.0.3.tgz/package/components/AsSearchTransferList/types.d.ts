import { ComponentPropsWithRef } from 'react';
import * as PropTypes from 'prop-types';
import { Props as AsSearchDropdownProps } from '../AsSearchDropdown/types';
import { Props as AsTransferListHalfProps } from '../AsTransferListHalf/types';
export interface StatefulProps<T extends string | number = string> extends ComponentPropsWithRef<'div'> {
    onSearch: AsSearchDropdownProps<T>['onSearch'];
    loading: AsSearchDropdownProps<T>['loading'];
    loadError?: AsSearchDropdownProps<T>['error'];
    searchMatches: AsSearchDropdownProps<T>['matches'];
    onSearchMatchSelect: AsSearchDropdownProps<T>['onSelect'];
    addedItemsLabel?: string | null;
    showRemoveAll?: boolean | null;
    addedItems: AsTransferListHalfProps<T>['items'];
    onRemove: (newAddedItems: AsTransferListHalfProps<T>['items']) => void;
    addedItemsCountFormatter?: ((n: number) => string) | null;
    filterFn?: ((filterStr: string, itemDisplayName: string) => boolean) | null;
}
export interface Props<T extends string | number = string> extends StatefulProps<T> {
    searchText: AsSearchDropdownProps<T>['searchText'];
    onSearchTextChange: AsSearchDropdownProps<T>['onSearchTextChange'];
    addedItemsFilter: AsTransferListHalfProps<T>['filterValue'];
    onAddedItemsFilterChange: AsTransferListHalfProps<T>['onFilterChange'];
}
export declare const statefulPropTypes: PropTypes.ValidationMap<StatefulProps<string | number>>;
export declare const propTypes: PropTypes.ValidationMap<Props<string | number>>;
//# sourceMappingURL=types.d.ts.map