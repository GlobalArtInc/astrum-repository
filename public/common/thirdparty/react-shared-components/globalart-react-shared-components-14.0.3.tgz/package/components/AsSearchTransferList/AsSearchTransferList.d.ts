import React from 'react';
import './AsSearchTransferList.scss';
import { Props } from './types';
export { Props };
declare function AsSearchTransferList<T extends string | number>(props: Props<T>): React.JSX.Element;
declare namespace AsSearchTransferList {
    var propTypes: import("prop-types").ValidationMap<Props<string | number>>;
}
export default AsSearchTransferList;
//# sourceMappingURL=AsSearchTransferList.d.ts.map