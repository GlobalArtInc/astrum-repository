import React from 'react';
import { StatefulProps as Props } from '../types';
export { Props };
declare function AsStatefulSearchTransferList<T extends string | number>(props: Props<T>): React.JSX.Element;
declare namespace AsStatefulSearchTransferList {
    var propTypes: import("prop-types").ValidationMap<Props<string | number>>;
}
export default AsStatefulSearchTransferList;
//# sourceMappingURL=AsStatefulSearchTransferList.d.ts.map