import * as PropTypes from 'prop-types';
import { optionalPercentNumber } from '../../util/customPropTypes';
export var propTypes = {
    value: PropTypes.number,
    percent: optionalPercentNumber,
    innerRadiusPercent: optionalPercentNumber,
    maxVal: PropTypes.number
};
//# sourceMappingURL=types.js.map