import { ComponentPropsWithRef } from 'react';
import * as PropTypes from 'prop-types';
interface BaseProps extends ComponentPropsWithRef<'svg'> {
    innerRadiusPercent?: number | null;
    maxVal?: number | null;
}
interface CurrentProps extends BaseProps {
    value: number;
    percent?: never;
}
interface DeprecatedProps extends BaseProps {
    value?: never;
    percent: number;
}
export type Props = CurrentProps | DeprecatedProps;
export declare const propTypes: PropTypes.ValidationMap<Props>;
export {};
//# sourceMappingURL=types.d.ts.map