import React from 'react';
import { Props } from './types';
export { Props } from './types';
import './NxBinaryDonutChart.scss';
declare function NxBinaryDonutChart(props: Props): React.JSX.Element;
declare namespace NxBinaryDonutChart {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default NxBinaryDonutChart;
//# sourceMappingURL=NxBinaryDonutChart.d.ts.map