var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import { propTypes } from './types';
import './NxBinaryDonutChart.scss';
import classnames from 'classnames';
export default function NxBinaryDonutChart(props) {
    var ref = props.ref, innerRadiusPercent = props.innerRadiusPercent, value = props.value, percent = props.percent, className = props.className, maxVal = props.maxVal, svgAttrs = __rest(props, ["ref", "innerRadiusPercent", "value", "percent", "className", "maxVal"]);
    var donutClasses = classnames('nx-binary-donut-chart', className);
    var max = maxVal !== null && maxVal !== void 0 ? maxVal : 100;
    var calculatedPercent = value ? value / max * 100 : percent;
    var calculatedValue = value !== null && value !== void 0 ? value : calculatedPercent * max / 100;
    // _Not counting the borders_, the inner radius is defined as a percentage
    // of the outer radius. Of the 30x30 viewbox, 1px on each side is border - the area that
    // the inner radius is relative to is actually 28x28 which is what the 14 and 7 here derive from
    var innerRadius = innerRadiusPercent == null ? 7 :
        (Math.min(100, Math.max(0, innerRadiusPercent)) / 100) * 14;
    var innerBorderRadius = innerRadius - 0.5;
    var donutWidth = 14 - innerRadius;
    var arcR = innerRadius + (donutWidth / 2);
    // Add 0.5π because we want the angle from the top of the circle, not the right
    var arcEndAngle = (Math.PI / 2) + (2 * Math.PI * (calculatedPercent / 100));
    // Multiply by -1 to fill clockwise not counter-clockwise
    var arcEndX = -1 * arcR * Math.cos(arcEndAngle);
    // Multiply by -1 because the y value increases going downwards on the screen, not upwards
    var arcEndY = -1 * arcR * Math.sin(arcEndAngle);
    var largeArc = calculatedPercent > 50 ? 1 : 0;
    return (React.createElement("svg", __assign({ ref: ref, viewBox: "-15 -15 30 30", role: "meter", "aria-valuemin": 0, "aria-valuemax": max, "aria-valuenow": calculatedValue, className: donutClasses }, svgAttrs),
        React.createElement("path", { className: "nx-binary-donut-chart__background", d: "M 0 -14.5\n                  a 14.5 14.5 0 1 1 0 29\n                  a 14.5 14.5 0 1 1 0 -29\n                ".concat(innerBorderRadius <= 0 ? '' :
                "M 0 ".concat(-innerBorderRadius, "\n                    a ").concat(innerBorderRadius, " ").concat(innerBorderRadius, " 0 1 1 0 ").concat(innerBorderRadius * 2, "\n                    a ").concat(innerBorderRadius, " ").concat(innerBorderRadius, " 0 1 1 0 ").concat(-innerBorderRadius * 2)) }),
        calculatedPercent > 0 && calculatedPercent < 100 &&
            React.createElement("path", { className: "nx-binary-donut-chart__arc", d: "M 0 ".concat(-arcR, " A ").concat(arcR, " ").concat(arcR, " 0 ").concat(largeArc, " 1 ").concat(arcEndX, " ").concat(arcEndY), strokeWidth: donutWidth }),
        calculatedPercent >= 100 &&
            React.createElement("circle", { className: "nx-binary-donut-chart__arc", strokeWidth: donutWidth, r: arcR })));
}
NxBinaryDonutChart.propTypes = propTypes;
//# sourceMappingURL=NxBinaryDonutChart.js.map