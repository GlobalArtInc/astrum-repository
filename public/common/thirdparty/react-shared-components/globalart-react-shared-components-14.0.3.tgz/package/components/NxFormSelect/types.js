import * as PropTypes from 'prop-types';
export var propTypes = {
    isPristine: PropTypes.bool,
    validatable: PropTypes.bool,
    validationErrors: PropTypes.oneOfType([PropTypes.arrayOf(PropTypes.string.isRequired), PropTypes.string])
};
//# sourceMappingURL=types.js.map