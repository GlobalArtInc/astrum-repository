import { ComponentPropsWithoutRef, Ref } from 'react';
import * as PropTypes from 'prop-types';
import { ValidationErrors } from '../../util/validationUtil';
export interface Props extends Omit<ComponentPropsWithoutRef<'select'>, 'onChange'> {
    ref?: Ref<HTMLDivElement>;
    isPristine?: boolean | null;
    validatable?: boolean | null;
    validationErrors?: ValidationErrors;
    onChange?: ((val: string) => void) | null;
}
export declare const propTypes: PropTypes.ValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map