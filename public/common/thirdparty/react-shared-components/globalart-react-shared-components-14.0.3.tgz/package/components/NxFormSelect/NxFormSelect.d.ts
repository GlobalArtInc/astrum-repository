import React from 'react';
import { Props } from './types';
import './NxFormSelect.scss';
export { Props };
declare function NxFormSelect(props: Props): React.JSX.Element;
declare namespace NxFormSelect {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default NxFormSelect;
//# sourceMappingURL=NxFormSelect.d.ts.map