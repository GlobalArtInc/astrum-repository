var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { useContext } from 'react';
import classnames from 'classnames';
import { propTypes } from './types';
import { FormAriaContext } from '../NxForm/context';
import { getFirstValidationError, hasValidationErrors } from '../../util/validationUtil';
import { useUniqueId } from '../../util/idUtil';
import './NxFormSelect.scss';
import NxFontAwesomeIcon from '../NxFontAwesomeIcon/NxFontAwesomeIcon';
import { faCaretDown } from '@fortawesome/free-solid-svg-icons';
export default function NxFormSelect(props) {
    var ref = props.ref, classNameProp = props.className, validatable = props.validatable, isPristine = props.isPristine, validationErrors = props.validationErrors, onChange = props.onChange, attrs = __rest(props, ["ref", "className", "validatable", "isPristine", "validationErrors", "onChange"]), formShowValidationErrors = useContext(FormAriaContext).showValidationErrors, showValidationErrors = formShowValidationErrors || !isPristine, isInvalid = !!(validatable && showValidationErrors && hasValidationErrors(validationErrors)), firstValidationError = validatable && getFirstValidationError(validationErrors), invalidMessageId = useUniqueId('nx-form-select-invalid-message'), className = classnames('nx-form-select', classNameProp, {
        pristine: isPristine,
        invalid: isInvalid,
        valid: !isPristine && validatable && !isInvalid
    });
    function selectOnChange(e) {
        if (onChange) {
            onChange(e.currentTarget.value);
        }
    }
    return (React.createElement("div", { ref: ref, className: className },
        React.createElement("select", __assign({ className: "nx-form-select__select", onChange: selectOnChange }, attrs, { "aria-invalid": isInvalid, "aria-errormessage": invalidMessageId })),
        React.createElement(NxFontAwesomeIcon, { role: "presentation", className: "nx-form-select__caret", icon: faCaretDown }),
        isInvalid &&
            React.createElement("div", { id: invalidMessageId, role: "alert", className: "nx-field-validation-message" }, firstValidationError)));
}
NxFormSelect.propTypes = propTypes;
//# sourceMappingURL=NxFormSelect.js.map