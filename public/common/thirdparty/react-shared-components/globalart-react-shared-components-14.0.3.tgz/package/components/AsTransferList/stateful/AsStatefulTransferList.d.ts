import React from 'react';
import { StatefulProps } from '../types';
export { StatefulProps as Props };
export default function AsStatefulTransferList<T extends string | number = string>(props: StatefulProps<T>): React.JSX.Element;
//# sourceMappingURL=AsStatefulTransferList.d.ts.map