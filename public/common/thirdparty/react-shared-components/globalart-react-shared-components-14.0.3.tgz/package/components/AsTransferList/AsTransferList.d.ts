import React from 'react';
import { Props } from './types';
import './AsTransferList.scss';
export { Props };
declare function AsTransferList<T extends string | number = string>(props: Props<T>): React.JSX.Element;
declare namespace AsTransferList {
    var propTypes: {
        availableItemsLabel: import("prop-types").Requireable<import("prop-types").ReactNodeLike>;
        selectedItemsLabel: import("prop-types").Requireable<import("prop-types").ReactNodeLike>;
        availableItemsCountFormatter: import("prop-types").Requireable<(...args: any[]) => any>;
        selectedItemsCountFormatter: import("prop-types").Requireable<(...args: any[]) => any>;
        showMoveAll: import("prop-types").Requireable<boolean>;
        onChange: import("prop-types").Validator<(...args: any[]) => any>;
        filterFn: import("prop-types").Requireable<(...args: any[]) => any>;
        availableItemsFilter: import("prop-types").Validator<string>;
        selectedItemsFilter: import("prop-types").Validator<string>;
        onAvailableItemsFilterChange: import("prop-types").Requireable<(...args: any[]) => any>;
        onSelectedItemsFilterChange: import("prop-types").Requireable<(...args: any[]) => any>;
    };
}
export default AsTransferList;
//# sourceMappingURL=AsTransferList.d.ts.map