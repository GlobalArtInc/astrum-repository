import React from 'react';
export declare const ColumnCountContext: React.Context<number>;
export declare const HeaderContext: React.Context<boolean>;
export declare const RowContext: React.Context<{
    label: string;
    isFilterHeader: boolean;
}>;
//# sourceMappingURL=contexts.d.ts.map