import React from 'react';
import { NxTableBodyProps } from './types';
export { NxTableBodyProps };
declare const NxTableBody: {
    (props: NxTableBodyProps): React.JSX.Element;
    propTypes: import("prop-types").ValidationMap<NxTableBodyProps>;
};
export default NxTableBody;
//# sourceMappingURL=NxTableBody.d.ts.map