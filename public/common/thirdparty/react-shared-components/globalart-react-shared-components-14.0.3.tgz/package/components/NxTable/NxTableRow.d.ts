import React from 'react';
import { NxTableRowProps } from './types';
export { NxTableRowProps };
declare function NxTableRow(props: NxTableRowProps): React.JSX.Element;
declare namespace NxTableRow {
    var propTypes: import("prop-types").ValidationMap<NxTableRowProps>;
}
export default NxTableRow;
//# sourceMappingURL=NxTableRow.d.ts.map