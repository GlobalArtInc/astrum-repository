import React from 'react';
import NxTableRow from './NxTableRow';
import { NxTableProps } from './types';
export { NxTableProps };
declare const NxTable: {
    (props: NxTableProps): React.JSX.Element;
    Body: {
        (props: import("./types").NxTableBodyProps): React.JSX.Element;
        propTypes: import("prop-types").ValidationMap<import("./types").NxTableBodyProps>;
    };
    Head: {
        (props: import("./types").NxTableHeadProps): React.JSX.Element;
        propTypes: import("prop-types").ValidationMap<React.DetailedHTMLProps<React.HTMLAttributes<HTMLTableSectionElement>, HTMLTableSectionElement>>;
    };
    Row: typeof NxTableRow;
    Cell: {
        (props: import("./types").NxTableCellProps): React.JSX.Element;
        propTypes: import("prop-types").ValidationMap<import("./types").NxTableCellProps>;
    };
    propTypes: import("prop-types").ValidationMap<NxTableProps>;
};
export default NxTable;
//# sourceMappingURL=NxTable.d.ts.map