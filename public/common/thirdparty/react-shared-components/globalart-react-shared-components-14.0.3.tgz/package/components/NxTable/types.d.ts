import { ReactNode, ComponentPropsWithRef } from 'react';
import PropTypes from 'prop-types';
import { IconDefinition } from '@fortawesome/fontawesome-svg-core';
export interface NxTableProps extends ComponentPropsWithRef<'table'> {
    caption?: string | null;
}
export declare const nxTablePropTypes: PropTypes.ValidationMap<NxTableProps>;
export type NxTableBodyProps = ComponentPropsWithRef<'tbody'> & {
    isLoading?: boolean | null;
    error?: string | null;
    emptyMessage?: ReactNode | null;
    retryHandler?: (() => void) | null;
};
export declare const nxTableBodyPropTypes: PropTypes.ValidationMap<NxTableBodyProps>;
export type NxTableCellProps = (ComponentPropsWithRef<'th'> | ComponentPropsWithRef<'td'>) & {
    metaInfo?: boolean | null;
    isNumeric?: boolean | null;
    isSortable?: boolean | null;
    isFilterHeader?: boolean | null;
    hasIcon?: boolean | null;
    chevron?: boolean | null;
    rowBtnIcon?: IconDefinition | null;
    sortDir?: 'asc' | 'desc' | null;
};
export declare const nxTableCellPropTypes: PropTypes.ValidationMap<NxTableCellProps>;
export type NxTableHeadProps = ComponentPropsWithRef<'thead'>;
export declare const nxTableHeadPropTypes: PropTypes.ValidationMap<NxTableHeadProps>;
export type NxTableRowProps = ComponentPropsWithRef<'tr'> & {
    isFilterHeader?: boolean | null;
    isClickable?: boolean | null;
    selected?: boolean | null;
    clickAccessibleLabel?: string | null;
};
export declare const nxTableRowPropTypes: PropTypes.ValidationMap<NxTableRowProps>;
//# sourceMappingURL=types.d.ts.map