import PropTypes from 'prop-types';
;
export var nxTablePropTypes = {
    children: PropTypes.node
};
export var nxTableBodyPropTypes = {
    isLoading: PropTypes.bool,
    error: PropTypes.string,
    emptyMessage: PropTypes.node,
    retryHandler: PropTypes.func,
    children: PropTypes.node
};
export var nxTableCellPropTypes = {
    metaInfo: PropTypes.bool,
    isNumeric: PropTypes.bool,
    isSortable: PropTypes.bool,
    isFilterHeader: PropTypes.bool,
    hasIcon: PropTypes.bool,
    chevron: PropTypes.bool,
    sortDir: PropTypes.oneOf(['asc', 'desc', null]),
    children: PropTypes.node
};
export var nxTableHeadPropTypes = {
    children: PropTypes.node
};
export var nxTableRowPropTypes = {
    isFilterHeader: PropTypes.bool,
    isClickable: PropTypes.bool,
    selected: PropTypes.bool,
    clickAccessibleLabel: PropTypes.string,
    children: PropTypes.node
};
//# sourceMappingURL=types.js.map