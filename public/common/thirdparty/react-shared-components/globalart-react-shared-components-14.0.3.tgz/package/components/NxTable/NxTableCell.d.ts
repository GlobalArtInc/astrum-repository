import React from 'react';
import { NxTableCellProps } from './types';
export { NxTableCellProps };
declare const NxTableCell: {
    (props: NxTableCellProps): React.JSX.Element;
    propTypes: import("prop-types").ValidationMap<NxTableCellProps>;
};
export default NxTableCell;
//# sourceMappingURL=NxTableCell.d.ts.map