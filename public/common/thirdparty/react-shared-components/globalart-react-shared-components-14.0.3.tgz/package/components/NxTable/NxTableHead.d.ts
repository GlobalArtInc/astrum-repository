import React from 'react';
import { NxTableHeadProps } from './types';
export { NxTableHeadProps };
declare const NxTableHead: {
    (props: NxTableHeadProps): React.JSX.Element;
    propTypes: import("prop-types").ValidationMap<React.DetailedHTMLProps<React.HTMLAttributes<HTMLTableSectionElement>, HTMLTableSectionElement>>;
};
export default NxTableHead;
//# sourceMappingURL=NxTableHead.d.ts.map