import React from 'react';
import { Props } from './types';
import './AsFormSelect.scss';
export { Props };
declare function AsFormSelect(props: Props): React.JSX.Element;
declare namespace AsFormSelect {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default AsFormSelect;
//# sourceMappingURL=AsFormSelect.d.ts.map