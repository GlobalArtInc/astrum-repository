import { ValidationErrors } from '../../util/validationUtil';
interface StateProps<T extends string | number> {
    value: T;
    isPristine: boolean;
    validationErrors: ValidationErrors;
}
type Validator<T> = (val: T) => ValidationErrors;
/**
 * @return an initialized state with the specified value and isPristine set to true.
 */
export declare function initialState<T extends string | number>(value: T, validator?: Validator<T>): StateProps<T>;
/**
 * @return a state useful once a user has adjusted the value of a form select: one with the specified value and
 * isPristine set to false.
 */
export declare function userInput<T extends string | number>(newValue: T, validator?: Validator<T>): StateProps<T>;
/**
 * A react hook for managing AsFormSelect state.
 * @param initialValue The initial `value` desired for the AsFormSelect
 * @return a tuple containing:
 *   A StateProps object containing the current value and isPristine flag, which can be passed as props to an
 *   AsFormSelect.
 *   A updater function that takes a new value and initiates a new render with that value, similarly to the
 *   second return value of React's `useState` hook
 */
export declare function useAsFormSelectState<T extends string | number>(initialValue: T, validator?: Validator<T>): [StateProps<T>, (v: T) => void];
export {};
//# sourceMappingURL=stateHelpers.d.ts.map