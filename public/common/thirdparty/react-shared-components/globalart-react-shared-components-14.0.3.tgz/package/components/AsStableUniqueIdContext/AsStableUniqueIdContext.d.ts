import React, { ProviderProps } from 'react';
/**
 * Establishes a separate provided value for the StableUniqueIdContext, which is used by the idUtils
 */
export default function AsStableUniqueIdContext(props: Omit<ProviderProps<never>, 'value'>): React.JSX.Element;
//# sourceMappingURL=AsStableUniqueIdContext.d.ts.map