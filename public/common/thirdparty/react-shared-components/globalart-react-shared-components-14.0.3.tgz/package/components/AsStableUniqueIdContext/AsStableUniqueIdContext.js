var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import { StableUniqueIdContext } from '../../util/idUtil';
/**
 * Establishes a separate provided value for the StableUniqueIdContext, which is used by the idUtils
 */
export default function AsStableUniqueIdContext(props) {
    return React.createElement(StableUniqueIdContext.Provider, __assign({ value: { value: 0 } }, props));
}
//# sourceMappingURL=AsStableUniqueIdContext.js.map