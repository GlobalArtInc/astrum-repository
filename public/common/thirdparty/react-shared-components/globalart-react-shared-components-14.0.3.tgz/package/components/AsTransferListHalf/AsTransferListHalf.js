var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { memo, useMemo } from 'react';
import { filter, includes, map, partial, pipe, prop, toLower } from 'ramda';
import { faPlusCircle, faTimesCircle, faArrowDown, faArrowUp } from '@fortawesome/free-solid-svg-icons';
import classnames from 'classnames';
import AsFilterInput from '../AsFilterInput/AsFilterInput';
import AsFontAwesomeIcon from '../AsFontAwesomeIcon/AsFontAwesomeIcon';
import AsOverflowTooltip from '../AsTooltip/AsOverflowTooltip';
import AsButton from '../AsButton/AsButton';
import AsTooltip from '../AsTooltip/AsTooltip';
import AsFieldset from '../AsFieldset/AsFieldset';
import { textContent } from '../../util/childUtil';
import { propTypes } from './types';
import './AsTransferListHalf.scss';
import { wrapTooltipProps } from '../../util/tooltipUtils';
import { useUniqueId } from '../../util/idUtil';
import AsScrollRender from '../AsScrollRender/AsScrollRender';
function _TransferListItem(props) {
    var showReorderingButtons = props.showReorderingButtons, checked = props.checked, _a = props.isFilteredItem, isFilteredItem = _a === void 0 ? false : _a, id = props.id, displayName = props.displayName, onChangeProp = props.onChange, onReorderItem = props.onReorderItem, isTopItem = props.isTopItem, isBottomItem = props.isBottomItem, tooltip = props.tooltip;
    function onChange(evt) {
        // NOTE: the `checked` property on the DOM node will have the new value, not the old
        onChangeProp === null || onChangeProp === void 0 ? void 0 : onChangeProp(evt.currentTarget.checked, id);
    }
    var classes = classnames('as-transfer-list__item', {
        'as-transfer-list__item--with-reordering': !!showReorderingButtons,
        'as-transfer-list__item--movable': !!onChangeProp
    });
    var moveUpDisabled = isFilteredItem || isTopItem;
    var moveDownDisabled = isFilteredItem || isBottomItem;
    var moveUpButtonTitle = moveUpDisabled ? 'Move Up (disabled)' : 'Move Up';
    var moveDownButtonTitle = moveDownDisabled ? 'Move Down (disabled)' : 'Move Down';
    var tooltipProps = tooltip && wrapTooltipProps(tooltip), Tooltip = tooltipProps ? AsTooltip : AsOverflowTooltip;
    var displayNameId = useUniqueId('as-transfer-list-item-name');
    return (React.createElement("div", { role: "group", "aria-labelledby": displayNameId, className: classes },
        React.createElement(Tooltip, __assign({}, tooltipProps),
            React.createElement("label", { className: "as-transfer-list__select" },
                !!onChangeProp &&
                    React.createElement(React.Fragment, null,
                        React.createElement(AsFontAwesomeIcon, { icon: checked ? faTimesCircle : faPlusCircle }),
                        React.createElement("input", { className: "as-transfer-list__checkbox", type: "checkbox", checked: checked, onChange: onChange })),
                React.createElement("span", { id: displayNameId, className: "as-transfer-list__display-name" }, displayName))),
        showReorderingButtons && (React.createElement(AsTooltip, { title: isFilteredItem ? 'Reordering is disabled when filtered' : '' },
            React.createElement("div", { className: "as-btn-bar as-transfer-list__button-bar" },
                React.createElement(AsTooltip, { title: isFilteredItem ? '' : moveUpButtonTitle, placement: "left" },
                    React.createElement(AsButton, { type: "button", variant: "icon-only", className: moveUpDisabled ? 'disabled' : '', onClick: function () { return !moveUpDisabled && onReorderItem && onReorderItem(id, -1); } },
                        React.createElement(AsFontAwesomeIcon, { icon: faArrowUp }))),
                React.createElement(AsTooltip, { title: isFilteredItem ? '' : moveDownButtonTitle, placement: "right" },
                    React.createElement(AsButton, { type: "button", variant: "icon-only", className: moveDownDisabled ? 'disabled' : '', onClick: function () { return !moveDownDisabled && onReorderItem && onReorderItem(id, 1); } },
                        React.createElement(AsFontAwesomeIcon, { icon: faArrowDown }))))))));
}
var TransferListItem = memo(_TransferListItem);
/*
 * Used by AsTransferList and AsSearchTransferList, but also available on its own for more flexibility
 */
export default function AsTransferListHalf(props) {
    var allowReordering = props.allowReordering, label = props.label, filterValue = props.filterValue, onFilterChange = props.onFilterChange, showMoveAll = props.showMoveAll, onMoveAll = props.onMoveAll, isSelectedProp = props.isSelected, items = props.items, onItemChange = props.onItemChange, onReorderItem = props.onReorderItem, footerContent = props.footerContent, filterFnProp = props.filterFn, isSelected = isSelectedProp !== null && isSelectedProp !== void 0 ? isSelectedProp : true, defaultFilterFn = pipe(toLower, includes(toLower(filterValue))), filterFn = filterFnProp ? partial(filterFnProp, [filterValue]) : defaultFilterFn, visibleItems = useMemo(function () { return filterValue ?
        filter(pipe(prop('displayName'), textContent, filterFn), items) :
        items; }, [filterFn, items, filterValue]);
    function onMoveAllClick() {
        var idsToMove = map(prop('id'), visibleItems);
        onMoveAll === null || onMoveAll === void 0 ? void 0 : onMoveAll(idsToMove);
    }
    return (React.createElement(AsFieldset, { className: "as-transfer-list__half", label: label },
        React.createElement("div", { className: "as-transfer-list__control-box" },
            React.createElement(AsFilterInput, { className: "as-transfer-list__filter", placeholder: "Filter", inputAttributes: { 'aria-label': 'Filter' }, value: filterValue, onChange: onFilterChange }),
            showMoveAll &&
                React.createElement("button", { type: "button", className: "as-transfer-list__move-all", onClick: onMoveAllClick },
                    React.createElement(AsFontAwesomeIcon, { icon: isSelected ? faTimesCircle : faPlusCircle }),
                    React.createElement("span", null,
                        isSelected ? 'Remove' : 'Transfer',
                        " All")),
            React.createElement(AsScrollRender, null,
                React.createElement("div", { className: "as-transfer-list__item-list", tabIndex: onItemChange || allowReordering ? undefined : 0 }, visibleItems.map(function (i, index) { return React.createElement(TransferListItem, __assign({ showReorderingButtons: allowReordering, isFilteredItem: !!filterValue, key: i.id, checked: isSelected, onChange: onItemChange, onReorderItem: onReorderItem, isTopItem: index === 0, isBottomItem: index === visibleItems.length - 1 }, i)); }))),
            React.createElement("div", { className: "as-transfer-list__footer" }, footerContent))));
}
AsTransferListHalf.propTypes = propTypes;
//# sourceMappingURL=AsTransferListHalf.js.map