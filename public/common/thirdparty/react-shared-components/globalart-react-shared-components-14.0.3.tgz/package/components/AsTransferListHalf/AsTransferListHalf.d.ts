import React from 'react';
import { Props, AsTransferListDataItem } from './types';
import './AsTransferListHalf.scss';
export { Props, AsTransferListDataItem };
declare function AsTransferListHalf<T extends string | number = string>(props: Props<T>): React.JSX.Element;
declare namespace AsTransferListHalf {
    var propTypes: {
        label: import("prop-types").Validator<NonNullable<import("prop-types").ReactNodeLike>>;
        filterValue: import("prop-types").Validator<string>;
        onFilterChange: import("prop-types").Validator<(...args: any[]) => any>;
        isSelected: import("prop-types").Requireable<boolean>;
        onItemChange: import("prop-types").Requireable<(...args: any[]) => any>;
        footerContent: import("prop-types").Validator<NonNullable<import("prop-types").ReactNodeLike>>;
        filterFn: import("prop-types").Requireable<(...args: any[]) => any>;
        showMoveAll: import("prop-types").Requireable<boolean>;
        onMoveAll: import("prop-types").Requireable<(...args: any[]) => any>;
        allowReordering: import("prop-types").Requireable<boolean>;
        onReorderItem: import("prop-types").Requireable<(...args: any[]) => any>;
    };
}
export default AsTransferListHalf;
//# sourceMappingURL=AsTransferListHalf.d.ts.map