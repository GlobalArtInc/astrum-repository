import { ReactNode } from 'react';
import * as PropTypes from 'prop-types';
import { Props as AsFilterInputProps } from '../AsFilterInput/AsFilterInput';
import DataItem from '../../util/DataItem';
import { TooltipConfigProps } from '../../util/tooltipUtils';
type SelectionChangeHandler<T> = (checked: boolean, id: T) => void;
export interface AsTransferListDataItem<T extends string | number = string> extends DataItem<T> {
    tooltip?: TooltipConfigProps | string | null;
}
export interface TransferListItemProps<T extends string | number = string> extends AsTransferListDataItem<T> {
    checked: boolean;
    onChange?: SelectionChangeHandler<T> | null;
    showReorderingButtons?: boolean | null;
    isFilteredItem?: boolean | null;
    onReorderItem?: (id: T, direction: 1 | -1) => void | null;
    isTopItem: boolean;
    isBottomItem: boolean;
}
export interface Props<T extends string | number = string> {
    label: Exclude<ReactNode, null | undefined>;
    filterValue: string;
    onFilterChange: AsFilterInputProps['onChange'];
    showMoveAll?: boolean | null;
    onMoveAll?: (toMove: T[]) => void | null;
    items: AsTransferListDataItem<T>[];
    isSelected?: boolean | null;
    onItemChange?: SelectionChangeHandler<T> | null;
    footerContent: ReactNode;
    filterFn?: ((filterStr: string, itemDisplayName: string) => boolean) | null;
    onReorderItem?: (id: T, direction: -1 | 1) => void | null;
    allowReordering?: boolean | null;
}
export declare const propTypes: {
    label: PropTypes.Validator<NonNullable<PropTypes.ReactNodeLike>>;
    filterValue: PropTypes.Validator<string>;
    onFilterChange: PropTypes.Validator<(...args: any[]) => any>;
    isSelected: PropTypes.Requireable<boolean>;
    onItemChange: PropTypes.Requireable<(...args: any[]) => any>;
    footerContent: PropTypes.Validator<NonNullable<PropTypes.ReactNodeLike>>;
    filterFn: PropTypes.Requireable<(...args: any[]) => any>;
    showMoveAll: PropTypes.Requireable<boolean>;
    onMoveAll: PropTypes.Requireable<(...args: any[]) => any>;
    allowReordering: PropTypes.Requireable<boolean>;
    onReorderItem: PropTypes.Requireable<(...args: any[]) => any>;
};
export {};
//# sourceMappingURL=types.d.ts.map