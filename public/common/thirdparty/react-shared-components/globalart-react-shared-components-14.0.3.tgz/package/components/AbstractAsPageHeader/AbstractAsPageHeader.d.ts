import React from 'react';
import { HeaderLinkProps, Props } from './types';
export { Props };
declare function HeaderLink({ name, href, current }: HeaderLinkProps): React.JSX.Element;
export { HeaderLinkProps, HeaderLink };
declare function AsPageHeader({ className, links, homeLink, productInfoContent, logo, children }: Props): React.JSX.Element;
declare namespace AsPageHeader {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default AsPageHeader;
//# sourceMappingURL=AbstractAsPageHeader.d.ts.map