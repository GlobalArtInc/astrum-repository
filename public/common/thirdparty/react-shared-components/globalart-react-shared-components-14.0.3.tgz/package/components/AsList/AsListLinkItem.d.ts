import React from 'react';
import { AsListLinkItemProps } from './types';
declare function AsListLinkItem(props: AsListLinkItemProps): React.JSX.Element;
declare namespace AsListLinkItem {
    var propTypes: import("prop-types").ValidationMap<AsListLinkItemProps>;
}
export default AsListLinkItem;
//# sourceMappingURL=AsListLinkItem.d.ts.map