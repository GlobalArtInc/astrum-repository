import { ReactNode, ComponentPropsWithRef, ComponentPropsWithoutRef } from 'react';
import { ValidationMap } from 'prop-types';
export interface AsListProps extends ComponentPropsWithRef<'ul'> {
    bulleted?: boolean | null;
    emptyMessage?: ReactNode;
    error?: string | null;
    isLoading?: boolean | null;
    retryHandler?: (() => void) | null;
}
export declare const asListPropTypes: ValidationMap<AsListProps>;
export interface AsListButtonItemProps extends ComponentPropsWithRef<'li'> {
    selected?: boolean | null;
    disabled?: boolean | null;
    buttonClassName?: string | null;
    buttonAttributes?: ComponentPropsWithoutRef<'button'> | null;
}
export declare const asListButtonItemPropTypes: ValidationMap<AsListButtonItemProps>;
export interface AsListLinkItemProps extends ComponentPropsWithRef<'li'> {
    disabled?: boolean | null;
    selected?: boolean | null;
    href: string;
    anchorClassName?: string | null;
    anchorAttributes?: ComponentPropsWithoutRef<'a'> | null;
}
export declare const asListLinkItemPropTypes: ValidationMap<AsListLinkItemProps>;
//# sourceMappingURL=types.d.ts.map