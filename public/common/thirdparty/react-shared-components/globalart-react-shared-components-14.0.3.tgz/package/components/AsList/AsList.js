var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { useRef } from 'react';
import classnames from 'classnames';
import useMergedRef from '@react-hook/merged-ref';
import withClass from '../../util/withClass';
import AsLoadingSpinner from '../AsLoadingSpinner/AsLoadingSpinner';
import AsLoadError from '../AsLoadError/AsLoadError';
import AsDescriptionList from '../AsDescriptionList/AsDescriptionList';
import AsListButtonItem from './AsListButtonItem';
import AsListLinkItem from './AsListLinkItem';
import { asListPropTypes } from './types';
import useEmptyComponent from '../../util/useEmptyComponent';
import { ensureRef } from '../../util/reactUtil';
export default function AsList(props) {
    var externalRef = props.ref, className = props.className, children = props.children, bulleted = props.bulleted, emptyMessage = props.emptyMessage, _a = props.isLoading, isLoading = _a === void 0 ? false : _a, error = props.error, retryHandler = props.retryHandler, attrs = __rest(props, ["ref", "className", "children", "bulleted", "emptyMessage", "isLoading", "error", "retryHandler"]);
    var classNames = classnames(className, 'as-list', { 'as-list--bulleted': bulleted });
    var ulRef = useRef(null);
    var emptyListRef = useRef(null);
    var ref = useMergedRef(ulRef, ensureRef(externalRef));
    var isEmpty = useEmptyComponent(ulRef, emptyListRef);
    if (isEmpty && !isLoading && !error) {
        if (!emptyMessage) {
            console.warn('emptyMessage is required when no list items are to be rendered');
        }
    }
    var asListEmpty = (React.createElement("li", { ref: emptyListRef, className: "as-list__item as-list__item--empty" },
        React.createElement("span", { className: "as-list__text" }, emptyMessage || 'This list is empty.')));
    var asListLoading = (React.createElement("li", { className: "as-list__item" },
        React.createElement(AsLoadingSpinner, null)));
    var asListError = (React.createElement("li", { className: "as-list__item as-list__item--error" },
        React.createElement(AsLoadError, { error: error, retryHandler: retryHandler })));
    return (React.createElement("ul", __assign({ ref: ref, className: classNames }, attrs),
        isLoading && asListLoading,
        !!error && !isLoading && asListError,
        !isLoading && !error && children,
        !(isLoading || error) && isEmpty && asListEmpty));
}
AsList.propTypes = asListPropTypes;
AsList.Item = withClass('li', 'as-list__item');
AsList.Text = withClass('span', 'as-list__text');
AsList.Subtext = withClass('span', 'as-list__subtext');
AsList.Actions = withClass('div', 'as-list__actions');
AsList.ButtonItem = AsListButtonItem;
AsList.LinkItem = AsListLinkItem;
// deprecated aliases
AsList.Description = AsDescriptionList.Description;
AsList.DescriptionTerm = AsDescriptionList.Term;
export { asListPropTypes } from './types';
//# sourceMappingURL=AsList.js.map