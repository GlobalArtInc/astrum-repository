import PropTypes from 'prop-types';
export var asListPropTypes = {
    bulleted: PropTypes.bool,
    emptyMessage: PropTypes.node,
    error: PropTypes.string,
    isLoading: PropTypes.bool,
    retryHandler: PropTypes.func
};
export var asListButtonItemPropTypes = {
    selected: PropTypes.bool,
    disabled: PropTypes.bool,
    buttonClassName: PropTypes.string,
    buttonAttributes: PropTypes.object
};
export var asListLinkItemPropTypes = {
    disabled: PropTypes.bool,
    selected: PropTypes.bool,
    href: PropTypes.string.isRequired,
    anchorClassName: PropTypes.string,
    anchorAttributes: PropTypes.object
};
//# sourceMappingURL=types.js.map