import React from 'react';
import AsListButtonItem from './AsListButtonItem';
import AsListLinkItem from './AsListLinkItem';
import { AsListProps } from './types';
declare function AsList(props: AsListProps): React.JSX.Element;
declare namespace AsList {
    var propTypes: import("prop-types").ValidationMap<AsListProps>;
    var Item: (props: React.DetailedHTMLProps<React.LiHTMLAttributes<HTMLLIElement>, HTMLLIElement>) => React.ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<React.DetailedHTMLProps<React.LiHTMLAttributes<HTMLLIElement>, HTMLLIElement>, "className">, string | React.JSXElementConstructor<any>>;
    var Text: (props: React.DetailedHTMLProps<React.HTMLAttributes<HTMLSpanElement>, HTMLSpanElement>) => React.ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLSpanElement>, HTMLSpanElement>, "className">, string | React.JSXElementConstructor<any>>;
    var Subtext: (props: React.DetailedHTMLProps<React.HTMLAttributes<HTMLSpanElement>, HTMLSpanElement>) => React.ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLSpanElement>, HTMLSpanElement>, "className">, string | React.JSXElementConstructor<any>>;
    var Actions: (props: React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => React.ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | React.JSXElementConstructor<any>>;
    var ButtonItem: typeof AsListButtonItem;
    var LinkItem: typeof AsListLinkItem;
    var Description: (props: React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement>) => React.ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement>, "className">, string | React.JSXElementConstructor<any>>;
    var DescriptionTerm: (props: React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement>) => React.ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement>, "className">, string | React.JSXElementConstructor<any>>;
}
export default AsList;
export { AsListProps, asListPropTypes } from './types';
//# sourceMappingURL=AsList.d.ts.map