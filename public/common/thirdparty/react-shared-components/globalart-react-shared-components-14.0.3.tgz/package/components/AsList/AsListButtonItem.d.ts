import React from 'react';
import { AsListButtonItemProps } from './types';
declare function AsListButtonItem(props: AsListButtonItemProps): React.JSX.Element;
declare namespace AsListButtonItem {
    var propTypes: import("prop-types").ValidationMap<AsListButtonItemProps>;
}
export default AsListButtonItem;
//# sourceMappingURL=AsListButtonItem.d.ts.map