var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import classnames from 'classnames';
import { propTypes } from './types';
import AsButton from '../AsButton/AsButton';
import AsFontAwesomeIcon from '../AsFontAwesomeIcon/AsFontAwesomeIcon';
import { faCaretLeft, faCaretRight } from '@fortawesome/free-solid-svg-icons';
export { propTypes };
export default function AsIndeterminatePagination(props) {
    var className = props.className, onPrevPageSelect = props.onPrevPageSelect, onNextPageSelect = props.onNextPageSelect, isFirstPage = props.isFirstPage, isLastPage = props.isLastPage, attrs = __rest(props, ["className", "onPrevPageSelect", "onNextPageSelect", "isFirstPage", "isLastPage"]);
    var classes = classnames('as-btn-bar', 'as-btn-bar--pagination', 'as-btn-bar--indeterminate-pagination', className);
    return (React.createElement("nav", __assign({ "aria-label": "pagination", className: classes }, attrs),
        React.createElement(AsButton, { type: "button", "aria-label": "previous page", onClick: onPrevPageSelect, variant: "tertiary", className: isFirstPage ? 'hidden' : '' },
            React.createElement(AsFontAwesomeIcon, { icon: faCaretLeft, size: "lg" })),
        React.createElement(AsButton, { type: "button", "aria-label": "next page", onClick: onNextPageSelect, variant: "tertiary", className: isLastPage ? 'hidden' : '' },
            React.createElement(AsFontAwesomeIcon, { icon: faCaretRight, size: "lg" }))));
}
AsIndeterminatePagination.propTypes = propTypes;
//# sourceMappingURL=AsIndeterminatePagination.js.map