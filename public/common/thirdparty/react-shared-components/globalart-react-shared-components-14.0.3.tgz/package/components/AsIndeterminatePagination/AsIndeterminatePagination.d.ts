import React from 'react';
import { Props, propTypes } from './types';
export { Props, propTypes };
declare function AsIndeterminatePagination(props: Props): React.JSX.Element;
declare namespace AsIndeterminatePagination {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default AsIndeterminatePagination;
//# sourceMappingURL=AsIndeterminatePagination.d.ts.map