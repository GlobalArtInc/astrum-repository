var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import classnames from 'classnames';
import { faCaretRight } from '@fortawesome/free-solid-svg-icons';
import AsTooltip from '../AsTooltip/AsTooltip';
import { useUniqueId } from '../../util/idUtil';
import { propTypes, childPropTypes } from './types';
import AsFontAwesomeIcon from '../AsFontAwesomeIcon/AsFontAwesomeIcon';
import './AsCollapsibleItems.scss';
import { ensureStartEndElements } from '../../util/reactUtil';
export function PrivateAsCollapsibleItems(props) {
    var onToggleCollapse = props.onToggleCollapse, isOpen = props.isOpen, disabled = props.disabled, children = props.children, triggerContent = props.triggerContent, triggerTooltip = props.triggerTooltip, actionContent = props.actionContent, className = props.className, role = props.role, contentBeforeChildren = props.contentBeforeChildren, collapsibleChildrenId = props.collapsibleChildrenId, otherProps = __rest(props, ["onToggleCollapse", "isOpen", "disabled", "children", "triggerContent", "triggerTooltip", "actionContent", "className", "role", "contentBeforeChildren", "collapsibleChildrenId"]);
    var isEmpty = !React.Children.count(children), isExpanded = isOpen && !isEmpty, // conceptually we don't allow empty collapsible items to expand
    treeViewClasses = classnames('as-collapsible-items', className, {
        'as-collapsible-items--expanded': isExpanded,
        'as-collapsible-items--collapsed': !isExpanded,
        'as-collapsible-items--disabled': disabled,
        'as-collapsible-items--empty': isEmpty
    }), treeViewChildrenId = collapsibleChildrenId !== null && collapsibleChildrenId !== void 0 ? collapsibleChildrenId : useUniqueId('as-collapsible-items-children'), treeViewChildrenRole = role !== null && role !== void 0 ? role : 'list', trigger = (React.createElement("button", { type: "button", className: "as-collapsible-items__trigger", onClick: onToggleCollapse || undefined, "aria-controls": treeViewChildrenId, "aria-expanded": isExpanded, disabled: disabled || isEmpty || undefined },
        React.createElement(AsFontAwesomeIcon, { className: "as-collapsible-items__twisty", icon: faCaretRight }),
        React.createElement("span", { className: "as-collapsible-items__text" }, ensureStartEndElements(triggerContent)))), triggerTooltipProps = typeof triggerTooltip === 'string' ? { title: triggerTooltip } : triggerTooltip;
    return (React.createElement("div", __assign({ className: treeViewClasses, role: "group" }, otherProps),
        React.createElement("div", { className: "as-collapsible-items__header" },
            triggerTooltipProps ? (
            // div necessary to avoid error message when tooltip is on disabled button
            React.createElement(AsTooltip, __assign({}, triggerTooltipProps),
                React.createElement("div", { className: "as-collapsible-items__tooltip-wrapper" }, trigger))) : trigger,
            actionContent && (React.createElement("div", { className: "as-collapsible-items__action-content" }, actionContent))),
        contentBeforeChildren,
        React.createElement("div", { className: "as-collapsible-items__children", role: treeViewChildrenRole, id: treeViewChildrenId }, isExpanded && children)));
}
/**
 * All individual treeview children should be wrapped in this component. When the child is an element,
 * this does not actually add another element to the DOM (as doing so would cause styling and screenreading
 * challenges) but instead adds the needed class and role to its child. If on the other hand the child is text,
 * this wraps it in a div
 */
export function AsCollapsibleItemsChild(_a) {
    var _b;
    var children = _a.children, className = _a.className, otherProps = __rest(_a, ["children", "className"]);
    if (typeof children === 'string' || typeof children === 'number') {
        return (React.createElement(AsCollapsibleItemsChild, __assign({ className: className }, otherProps),
            React.createElement("div", null, children)));
    }
    else {
        var classes = classnames('as-collapsible-items__child', children.props.className, className), 
        // if no role is specified, default it to listitem. If role is specified as empty string, unset it entirely
        role = ((_b = children.props.role) !== null && _b !== void 0 ? _b : 'listitem') || undefined;
        return React.cloneElement(children, __assign({ className: classes, role: role }, otherProps));
    }
}
var AsCollapsibleItems = Object.assign(PrivateAsCollapsibleItems, {
    Child: AsCollapsibleItemsChild,
    propTypes: propTypes
});
AsCollapsibleItemsChild.propTypes = childPropTypes;
export default AsCollapsibleItems;
//# sourceMappingURL=AsCollapsibleItems.js.map