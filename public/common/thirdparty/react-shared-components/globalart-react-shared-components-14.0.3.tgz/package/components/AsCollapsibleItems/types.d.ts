import { ReactNode, ReactElement, HTMLAttributes, RefAttributes, Ref, ComponentPropsWithRef } from 'react';
import * as PropTypes from 'prop-types';
import { TooltipConfigProps } from '../../util/tooltipUtils';
export interface PublicProps extends ComponentPropsWithRef<'div'> {
    onToggleCollapse?: (() => void) | null;
    isOpen: boolean;
    disabled?: boolean | null;
    triggerContent: ReactNode;
    triggerTooltip?: TooltipConfigProps | string | null;
    actionContent?: ReactElement | null;
    children?: ReactNode;
}
export interface Props extends PublicProps {
    contentBeforeChildren?: ReactNode;
    collapsibleChildrenId?: string | null;
}
export type AsCollapsibleItemsChildElement = ReactElement<HTMLAttributes<Element> & RefAttributes<Element | null>>;
export interface AsCollapsibleItemsChildProps extends HTMLAttributes<Element> {
    ref?: Ref<Element>;
    children: AsCollapsibleItemsChildElement | string | number;
}
export declare const propTypes: PropTypes.ValidationMap<PublicProps>;
export declare const childPropTypes: PropTypes.WeakValidationMap<AsCollapsibleItemsChildProps>;
//# sourceMappingURL=types.d.ts.map