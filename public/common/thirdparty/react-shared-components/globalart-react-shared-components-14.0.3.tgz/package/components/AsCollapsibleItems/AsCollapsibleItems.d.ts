import React, { FC } from 'react';
import { Props, PublicProps, AsCollapsibleItemsChildProps } from './types';
export { Props, PublicProps, AsCollapsibleItemsChildProps } from './types';
import './AsCollapsibleItems.scss';
type AsCollapsibleItemsFC = FC<PublicProps> & {
    Child: FC<AsCollapsibleItemsChildProps>;
};
export declare function PrivateAsCollapsibleItems(props: Props): React.JSX.Element;
/**
 * All individual treeview children should be wrapped in this component. When the child is an element,
 * this does not actually add another element to the DOM (as doing so would cause styling and screenreading
 * challenges) but instead adds the needed class and role to its child. If on the other hand the child is text,
 * this wraps it in a div
 */
export declare function AsCollapsibleItemsChild({ children, className, ...otherProps }: AsCollapsibleItemsChildProps): React.JSX.Element;
export declare namespace AsCollapsibleItemsChild {
    var propTypes: import("prop-types").WeakValidationMap<AsCollapsibleItemsChildProps>;
}
declare const AsCollapsibleItems: AsCollapsibleItemsFC;
export default AsCollapsibleItems;
//# sourceMappingURL=AsCollapsibleItems.d.ts.map