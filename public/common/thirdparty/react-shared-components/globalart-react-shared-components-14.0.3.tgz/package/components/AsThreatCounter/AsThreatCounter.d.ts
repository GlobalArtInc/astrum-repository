import React from 'react';
import { Props } from './types';
export { Props } from './types';
import './AsThreatCounter.scss';
declare function AsThreatCounter(props: Props): React.JSX.Element | null;
declare namespace AsThreatCounter {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default AsThreatCounter;
//# sourceMappingURL=AsThreatCounter.d.ts.map