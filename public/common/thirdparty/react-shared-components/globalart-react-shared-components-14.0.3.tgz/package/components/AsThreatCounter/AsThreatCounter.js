var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import classnames from 'classnames';
import { propTypes } from './types';
import './AsThreatCounter.scss';
export default function AsThreatCounter(props) {
    var _a;
    var criticalCount = props.criticalCount, severeCount = props.severeCount, moderateCount = props.moderateCount, lowCount = props.lowCount, noneCount = props.noneCount, unspecifiedCount = props.unspecifiedCount, layout = props.layout, className = props.className, attrs = __rest(props, ["criticalCount", "severeCount", "moderateCount", "lowCount", "noneCount", "unspecifiedCount", "layout", "className"]);
    var layoutClasses = classnames('as-threat-counter-container', className, (_a = {},
        _a["as-threat-counter-container--".concat(layout)] = layout,
        _a));
    if (typeof criticalCount !== 'number' &&
        typeof severeCount !== 'number' &&
        typeof moderateCount !== 'number' &&
        typeof lowCount !== 'number' &&
        typeof noneCount !== 'number' &&
        typeof unspecifiedCount !== 'number') {
        console.warn('No counts have been provided and so nothing will be rendered.');
        return null;
    }
    return (React.createElement("dl", __assign({ className: layoutClasses }, attrs),
        typeof criticalCount === 'number' &&
            React.createElement("div", { className: "as-threat-counter as-threat-counter--critical" },
                React.createElement("dt", { className: "as-threat-counter__text" }, "Critical"),
                React.createElement("dd", { className: "as-threat-counter__count" }, criticalCount)),
        typeof severeCount === 'number' &&
            React.createElement("div", { className: "as-threat-counter as-threat-counter--severe" },
                React.createElement("dt", { className: "as-threat-counter__text" }, "Severe"),
                React.createElement("dd", { className: "as-threat-counter__count" }, severeCount)),
        typeof moderateCount === 'number' &&
            React.createElement("div", { className: "as-threat-counter as-threat-counter--moderate" },
                React.createElement("dt", { className: "as-threat-counter__text" }, "Moderate"),
                React.createElement("dd", { className: "as-threat-counter__count" }, moderateCount)),
        typeof lowCount === 'number' &&
            React.createElement("div", { className: "as-threat-counter as-threat-counter--low" },
                React.createElement("dt", { className: "as-threat-counter__text" }, "Low"),
                React.createElement("dd", { className: "as-threat-counter__count" }, lowCount)),
        typeof noneCount === 'number' &&
            React.createElement("div", { className: "as-threat-counter as-threat-counter--none" },
                React.createElement("dt", { className: "as-threat-counter__text" }, "None"),
                React.createElement("dd", { className: "as-threat-counter__count" }, noneCount)),
        typeof unspecifiedCount === 'number' &&
            React.createElement("div", { className: "as-threat-counter as-threat-counter--unspecified" },
                React.createElement("dt", { className: "as-threat-counter__text" }, "Unspecified"),
                React.createElement("dd", { className: "as-threat-counter__count" }, unspecifiedCount))));
}
AsThreatCounter.propTypes = propTypes;
//# sourceMappingURL=AsThreatCounter.js.map