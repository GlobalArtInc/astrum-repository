import React from 'react';
import { Props } from './types';
import './NxCopyToClipboard.scss';
export { Props };
declare function NxCopyToClipboard(props: Props): React.JSX.Element;
declare namespace NxCopyToClipboard {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default NxCopyToClipboard;
//# sourceMappingURL=NxCopyToClipboard.d.ts.map