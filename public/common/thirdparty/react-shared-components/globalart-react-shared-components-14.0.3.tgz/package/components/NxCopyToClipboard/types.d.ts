import * as PropTypes from 'prop-types';
import { Props as NxFormGroupProps } from '../NxFormGroup/types';
import { PublicProps as NxTextInputProps } from '../NxTextInput/types';
export type InternalInputProps = Omit<NxTextInputProps, 'type' | 'value' | 'isPristine'>;
type ExternalInputProps = Omit<InternalInputProps, 'readOnly'>;
export interface Props extends Omit<NxFormGroupProps, 'children' | 'isRequired'> {
    content: string;
    onCopyUsingBtn?: (() => void) | null;
    inputProps?: ExternalInputProps | null;
}
export declare const propTypes: PropTypes.ValidationMap<Props>;
export {};
//# sourceMappingURL=types.d.ts.map