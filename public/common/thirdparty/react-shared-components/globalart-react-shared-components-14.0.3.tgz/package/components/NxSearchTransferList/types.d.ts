import { ComponentPropsWithRef } from 'react';
import * as PropTypes from 'prop-types';
import { Props as NxSearchDropdownProps } from '../NxSearchDropdown/types';
import { Props as NxTransferListHalfProps } from '../NxTransferListHalf/types';
export interface StatefulProps<T extends string | number = string> extends ComponentPropsWithRef<'div'> {
    onSearch: NxSearchDropdownProps<T>['onSearch'];
    loading: NxSearchDropdownProps<T>['loading'];
    loadError?: NxSearchDropdownProps<T>['error'];
    searchMatches: NxSearchDropdownProps<T>['matches'];
    onSearchMatchSelect: NxSearchDropdownProps<T>['onSelect'];
    addedItemsLabel?: string | null;
    showRemoveAll?: boolean | null;
    addedItems: NxTransferListHalfProps<T>['items'];
    onRemove: (newAddedItems: NxTransferListHalfProps<T>['items']) => void;
    addedItemsCountFormatter?: ((n: number) => string) | null;
    filterFn?: ((filterStr: string, itemDisplayName: string) => boolean) | null;
}
export interface Props<T extends string | number = string> extends StatefulProps<T> {
    searchText: NxSearchDropdownProps<T>['searchText'];
    onSearchTextChange: NxSearchDropdownProps<T>['onSearchTextChange'];
    addedItemsFilter: NxTransferListHalfProps<T>['filterValue'];
    onAddedItemsFilterChange: NxTransferListHalfProps<T>['onFilterChange'];
}
export declare const statefulPropTypes: PropTypes.ValidationMap<StatefulProps<string | number>>;
export declare const propTypes: PropTypes.ValidationMap<Props<string | number>>;
//# sourceMappingURL=types.d.ts.map