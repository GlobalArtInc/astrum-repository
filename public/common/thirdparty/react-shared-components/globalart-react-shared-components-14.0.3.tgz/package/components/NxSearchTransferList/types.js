var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
import * as PropTypes from 'prop-types';
var matchesPropType = PropTypes.arrayOf(PropTypes.shape({
    id: PropTypes.oneOfType([PropTypes.number.isRequired, PropTypes.string.isRequired]).isRequired,
    displayName: PropTypes.node.isRequired
}).isRequired).isRequired;
export var statefulPropTypes = {
    onSearch: PropTypes.func.isRequired,
    loading: PropTypes.bool,
    loadError: PropTypes.string,
    searchMatches: matchesPropType,
    onSearchMatchSelect: PropTypes.func.isRequired,
    addedItemsLabel: PropTypes.string,
    showRemoveAll: PropTypes.bool,
    addedItems: matchesPropType,
    onRemove: PropTypes.func.isRequired,
    addedItemsCountFormatter: PropTypes.func,
    filterFn: PropTypes.func
};
export var propTypes = __assign(__assign({}, statefulPropTypes), { searchText: PropTypes.string.isRequired, onSearchTextChange: PropTypes.func.isRequired, addedItemsFilter: PropTypes.string.isRequired, onAddedItemsFilterChange: PropTypes.func.isRequired });
//# sourceMappingURL=types.js.map