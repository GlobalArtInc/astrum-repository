import React from 'react';
import './NxSearchTransferList.scss';
import { Props } from './types';
export { Props };
declare function NxSearchTransferList<T extends string | number>(props: Props<T>): React.JSX.Element;
declare namespace NxSearchTransferList {
    var propTypes: import("prop-types").ValidationMap<Props<string | number>>;
}
export default NxSearchTransferList;
//# sourceMappingURL=NxSearchTransferList.d.ts.map