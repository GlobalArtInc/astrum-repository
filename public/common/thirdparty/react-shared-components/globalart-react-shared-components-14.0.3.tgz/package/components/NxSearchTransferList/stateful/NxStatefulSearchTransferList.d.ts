import React from 'react';
import { StatefulProps as Props } from '../types';
export { Props };
declare function NxStatefulSearchTransferList<T extends string | number>(props: Props<T>): React.JSX.Element;
declare namespace NxStatefulSearchTransferList {
    var propTypes: import("prop-types").ValidationMap<Props<string | number>>;
}
export default NxStatefulSearchTransferList;
//# sourceMappingURL=NxStatefulSearchTransferList.d.ts.map