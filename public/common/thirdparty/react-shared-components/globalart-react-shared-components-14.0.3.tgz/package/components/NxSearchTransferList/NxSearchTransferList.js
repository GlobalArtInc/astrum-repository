var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import classnames from 'classnames';
import { propEq, reject } from 'ramda';
import NxSearchDropdown from '../NxSearchDropdown/NxSearchDropdown';
import NxTransferListHalf from '../NxTransferListHalf/NxTransferListHalf';
import './NxSearchTransferList.scss';
import { propTypes } from './types';
var defaultAddedItemsCountFormatter = function (n) { return "".concat(n, " item").concat(n === 1 ? '' : 's', " Added"); };
export default function NxSearchTransferList(props) {
    var classNameProp = props.className, searchText = props.searchText, onSearchTextChange = props.onSearchTextChange, onSearch = props.onSearch, loading = props.loading, loadError = props.loadError, searchMatches = props.searchMatches, onSearchMatchSelect = props.onSearchMatchSelect, addedItemsLabel = props.addedItemsLabel, addedItemsFilter = props.addedItemsFilter, onAddedItemsFilterChange = props.onAddedItemsFilterChange, showRemoveAll = props.showRemoveAll, addedItems = props.addedItems, onRemove = props.onRemove, addedItemsCountFormatterProp = props.addedItemsCountFormatter, filterFn = props.filterFn, attrs = __rest(props, ["className", "searchText", "onSearchTextChange", "onSearch", "loading", "loadError", "searchMatches", "onSearchMatchSelect", "addedItemsLabel", "addedItemsFilter", "onAddedItemsFilterChange", "showRemoveAll", "addedItems", "onRemove", "addedItemsCountFormatter", "filterFn"]), addedCount = addedItems.length, addedItemsCountFormatter = addedItemsCountFormatterProp || defaultAddedItemsCountFormatter;
    function onRemoveAll(idsToRemove) {
        var idsToRemoveSet = new Set(idsToRemove);
        var newAddedItems = reject(function (_a) {
            var id = _a.id;
            return idsToRemoveSet.has(id);
        }, addedItems);
        onRemove(newAddedItems);
    }
    function onItemRemove(_, id) {
        onRemove(reject(propEq(id, 'id'), addedItems));
    }
    return (React.createElement("div", __assign({ className: classnames('nx-search-transfer-list', classNameProp) }, attrs),
        React.createElement(NxSearchDropdown, { searchText: searchText, onSearchTextChange: onSearchTextChange, onSearch: onSearch, loading: loading, error: loadError, matches: searchMatches, onSelect: onSearchMatchSelect }),
        React.createElement(NxTransferListHalf, { label: addedItemsLabel || 'Items Added', filterValue: addedItemsFilter, onFilterChange: onAddedItemsFilterChange, showMoveAll: showRemoveAll || false, onMoveAll: onRemoveAll, isSelected: true, items: addedItems, onItemChange: onItemRemove, footerContent: addedItemsCountFormatter(addedCount), filterFn: filterFn })));
}
NxSearchTransferList.propTypes = propTypes;
//# sourceMappingURL=NxSearchTransferList.js.map