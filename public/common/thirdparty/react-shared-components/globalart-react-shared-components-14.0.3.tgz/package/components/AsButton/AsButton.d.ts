import React from 'react';
import { Props } from './types';
declare function AsButton({ variant, className, children, title: titleProp, disabled, ...attrs }: Props): React.JSX.Element;
declare namespace AsButton {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default AsButton;
export { Props, propTypes } from './types';
//# sourceMappingURL=AsButton.d.ts.map