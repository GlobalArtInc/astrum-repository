/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import * as PropTypes from 'prop-types';
export var AS_BUTTON_VARIANTS = ['primary', 'secondary', 'tertiary', 'icon-only', 'error'];
export var propTypes = {
    variant: PropTypes.oneOf(AS_BUTTON_VARIANTS),
    title: PropTypes.string
};
//# sourceMappingURL=types.js.map