import * as PropTypes from 'prop-types';
import { ComponentPropsWithRef } from 'react';
export declare const AS_BUTTON_VARIANTS: readonly ["primary", "secondary", "tertiary", "icon-only", "error"];
export type AS_BUTTON_VARIANT_TYPE = (typeof AS_BUTTON_VARIANTS)[number];
interface CommonProps extends Omit<ComponentPropsWithRef<'button'>, 'title'> {
    inline?: boolean;
    title?: string | null;
}
export interface IconOnlyButtonProps extends CommonProps {
    variant: 'icon-only';
}
export interface OtherButtonProps extends CommonProps {
    variant?: Omit<AS_BUTTON_VARIANT_TYPE, 'icon-only'> | null;
}
export type Props = IconOnlyButtonProps | OtherButtonProps;
export declare const propTypes: PropTypes.ValidationMap<Props>;
export {};
//# sourceMappingURL=types.d.ts.map