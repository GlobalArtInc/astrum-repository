var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React, { useContext } from 'react';
import classnames from 'classnames';
import { propTypes } from './types';
import AsTooltip, { TooltipContext } from '../AsTooltip/AsTooltip';
import { includesDisabledClass } from '../../util/classUtil';
export default function AsButton(_a) {
    var variant = _a.variant, className = _a.className, children = _a.children, titleProp = _a.title, disabled = _a.disabled, attrs = __rest(_a, ["variant", "className", "children", "title", "disabled"]);
    var classNames = classnames(className, 'as-btn', "as-btn--".concat(variant || 'secondary')), alreadyHasTooltip = useContext(TooltipContext), title = titleProp || undefined, isIconOnly = variant === 'icon-only', getBtn = function (title) { return (React.createElement("button", __assign({ "aria-disabled": includesDisabledClass(className) || disabled, disabled: disabled, className: classNames, title: title }, attrs), children)); }, wrapInTooltip = title && !disabled && !alreadyHasTooltip;
    if (disabled && title) {
        throw new TypeError('AsButton cannot contain both the \'disabled\' and \'title\' props.');
    }
    if (isIconOnly && !title && !disabled && !alreadyHasTooltip) {
        console.warn('Using icon-only buttons without the title prop is deprecated');
    }
    return wrapInTooltip ? React.createElement(AsTooltip, { isName: isIconOnly, title: title }, getBtn()) : getBtn(title);
}
AsButton.propTypes = propTypes;
export { propTypes } from './types';
//# sourceMappingURL=AsButton.js.map