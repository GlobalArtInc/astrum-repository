import React from 'react';
import { Props } from './types';
export { Props } from './types';
import './AsColorPicker.scss';
declare function AsColorPicker({ value, onChange, className, label, ...attrs }: Props): React.JSX.Element;
declare namespace AsColorPicker {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default AsColorPicker;
//# sourceMappingURL=AsColorPicker.d.ts.map