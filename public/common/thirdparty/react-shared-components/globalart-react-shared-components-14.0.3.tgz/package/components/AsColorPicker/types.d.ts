import * as PropTypes from 'prop-types';
import { Props as AsFieldsetProps } from '../AsFieldset/types';
import { SelectableColor } from '../../util/selectableColors';
export interface Props extends Omit<AsFieldsetProps, 'onChange' | 'sublabel'> {
    value?: SelectableColor | null;
    onChange?: ((currentValue: SelectableColor) => void) | null;
}
export declare const propTypes: PropTypes.ValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map