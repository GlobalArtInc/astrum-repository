import React, { ProviderProps } from 'react';
/**
 * Establishes a separate provided value for the StableUniqueIdContext, which is used by the idUtils
 */
export default function NxStableUniqueIdContext(props: Omit<ProviderProps<never>, 'value'>): React.JSX.Element;
//# sourceMappingURL=NxStableUniqueIdContext.d.ts.map