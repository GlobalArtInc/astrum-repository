import * as PropTypes from 'prop-types';
import { PublicProps as NxTextInputProps } from '../NxTextInput/NxTextInput';
export interface Props extends Omit<NxTextInputProps, 'validatable' | 'isPristine' | 'validationErrors' | 'type'> {
    searchIcon?: boolean | null;
}
export declare const propTypes: PropTypes.ValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map