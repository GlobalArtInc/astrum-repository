var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import { mergeDeepRight, omit } from 'ramda';
import classnames from 'classnames';
import { faFilter, faSearch } from '@fortawesome/free-solid-svg-icons';
import './NxFilterInput.scss';
import NxFontAwesomeIcon from '../NxFontAwesomeIcon/NxFontAwesomeIcon';
import Close from '../../icons/Close';
import NxButton from '../NxButton/NxButton';
import { propTypes } from './types';
import { PrivateNxTextInput } from '../NxTextInput/NxTextInput';
export default function NxFilterInput(props) {
    var classNameProp = props.className, searchIcon = props.searchIcon, onKeyDown = props.onKeyDown, value = props.value, inputAttributes = props.inputAttributes, otherProps = __rest(props, ["className", "searchIcon", "onKeyDown", "value", "inputAttributes"]), isEmpty = value.trim() === '', className = classnames('nx-filter-input', classNameProp, {
        'nx-filter-input--empty': isEmpty
    }), btnClassName = classnames('nx-btn--clear', { 'hidden': isEmpty }), 
    // just in case these props get passed in, avoid passing them to NxTextInput as they would cause
    // malfunction
    cleanedProps = omit(['validatable', 'validationErrors', 'type'], otherProps), filterIcon = searchIcon ? faSearch : faFilter, btnTitle = searchIcon ? 'Clear search' : 'Clear filter', prefixContent = React.createElement(NxFontAwesomeIcon, { icon: filterIcon, className: "nx-icon--filter-icons" }), suffixContent = React.createElement(NxButton, { className: btnClassName, variant: "icon-only", title: btnTitle, onClick: clearFilterInputText, tabIndex: -1, type: "button" },
        React.createElement(Close, null));
    function clearFilterInputText() {
        var _a;
        (_a = props.onChange) === null || _a === void 0 ? void 0 : _a.call(props, '');
    }
    var handleKeyDown = function (e) {
        if (e.key === 'Escape') {
            clearFilterInputText();
            if (value !== '') {
                // only prevent default if the ESC actually made a difference here
                e.preventDefault();
            }
        }
        // NxFilterInput always uses <input> and not <textarea>
        onKeyDown === null || onKeyDown === void 0 ? void 0 : onKeyDown(e);
    }, mergedInputAttributes = mergeDeepRight(inputAttributes !== null && inputAttributes !== void 0 ? inputAttributes : {}, { onKeyDown: handleKeyDown });
    return React.createElement(PrivateNxTextInput, __assign({}, cleanedProps, { prefixContent: prefixContent, className: className, suffixContent: suffixContent, value: value, inputAttributes: mergedInputAttributes, isPristine: false }));
}
NxFilterInput.propTypes = propTypes;
//# sourceMappingURL=NxFilterInput.js.map