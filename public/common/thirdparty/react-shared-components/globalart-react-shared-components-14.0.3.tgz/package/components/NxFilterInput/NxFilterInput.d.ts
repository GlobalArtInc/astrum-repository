import React from 'react';
import './NxFilterInput.scss';
import { Props } from './types';
export { Props } from './types';
declare function NxFilterInput(props: Props): React.JSX.Element;
declare namespace NxFilterInput {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default NxFilterInput;
//# sourceMappingURL=NxFilterInput.d.ts.map