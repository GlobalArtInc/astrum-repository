import React from 'react';
import { Props } from './types';
export { Props } from './types';
import './AsBinaryDonutChart.scss';
declare function AsBinaryDonutChart(props: Props): React.JSX.Element;
declare namespace AsBinaryDonutChart {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default AsBinaryDonutChart;
//# sourceMappingURL=AsBinaryDonutChart.d.ts.map