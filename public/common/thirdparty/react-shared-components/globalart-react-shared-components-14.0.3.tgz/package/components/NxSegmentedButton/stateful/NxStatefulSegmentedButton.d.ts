import React from 'react';
import { Props } from './types';
declare function NxStatefulSegmentedButton(props: Props): React.JSX.Element;
declare namespace NxStatefulSegmentedButton {
    var propTypes: import("prop-types").WeakValidationMap<Props>;
}
export default NxStatefulSegmentedButton;
export { Props, propTypes } from './types';
//# sourceMappingURL=NxStatefulSegmentedButton.d.ts.map