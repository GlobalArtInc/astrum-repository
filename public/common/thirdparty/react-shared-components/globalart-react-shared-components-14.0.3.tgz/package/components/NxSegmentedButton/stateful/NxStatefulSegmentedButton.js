var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import NxSegmentedButton from '../NxSegmentedButton';
import { propTypes } from './types';
import useToggle from '../../../util/useToggle';
export default function NxStatefulSegmentedButton(props) {
    var _a = useToggle(false), isOpen = _a[0], onToggleOpen = _a[1];
    return React.createElement(NxSegmentedButton, __assign({ isOpen: isOpen, onToggleOpen: onToggleOpen }, props));
}
NxStatefulSegmentedButton.propTypes = propTypes;
export { propTypes } from './types';
//# sourceMappingURL=NxStatefulSegmentedButton.js.map