var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import classnames from 'classnames';
import { faCaretDown, faCaretUp } from '@fortawesome/free-solid-svg-icons';
import NxFontAwesomeIcon from '../NxFontAwesomeIcon/NxFontAwesomeIcon';
import NxButton from '../NxButton/NxButton';
import NxOverflowTooltip from '../NxTooltip/NxOverflowTooltip';
import { propTypes } from './types';
import './NxSegmentedButton.scss';
import AbstractDropdown from '../NxDropdown/AbstractDropdown';
export default function NxSegmentedButton(props) {
    var variant = props.variant, className = props.className, disabled = props.disabled, buttonContent = props.buttonContent, onClick = props.onClick, children = props.children, isOpen = props.isOpen, type = props.type, externalOnToggleCollapse = props.onToggleOpen, attrs = __rest(props, ["variant", "className", "disabled", "buttonContent", "onClick", "children", "isOpen", "type", "onToggleOpen"]), classes = classnames('nx-segmented-btn', className, {
        'nx-segmented-btn--open': isOpen
    }), wrappedMenuItems = React.Children.map(children, function (item) { return (React.createElement(NxOverflowTooltip, null, item)); });
    var renderToggleElement = function (toggleRef, onToggleCollapse) { return (React.createElement(React.Fragment, null,
        React.createElement(NxButton, { type: type || undefined, variant: variant, className: "nx-segmented-btn__main-btn", onClick: onClick, disabled: disabled || undefined }, buttonContent),
        React.createElement(NxButton, { ref: toggleRef, type: "button", variant: variant, className: "nx-segmented-btn__dropdown-btn", onClick: onToggleCollapse, "aria-label": "more options", disabled: disabled || undefined },
            React.createElement(NxFontAwesomeIcon, { icon: isOpen ? faCaretUp : faCaretDown })))); };
    return (React.createElement(AbstractDropdown, __assign({ isOpen: isOpen, disabled: disabled, className: classes, renderToggleElement: renderToggleElement, onToggleCollapse: externalOnToggleCollapse }, attrs), wrappedMenuItems));
}
NxSegmentedButton.propTypes = propTypes;
export { propTypes };
//# sourceMappingURL=NxSegmentedButton.js.map