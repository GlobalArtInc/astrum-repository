import { WeakValidationMap } from 'prop-types';
import { Props as NxSegmentedButtonProps } from '../types';
export type Props = Omit<NxSegmentedButtonProps, 'isOpen' | 'onToggleOpen'>;
export declare const propTypes: WeakValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map