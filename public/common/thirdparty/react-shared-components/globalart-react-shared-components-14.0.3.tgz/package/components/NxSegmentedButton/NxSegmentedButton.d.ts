import React from 'react';
import { Props, propTypes } from './types';
import './NxSegmentedButton.scss';
declare function NxSegmentedButton(props: Props): React.JSX.Element;
declare namespace NxSegmentedButton {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default NxSegmentedButton;
export { Props, propTypes };
//# sourceMappingURL=NxSegmentedButton.d.ts.map