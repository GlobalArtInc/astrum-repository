import * as PropTypes from 'prop-types';
import React, { ReactElement, ReactNode, KeyboardEventHandler, RefAttributes, ComponentPropsWithRef } from 'react';
import { NX_BUTTON_VARIANT_TYPE } from '../NxButton/types';
declare const invalidButtonVariants: readonly ["icon-only", "error"];
export type NX_SEGMENTED_BUTTON_VARIANT_TYPE = Exclude<NX_BUTTON_VARIANT_TYPE, (typeof invalidButtonVariants)[number]>;
export declare const NX_SEGMENTED_BUTTON_VARIANTS: NX_SEGMENTED_BUTTON_VARIANT_TYPE[];
export interface Props extends Omit<ComponentPropsWithRef<'div'>, 'onClick'> {
    variant: NX_SEGMENTED_BUTTON_VARIANT_TYPE;
    children: ReactElement<RefAttributes<HTMLElement>> | ReactElement<RefAttributes<HTMLElement>>[];
    buttonContent: ReactNode;
    isOpen: boolean;
    onToggleOpen: () => void;
    onClick: (evt: React.MouseEvent<HTMLButtonElement>) => void;
    onCloseKeyDown?: KeyboardEventHandler | null;
    onCloseClick?: ((e: MouseEvent) => void) | null;
    disabled?: boolean | null;
    type?: ComponentPropsWithRef<'button'>['type'];
}
export declare const propTypes: PropTypes.ValidationMap<Props>;
export {};
//# sourceMappingURL=types.d.ts.map