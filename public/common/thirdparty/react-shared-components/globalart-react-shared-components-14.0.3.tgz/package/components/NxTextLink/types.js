import * as PropTypes from 'prop-types';
export var propTypes = {
    external: PropTypes.bool,
    noReferrer: PropTypes.bool,
    newTab: PropTypes.bool,
    truncate: PropTypes.bool,
    disabled: PropTypes.bool
};
//# sourceMappingURL=types.js.map