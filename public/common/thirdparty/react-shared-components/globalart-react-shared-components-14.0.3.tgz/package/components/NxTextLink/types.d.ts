import { ComponentPropsWithoutRef } from 'react';
import * as PropTypes from 'prop-types';
export interface Props extends ComponentPropsWithoutRef<'a'> {
    external?: boolean | null;
    noReferrer?: boolean | null;
    newTab?: boolean | null;
    truncate?: boolean | null;
    disabled?: boolean | null;
}
export declare const propTypes: PropTypes.ValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map