var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import classnames from 'classnames';
import { faExternalLinkAlt } from '@fortawesome/free-solid-svg-icons';
import { ensureStartEndElements } from '../../util/reactUtil';
import NxFontAwesomeIcon from '../NxFontAwesomeIcon/NxFontAwesomeIcon';
import { propTypes } from './types';
export default function NxTextLink(props) {
    var children = props.children, external = props.external, noReferrer = props.noReferrer, newTab = props.newTab, truncate = props.truncate, disabled = props.disabled, specifiedClassName = props.className, specifiedRel = props.rel, specifiedTarget = props.target, href = props.href, attrs = __rest(props, ["children", "external", "noReferrer", "newTab", "truncate", "disabled", "className", "rel", "target", "href"]), className = classnames('nx-text-link', specifiedClassName, {
        'nx-text-link--external': external,
        'nx-text-link--truncate': truncate,
        disabled: disabled
    }), 
    // add the noreferrer rel if `noReferrer` prop is explicitly true, or its an external link and
    // the `noReferrer` prop isn't explicitly false
    rel = classnames(specifiedRel, {
        noreferrer: noReferrer || (external && noReferrer !== false)
    }), 
    // unless the caller specified a different target, set it to _blank if the `newTab` prop is true or if
    // this is an external link and the newTab prop isn't explicitly false
    target = specifiedTarget || (newTab || (external && newTab !== false) ? '_blank' : ''), wrappedChildren = truncate ?
        React.createElement("span", { className: "nx-text-link__truncate-text" }, children) : ensureStartEndElements(children), icon = React.createElement(NxFontAwesomeIcon, { className: "nx-icon--colorful", icon: faExternalLinkAlt, size: "sm" });
    return (React.createElement("a", __assign({ className: className, rel: rel, target: target }, attrs, { href: disabled ? undefined : href, role: disabled ? 'link' : undefined, "aria-disabled": !!disabled }),
        wrappedChildren,
        external &&
            (truncate ?
                // this wrapper element is needed for vertical alignment in the truncate case. It provides a strut
                // character which makes the two flex children equal in height with matching baselines
                React.createElement("span", { className: "nx-text-link__icon" }, icon) :
                icon)));
}
NxTextLink.propTypes = propTypes;
//# sourceMappingURL=NxTextLink.js.map