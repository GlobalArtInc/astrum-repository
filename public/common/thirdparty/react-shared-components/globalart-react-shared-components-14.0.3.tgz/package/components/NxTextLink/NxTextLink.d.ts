import React from 'react';
import { Props } from './types';
export { Props };
declare function NxTextLink(props: Props): React.JSX.Element;
declare namespace NxTextLink {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default NxTextLink;
//# sourceMappingURL=NxTextLink.d.ts.map