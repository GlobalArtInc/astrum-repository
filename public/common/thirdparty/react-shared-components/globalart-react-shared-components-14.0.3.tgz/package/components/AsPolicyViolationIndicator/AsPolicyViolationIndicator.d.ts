import React from 'react';
import { Props } from './types';
export { Props } from './types';
import './AsPolicyViolationIndicator.scss';
declare function AsPolicyViolationIndicator(props: Props): React.JSX.Element;
declare namespace AsPolicyViolationIndicator {
    var propTypes: import("prop-types").WeakValidationMap<Props>;
}
export default AsPolicyViolationIndicator;
//# sourceMappingURL=AsPolicyViolationIndicator.d.ts.map