import React from 'react';
import { HeaderProps, Props } from './types';
import './AsAccordion.scss';
export { Props, HeaderProps };
declare function AsAccordionHeader({ className, onClick: onClickProp, children, ...otherProps }: HeaderProps): React.JSX.Element;
declare function AsAccordion(props: Props): React.JSX.Element;
declare namespace AsAccordion {
    var propTypes: import("prop-types").ValidationMap<Props>;
    var Header: typeof AsAccordionHeader;
    var Title: (props: React.DetailedHTMLProps<React.HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>) => React.ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<React.DetailedHTMLProps<React.HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>, "className">, string | React.JSXElementConstructor<any>>;
}
export default AsAccordion;
//# sourceMappingURL=AsAccordion.d.ts.map