import React from 'react';
import { Props } from './types';
export { Props };
declare function AsStatefulAccordion({ defaultOpen, onToggle, ...otherProps }: Props): React.JSX.Element;
declare namespace AsStatefulAccordion {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default AsStatefulAccordion;
//# sourceMappingURL=AsStatefulAccordion.d.ts.map