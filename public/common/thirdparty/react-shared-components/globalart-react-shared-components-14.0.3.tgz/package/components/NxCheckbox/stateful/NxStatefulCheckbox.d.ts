import React from 'react';
import { StatefulProps as Props } from '../types';
export { Props };
/**
 * A stateful component for rendering a checkbox with a label
 * @param props.onChange A callback for when the checkbox is toggled, receiving the new value as an argument
 * @param props.defaultChecked Whether the checkbox should start off checked or unchecked
 * @param props.disabled Whether the checkbox should be rendered as disabled or not.  When disabled, the onChange
 * callback will not fire
 * @param props.children VDOM rendered as label. Should be
 * [phrasing content](https://www.w3.org/TR/2011/WD-html-markup-20110525/terminology.html#phrasing-content).
 */
declare function NxStatefulCheckbox({ defaultChecked, onChange, ...otherProps }: Props): React.JSX.Element;
declare namespace NxStatefulCheckbox {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default NxStatefulCheckbox;
//# sourceMappingURL=NxStatefulCheckbox.d.ts.map