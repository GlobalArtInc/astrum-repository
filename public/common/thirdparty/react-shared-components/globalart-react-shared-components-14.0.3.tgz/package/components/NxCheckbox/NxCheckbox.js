var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import classnames from 'classnames';
import { omit } from 'ramda';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCheck } from '@fortawesome/free-solid-svg-icons';
import './NxCheckbox.scss';
import { propTypes } from './types';
import NxOverflowTooltip from '../NxTooltip/NxOverflowTooltip';
/**
 * A stateless component for rendering a checkbox with a label
 * @param props.checkboxId An id to identify the checkbox
 * @param props.onChange A callback for when the checkbox is toggled
 * @param props.isChecked Whether the checkbox should be rendered as checked or unchecked
 * @param props.disabled Whether the checkbox should be rendered as disabled or not.  When disabled, the onChange
 * callback will not fire
 * @param props.children VDOM rendered as label. Should be
 * [phrasing content](https://www.w3.org/TR/2011/WD-html-markup-20110525/terminology.html#phrasing-content).
 */
export default function NxCheckbox(props) {
    var className = props.className, onChangeProp = props.onChange, isChecked = props.isChecked, disabled = props.disabled, checkboxId = props.checkboxId, overflowTooltip = props.overflowTooltip, children = props.children, _a = props.inputAttributes, inputAttributes = _a === void 0 ? {} : _a, otherProps = __rest(props, ["className", "onChange", "isChecked", "disabled", "checkboxId", "overflowTooltip", "children", "inputAttributes"]), labelClasses = classnames('nx-radio-checkbox', 'nx-checkbox', className, {
        'nx-radio-checkbox--disabled': disabled,
        'tm-checked': isChecked,
        'tm-unchecked': !isChecked
    }), content = children && React.createElement("span", { className: "nx-radio-checkbox__content nx-checkbox__content" }, children);
    var _b = inputAttributes, checkboxClassName = _b.className, unfilteredInputAttributes = __rest(_b, ["className"]);
    var otherInputAttributes = omit(['disabled', 'checked', 'readOnly', 'onChange'], unfilteredInputAttributes);
    var onChange = onChangeProp ? function () { onChangeProp(!isChecked); } : undefined;
    return (React.createElement("label", __assign({}, otherProps, { className: labelClasses }),
        React.createElement("input", __assign({ type: "checkbox", id: otherInputAttributes.id || checkboxId || undefined, className: classnames('nx-radio-checkbox__input', 'nx-checkbox__input', checkboxClassName), disabled: !!disabled, checked: isChecked, readOnly: !onChange, onChange: onChange }, otherInputAttributes)),
        React.createElement("span", { className: "nx-radio-checkbox__control nx-checkbox__box" }, isChecked ?
            // The undefined aria attrs are to work around an issue with the axe a11y checker in
            // NxCollapsibleMultiSelect
            React.createElement(FontAwesomeIcon, { role: "none", "aria-hidden": undefined, icon: faCheck }) :
            // Put a space in the box if not checked, in order to provide a consistent vertical-align baseline
            '\u00A0'),
        content &&
            (overflowTooltip !== false ? React.createElement(NxOverflowTooltip, null, content) : content)));
}
NxCheckbox.propTypes = propTypes;
//# sourceMappingURL=NxCheckbox.js.map