import * as PropTypes from 'prop-types';
export var propTypes = {
    checkboxId: PropTypes.string,
    onChange: PropTypes.func,
    isChecked: PropTypes.bool.isRequired,
    disabled: PropTypes.bool,
    overflowTooltip: PropTypes.bool,
    inputAttributes: PropTypes.object
};
export var statefulPropTypes = {
    checkboxId: PropTypes.string,
    onChange: PropTypes.func,
    defaultChecked: PropTypes.bool.isRequired,
    disabled: PropTypes.bool,
    overflowTooltip: PropTypes.bool,
    inputAttributes: PropTypes.object
};
//# sourceMappingURL=types.js.map