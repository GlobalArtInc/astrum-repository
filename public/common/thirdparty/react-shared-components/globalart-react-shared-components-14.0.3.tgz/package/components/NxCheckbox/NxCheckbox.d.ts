import React from 'react';
import './NxCheckbox.scss';
import { Props } from './types';
export { Props } from './types';
/**
 * A stateless component for rendering a checkbox with a label
 * @param props.checkboxId An id to identify the checkbox
 * @param props.onChange A callback for when the checkbox is toggled
 * @param props.isChecked Whether the checkbox should be rendered as checked or unchecked
 * @param props.disabled Whether the checkbox should be rendered as disabled or not.  When disabled, the onChange
 * callback will not fire
 * @param props.children VDOM rendered as label. Should be
 * [phrasing content](https://www.w3.org/TR/2011/WD-html-markup-20110525/terminology.html#phrasing-content).
 */
declare function NxCheckbox(props: Props): React.JSX.Element;
declare namespace NxCheckbox {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default NxCheckbox;
//# sourceMappingURL=NxCheckbox.d.ts.map