import { ComponentPropsWithoutRef, ComponentPropsWithRef } from 'react';
import * as PropTypes from 'prop-types';
export type InputAttributesProp = Omit<ComponentPropsWithoutRef<'input'>, 'disabled' | 'checked' | 'readOnly' | 'onChange'>;
interface BaseProps extends Omit<ComponentPropsWithRef<'label'>, 'onChange'> {
    checkboxId?: string | null;
    disabled?: boolean | null;
    overflowTooltip?: boolean | null;
    inputAttributes?: InputAttributesProp;
}
export interface Props extends BaseProps {
    onChange?: ((newVal: boolean) => void) | null;
    isChecked: boolean;
}
export interface StatefulProps extends BaseProps {
    onChange?: ((isChecked: boolean) => void) | null;
    defaultChecked: boolean;
}
export declare const propTypes: PropTypes.ValidationMap<Props>;
export declare const statefulPropTypes: PropTypes.ValidationMap<StatefulProps>;
export {};
//# sourceMappingURL=types.d.ts.map