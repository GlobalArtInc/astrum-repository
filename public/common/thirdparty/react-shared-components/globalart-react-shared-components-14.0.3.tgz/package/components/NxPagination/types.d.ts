import { ComponentPropsWithRef, MouseEvent } from 'react';
import * as PropTypes from 'prop-types';
export interface Props extends Omit<ComponentPropsWithRef<'div'>, 'onChange'> {
    pageCount: number;
    currentPage?: number | null;
    onChange: ((newPage: number, evt: MouseEvent) => void);
}
export declare const propTypes: PropTypes.ValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map