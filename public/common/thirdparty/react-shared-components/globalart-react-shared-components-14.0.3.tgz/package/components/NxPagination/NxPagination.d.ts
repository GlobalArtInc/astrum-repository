import React from 'react';
import { Props, propTypes } from './types';
export { Props, propTypes };
declare function NxPagination({ className, pageCount, currentPage, onChange, ...attrs }: Props): React.JSX.Element;
declare namespace NxPagination {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default NxPagination;
//# sourceMappingURL=NxPagination.d.ts.map