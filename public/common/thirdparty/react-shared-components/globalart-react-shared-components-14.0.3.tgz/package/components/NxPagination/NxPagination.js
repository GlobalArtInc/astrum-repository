var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import classnames from 'classnames';
import { min, range, map, curryN } from 'ramda';
import { propTypes } from './types';
import NxButton from '../NxButton/NxButton';
import NxFontAwesomeIcon from '../NxFontAwesomeIcon/NxFontAwesomeIcon';
import { faCaretLeft, faCaretRight } from '@fortawesome/free-solid-svg-icons';
export { propTypes };
var PAGE_RANGE_SIZE = 5;
function validate(pageCount, currentPage) {
    if (pageCount < 0 || !Number.isInteger(pageCount)) {
        throw new TypeError("pageCount must be a non-negative integer, was ".concat(pageCount));
    }
    if (currentPage == null) {
        if (pageCount !== 0) {
            throw new TypeError("currentPage must be defined when pageCount is not 0, was ".concat(currentPage));
        }
    }
    else {
        if (pageCount === 0) {
            throw new TypeError("currentPage must not be defined when pageCount is 0, was ".concat(currentPage));
        }
        if (currentPage < 0 || currentPage >= pageCount || !Number.isInteger(currentPage)) {
            throw new TypeError("currentPage is out of bounds or not an integer: ".concat(currentPage));
        }
    }
}
/**
 * @return a tuple containing the index of the first page in the current page range
 * and the index one beyond that of the last page in this range
 */
function getCurrentPageRangeBounds(pageCount, currentPage) {
    // special case: we are on the last page which also happens to be the first
    // page of a new group/range. In this case we want to actually show the previous range, along with the
    // always-visible final page button
    var isFinalPageAndFirstPageOfGroup = currentPage &&
        currentPage + 1 === pageCount && pageCount % PAGE_RANGE_SIZE === 1;
    var currentPageRangeStart = isFinalPageAndFirstPageOfGroup ?
        currentPage - PAGE_RANGE_SIZE :
        currentPage - (currentPage % PAGE_RANGE_SIZE);
    var currentPageRangeEnd = isFinalPageAndFirstPageOfGroup ?
        currentPage + 1 :
        min(currentPageRangeStart + PAGE_RANGE_SIZE, pageCount);
    return [currentPageRangeStart, currentPageRangeEnd];
}
var getBtnClasses = function (selected) {
    if (selected === void 0) { selected = false; }
    return classnames('nx-btn--pagination', { selected: selected });
};
export default function NxPagination(_a) {
    var className = _a.className, pageCount = _a.pageCount, currentPage = _a.currentPage, onChange = _a.onChange, attrs = __rest(_a, ["className", "pageCount", "currentPage", "onChange"]);
    validate(pageCount, currentPage);
    var classes = classnames('nx-btn-bar', 'nx-btn-bar--pagination', className);
    if (pageCount === 0 || currentPage == null) {
        return React.createElement("div", { className: classes });
    }
    else {
        // Button click handler is the onChange prop just curried so we can pass the number ahead of time
        var handleBtnClick_1 = curryN(2, onChange), onFirstPage = currentPage === 0, onLastPage = currentPage === pageCount - 1, _b = getCurrentPageRangeBounds(pageCount, currentPage), currentPageRangeStart = _b[0], currentPageRangeEnd = _b[1], currentPageRange = range(currentPageRangeStart, currentPageRangeEnd), numPagesBelowRange = currentPageRangeStart, numPagesAboveRange = pageCount - currentPageRangeEnd, mkBtn = function (num) {
            var selected = num === currentPage, classes = getBtnClasses(selected);
            var ariaLabel;
            if (num === 0) {
                ariaLabel = 'goto first page';
            }
            else if (num === pageCount - 1) {
                ariaLabel = 'goto last page';
            }
            else {
                ariaLabel = "goto page ".concat(num + 1);
            }
            return (React.createElement(NxButton, { type: "button", onClick: selected ? undefined : handleBtnClick_1(num), key: num, className: classes, "aria-current": selected && 'page', "aria-disabled": selected, "aria-label": ariaLabel }, num + 1));
        };
        return (React.createElement("nav", __assign({ "aria-label": "pagination", className: classes }, attrs),
            !onFirstPage &&
                // Left arrow - back one page
                React.createElement(NxButton, { type: "button", "aria-label": "goto previous page", onClick: handleBtnClick_1(currentPage - 1), variant: "tertiary" },
                    React.createElement(NxFontAwesomeIcon, { icon: faCaretLeft, size: "lg" })),
            !!numPagesBelowRange &&
                // First page express
                React.createElement(NxButton, { type: "button", "aria-label": "goto first page", className: getBtnClasses(), onClick: handleBtnClick_1(0) }, "1"),
            numPagesBelowRange > 1 &&
                // Left '...' - back one page group
                React.createElement(NxButton, { type: "button", "aria-label": "goto page ".concat(currentPageRangeStart), className: getBtnClasses(), onClick: handleBtnClick_1(currentPageRangeStart - 1) }, "\u2026"), // The local group of pages
            map(mkBtn, currentPageRange),
            numPagesAboveRange > 1 &&
                // Rigth '...' - forward one page group
                React.createElement(NxButton, { type: "button", "aria-label": "goto page ".concat(currentPageRangeEnd + 1), className: getBtnClasses(), onClick: handleBtnClick_1(currentPageRangeEnd) }, "\u2026"),
            !!numPagesAboveRange &&
                // Last page express
                React.createElement(NxButton, { type: "button", className: getBtnClasses(onLastPage), onClick: handleBtnClick_1(pageCount - 1), "aria-label": "goto last page" }, pageCount),
            !onLastPage &&
                // Right arrow - forward one page
                React.createElement(NxButton, { type: "button", "aria-label": "goto next page", onClick: handleBtnClick_1(currentPage + 1), variant: "tertiary" },
                    React.createElement(NxFontAwesomeIcon, { icon: faCaretRight, size: "lg" }))));
    }
}
NxPagination.propTypes = propTypes;
//# sourceMappingURL=NxPagination.js.map