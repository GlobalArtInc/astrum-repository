import * as PropTypes from 'prop-types';
export var propTypes = {
    pageCount: PropTypes.number.isRequired,
    currentPage: PropTypes.number,
    onChange: PropTypes.func.isRequired
};
//# sourceMappingURL=types.js.map