var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import AsCheckbox from '../AsCheckbox';
import { statefulPropTypes as propTypes } from '../types';
import useToggle from '../../../util/useToggle';
/**
 * A stateful component for rendering a checkbox with a label
 * @param props.onChange A callback for when the checkbox is toggled, receiving the new value as an argument
 * @param props.defaultChecked Whether the checkbox should start off checked or unchecked
 * @param props.disabled Whether the checkbox should be rendered as disabled or not.  When disabled, the onChange
 * callback will not fire
 * @param props.children VDOM rendered as label. Should be
 * [phrasing content](https://www.w3.org/TR/2011/WD-html-markup-20110525/terminology.html#phrasing-content).
 */
export default function AsStatefulCheckbox(_a) {
    var defaultChecked = _a.defaultChecked, onChange = _a.onChange, otherProps = __rest(_a, ["defaultChecked", "onChange"]);
    var _b = useToggle(defaultChecked), isChecked = _b[0], toggle = _b[1];
    function changeHandler() {
        var newCheckedStatus = toggle();
        if (onChange) {
            onChange(newCheckedStatus);
        }
    }
    return React.createElement(AsCheckbox, __assign({}, otherProps, { onChange: changeHandler, isChecked: isChecked }));
}
AsStatefulCheckbox.propTypes = propTypes;
//# sourceMappingURL=AsStatefulCheckbox.js.map