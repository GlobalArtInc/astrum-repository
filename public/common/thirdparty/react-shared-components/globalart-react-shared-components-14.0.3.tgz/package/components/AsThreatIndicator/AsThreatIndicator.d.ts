import { FunctionComponent } from 'react';
import { Props } from './types';
export { Props } from './types';
import './AsThreatIndicator.scss';
declare const AsThreatIndicator: FunctionComponent<Props>;
export default AsThreatIndicator;
//# sourceMappingURL=AsThreatIndicator.d.ts.map