/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import React from 'react';
import AsTooltip from '../AsTooltip/AsTooltip';
import { categoryByPolicyThreatLevel } from '../../util/threatLevels';
import { propTypes } from './types';
import './AsThreatIndicator.scss';
import AsFontAwesomeIcon from '../AsFontAwesomeIcon/AsFontAwesomeIcon';
import { faCircle } from '@fortawesome/free-solid-svg-icons';
import classnames from 'classnames';
var capitalize = function (string) { return string.charAt(0).toUpperCase() + string.slice(1); };
var AsThreatIndicator = function AsThreatIndicator(props) {
    var title = props.title, threatLevelCategory = props.threatLevelCategory, policyThreatLevel = props.policyThreatLevel, classNameProp = props.className, presentational = props.presentational, category = threatLevelCategory ? threatLevelCategory :
        policyThreatLevel != null ? categoryByPolicyThreatLevel[policyThreatLevel] :
            'unspecified', className = classnames(classNameProp, "as-threat-indicator as-threat-indicator--".concat(category, " as-icon--colorful")), label = "threat level ".concat(category);
    var icon = (React.createElement(AsFontAwesomeIcon, { "aria-label": presentational ? undefined : label, className: className, icon: faCircle, role: presentational ? 'presentation' : 'graphics-symbol img', fixedWidth: true }));
    return presentational ? icon : (React.createElement(AsTooltip, { title: title || capitalize(category) }, icon));
};
AsThreatIndicator.propTypes = propTypes;
export default AsThreatIndicator;
//# sourceMappingURL=AsThreatIndicator.js.map