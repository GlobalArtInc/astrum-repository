import React from 'react';
import { Props, propTypes } from './types';
import './AsSegmentedButton.scss';
declare function AsSegmentedButton(props: Props): React.JSX.Element;
declare namespace AsSegmentedButton {
    var propTypes: import("prop-types").ValidationMap<Props>;
}
export default AsSegmentedButton;
export { Props, propTypes };
//# sourceMappingURL=AsSegmentedButton.d.ts.map