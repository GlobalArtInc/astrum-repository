import React from 'react';
import { Props } from './types';
declare function AsStatefulSegmentedButton(props: Props): React.JSX.Element;
declare namespace AsStatefulSegmentedButton {
    var propTypes: import("prop-types").WeakValidationMap<Props>;
}
export default AsStatefulSegmentedButton;
export { Props, propTypes } from './types';
//# sourceMappingURL=AsStatefulSegmentedButton.d.ts.map