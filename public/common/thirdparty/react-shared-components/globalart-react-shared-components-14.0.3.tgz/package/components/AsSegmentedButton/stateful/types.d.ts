import { WeakValidationMap } from 'prop-types';
import { Props as AsSegmentedButtonProps } from '../types';
export type Props = Omit<AsSegmentedButtonProps, 'isOpen' | 'onToggleOpen'>;
export declare const propTypes: WeakValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map