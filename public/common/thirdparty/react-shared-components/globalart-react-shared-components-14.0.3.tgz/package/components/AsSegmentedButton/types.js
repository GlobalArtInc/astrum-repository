/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
import * as PropTypes from 'prop-types';
import { without } from 'ramda';
import { AS_BUTTON_VARIANTS } from '../AsButton/types';
// variants of AsButton that are not supported on AsSegmentedButton
var invalidButtonVariants = ['icon-only', 'error'];
export var AS_SEGMENTED_BUTTON_VARIANTS = without(invalidButtonVariants, AS_BUTTON_VARIANTS);
export var propTypes = {
    variant: PropTypes.oneOf(AS_SEGMENTED_BUTTON_VARIANTS).isRequired,
    children: PropTypes.oneOfType([
        PropTypes.element.isRequired,
        PropTypes.arrayOf(PropTypes.element.isRequired).isRequired
    ]).isRequired,
    buttonContent: PropTypes.node.isRequired,
    isOpen: PropTypes.bool.isRequired,
    onToggleOpen: PropTypes.func.isRequired,
    onClick: PropTypes.func.isRequired,
    onCloseKeyDown: PropTypes.func,
    onCloseClick: PropTypes.func,
    disabled: PropTypes.bool
};
//# sourceMappingURL=types.js.map