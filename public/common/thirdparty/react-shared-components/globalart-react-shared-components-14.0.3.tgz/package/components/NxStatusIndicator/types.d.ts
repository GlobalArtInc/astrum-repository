import { ComponentPropsWithRef } from 'react';
export type Props = ComponentPropsWithRef<'span'>;
//# sourceMappingURL=types.d.ts.map