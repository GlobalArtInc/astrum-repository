import React from 'react';
import { Props } from './types';
export declare const NxNegativeStatusIndicator: ({ className, ...otherProps }: Props) => React.JSX.Element;
export declare const NxPositiveStatusIndicator: ({ className, ...otherProps }: Props) => React.JSX.Element;
export declare const NxIntermediateStatusIndicator: ({ className, ...otherProps }: Props) => React.JSX.Element;
export declare const NxErrorStatusIndicator: ({ className, ...otherProps }: Props) => React.JSX.Element;
//# sourceMappingURL=NxStatusIndicator.d.ts.map