export declare const AsP: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLParagraphElement>, HTMLParagraphElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLParagraphElement>, HTMLParagraphElement>, "className">, string | import("react").JSXElementConstructor<any>>;
export declare const AsCode: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>, "className">, string | import("react").JSXElementConstructor<any>>;
export declare const AsBlockquote: (props: import("react").DetailedHTMLProps<import("react").BlockquoteHTMLAttributes<HTMLQuoteElement>, HTMLQuoteElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").BlockquoteHTMLAttributes<HTMLQuoteElement>, HTMLQuoteElement>, "className">, string | import("react").JSXElementConstructor<any>>;
export declare const AsPre: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLPreElement>, HTMLPreElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLPreElement>, HTMLPreElement>, "className">, string | import("react").JSXElementConstructor<any>>;
export declare const AsFooter: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>, "className">, string | import("react").JSXElementConstructor<any>>;
export declare const AsButtonBar: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | import("react").JSXElementConstructor<any>>;
export declare const AsCounter: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLSpanElement>, HTMLSpanElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLSpanElement>, HTMLSpanElement>, "className">, string | import("react").JSXElementConstructor<any>>;
export declare const AsThreatNumber: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLSpanElement>, HTMLSpanElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLSpanElement>, HTMLSpanElement>, "className">, string | import("react").JSXElementConstructor<any>>;
export declare const AsPageMain: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>, "className">, string | import("react").JSXElementConstructor<any>>;
export declare const AsPageSidebar: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>, "className">, string | import("react").JSXElementConstructor<any>>;
export declare const AsH1: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>, "className">, string | import("react").JSXElementConstructor<any>>;
export declare const AsH2: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>, "className">, string | import("react").JSXElementConstructor<any>>;
export declare const AsH3: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>, "className">, string | import("react").JSXElementConstructor<any>>;
export declare const AsH4: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>, "className">, string | import("react").JSXElementConstructor<any>>;
export declare const AsDivider: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLHRElement>, HTMLHRElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLHRElement>, HTMLHRElement>, "className">, string | import("react").JSXElementConstructor<any>>;
export declare const AsFormRow: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | import("react").JSXElementConstructor<any>>;
export declare const AsGlobalFooter2: ((props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>, "className">, string | import("react").JSXElementConstructor<any>>) & {
    Container: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | import("react").JSXElementConstructor<any>>;
};
export declare const AsCard: ((props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>, "className">, string | import("react").JSXElementConstructor<any>>) & {
    Container: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | import("react").JSXElementConstructor<any>>;
    Header: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>, "className">, string | import("react").JSXElementConstructor<any>>;
    Footer: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>, "className">, string | import("react").JSXElementConstructor<any>>;
    Content: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | import("react").JSXElementConstructor<any>>;
    CallOut: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | import("react").JSXElementConstructor<any>>;
    Text: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | import("react").JSXElementConstructor<any>>;
};
export declare const AsGrid: {
    Row: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | import("react").JSXElementConstructor<any>>;
    Column: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>, "className">, string | import("react").JSXElementConstructor<any>>;
    ColumnSection: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>, "className">, string | import("react").JSXElementConstructor<any>>;
    HorizontalKeyline: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | import("react").JSXElementConstructor<any>>;
    Header: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | import("react").JSXElementConstructor<any>>;
    HeaderHrule: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLHRElement>, HTMLHRElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLHRElement>, HTMLHRElement>, "className">, string | import("react").JSXElementConstructor<any>>;
};
export declare const AsPageTitle: ((props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | import("react").JSXElementConstructor<any>>) & {
    Headings: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>, "className">, string | import("react").JSXElementConstructor<any>>;
    Subtitle: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>, "className">, string | import("react").JSXElementConstructor<any>>;
    Description: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | import("react").JSXElementConstructor<any>>;
    Tags: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | import("react").JSXElementConstructor<any>>;
};
export declare const AsReadOnly: ((props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDListElement>, HTMLDListElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDListElement>, HTMLDListElement>, "className">, string | import("react").JSXElementConstructor<any>>) & {
    Label: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>, "className">, string | import("react").JSXElementConstructor<any>>;
    Data: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>, "className">, string | import("react").JSXElementConstructor<any>>;
    Item: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | import("react").JSXElementConstructor<any>>;
};
export declare const AsTableContainer: ((props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | import("react").JSXElementConstructor<any>>) & {
    Footer: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | import("react").JSXElementConstructor<any>>;
};
export declare const AsGlobalHeader: ((props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>, "className">, string | import("react").JSXElementConstructor<any>>) & {
    Actions: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | import("react").JSXElementConstructor<any>>;
};
//# sourceMappingURL=SimpleComponents.d.ts.map