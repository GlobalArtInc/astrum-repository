export declare const NxP: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLParagraphElement>, HTMLParagraphElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLParagraphElement>, HTMLParagraphElement>, "className">, string | import("react").JSXElementConstructor<any>>;
export declare const NxCode: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>, "className">, string | import("react").JSXElementConstructor<any>>;
export declare const NxBlockquote: (props: import("react").DetailedHTMLProps<import("react").BlockquoteHTMLAttributes<HTMLQuoteElement>, HTMLQuoteElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").BlockquoteHTMLAttributes<HTMLQuoteElement>, HTMLQuoteElement>, "className">, string | import("react").JSXElementConstructor<any>>;
export declare const NxPre: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLPreElement>, HTMLPreElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLPreElement>, HTMLPreElement>, "className">, string | import("react").JSXElementConstructor<any>>;
export declare const NxFooter: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>, "className">, string | import("react").JSXElementConstructor<any>>;
export declare const NxButtonBar: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | import("react").JSXElementConstructor<any>>;
export declare const NxCounter: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLSpanElement>, HTMLSpanElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLSpanElement>, HTMLSpanElement>, "className">, string | import("react").JSXElementConstructor<any>>;
export declare const NxThreatNumber: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLSpanElement>, HTMLSpanElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLSpanElement>, HTMLSpanElement>, "className">, string | import("react").JSXElementConstructor<any>>;
export declare const NxPageMain: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>, "className">, string | import("react").JSXElementConstructor<any>>;
export declare const NxPageSidebar: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>, "className">, string | import("react").JSXElementConstructor<any>>;
export declare const NxH1: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>, "className">, string | import("react").JSXElementConstructor<any>>;
export declare const NxH2: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>, "className">, string | import("react").JSXElementConstructor<any>>;
export declare const NxH3: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>, "className">, string | import("react").JSXElementConstructor<any>>;
export declare const NxH4: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>, "className">, string | import("react").JSXElementConstructor<any>>;
export declare const NxDivider: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLHRElement>, HTMLHRElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLHRElement>, HTMLHRElement>, "className">, string | import("react").JSXElementConstructor<any>>;
export declare const NxFormRow: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | import("react").JSXElementConstructor<any>>;
export declare const NxGlobalFooter2: ((props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>, "className">, string | import("react").JSXElementConstructor<any>>) & {
    Container: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | import("react").JSXElementConstructor<any>>;
};
export declare const NxCard: ((props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>, "className">, string | import("react").JSXElementConstructor<any>>) & {
    Container: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | import("react").JSXElementConstructor<any>>;
    Header: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>, "className">, string | import("react").JSXElementConstructor<any>>;
    Footer: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>, "className">, string | import("react").JSXElementConstructor<any>>;
    Content: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | import("react").JSXElementConstructor<any>>;
    CallOut: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | import("react").JSXElementConstructor<any>>;
    Text: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | import("react").JSXElementConstructor<any>>;
};
export declare const NxGrid: {
    Row: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | import("react").JSXElementConstructor<any>>;
    Column: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>, "className">, string | import("react").JSXElementConstructor<any>>;
    ColumnSection: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>, "className">, string | import("react").JSXElementConstructor<any>>;
    HorizontalKeyline: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | import("react").JSXElementConstructor<any>>;
    Header: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | import("react").JSXElementConstructor<any>>;
    HeaderHrule: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLHRElement>, HTMLHRElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLHRElement>, HTMLHRElement>, "className">, string | import("react").JSXElementConstructor<any>>;
};
export declare const NxPageTitle: ((props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | import("react").JSXElementConstructor<any>>) & {
    Headings: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>, "className">, string | import("react").JSXElementConstructor<any>>;
    Subtitle: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLHeadingElement>, HTMLHeadingElement>, "className">, string | import("react").JSXElementConstructor<any>>;
    Description: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | import("react").JSXElementConstructor<any>>;
    Tags: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | import("react").JSXElementConstructor<any>>;
};
export declare const NxReadOnly: ((props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDListElement>, HTMLDListElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDListElement>, HTMLDListElement>, "className">, string | import("react").JSXElementConstructor<any>>) & {
    Label: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>, "className">, string | import("react").JSXElementConstructor<any>>;
    Data: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>, "className">, string | import("react").JSXElementConstructor<any>>;
    Item: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | import("react").JSXElementConstructor<any>>;
};
export declare const NxTableContainer: ((props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | import("react").JSXElementConstructor<any>>) & {
    Footer: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | import("react").JSXElementConstructor<any>>;
};
export declare const NxGlobalHeader: ((props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>) => import("react").ReactElement<{
    className: string;
    role: string | undefined;
} & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLElement>, HTMLElement>, "className">, string | import("react").JSXElementConstructor<any>>) & {
    Actions: (props: import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>) => import("react").ReactElement<{
        className: string;
        role: string | undefined;
    } & Omit<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "className">, string | import("react").JSXElementConstructor<any>>;
};
//# sourceMappingURL=SimpleComponents.d.ts.map