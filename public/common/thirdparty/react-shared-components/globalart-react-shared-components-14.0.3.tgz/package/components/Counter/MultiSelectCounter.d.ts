import React from 'react';
export interface Props {
    options: unknown[];
    selectedIds: Set<unknown>;
}
export default function MultiSelectCounter({ options, selectedIds }: Props): React.JSX.Element;
//# sourceMappingURL=MultiSelectCounter.d.ts.map