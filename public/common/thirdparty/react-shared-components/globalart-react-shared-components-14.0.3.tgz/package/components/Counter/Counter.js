/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
/* eslint react/prop-types: 0 */
import React from 'react';
import classnames from 'classnames';
export default function Counter(_a) {
    var isActive = _a.isActive, children = _a.children;
    var classes = classnames('nx-counter', { 'nx-counter--active': isActive });
    return React.createElement("div", { className: classes }, children);
}
//# sourceMappingURL=Counter.js.map