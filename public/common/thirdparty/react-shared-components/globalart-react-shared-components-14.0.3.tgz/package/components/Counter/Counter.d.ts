import React, { ReactNode } from 'react';
export interface Props {
    isActive?: boolean | null;
    children: ReactNode;
}
export default function Counter({ isActive, children }: Props): React.JSX.Element;
//# sourceMappingURL=Counter.d.ts.map