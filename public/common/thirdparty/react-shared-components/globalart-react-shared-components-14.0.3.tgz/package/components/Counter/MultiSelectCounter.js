/*
 * Copyright (c) 2019-present Sonatype, Inc.
 * This program and the accompanying materials are made available under
 * the terms of the Eclipse Public License 2.0 which accompanies this
 * distribution and is available at https://www.eclipse.org/legal/epl-2.0/.
 */
/* eslint react/prop-types: 0 */
import React from 'react';
import Counter from './Counter';
export default function MultiSelectCounter(_a) {
    var options = _a.options, selectedIds = _a.selectedIds;
    var isAnyOptionSelected = selectedIds.size !== 0, ariaLabel = "".concat(selectedIds.size, " option").concat(selectedIds.size === 1 ? '' : 's', " out of ").concat(options.length, " selected");
    return (React.createElement(Counter, { "aria-label": ariaLabel, isActive: isAnyOptionSelected },
        isAnyOptionSelected ? selectedIds.size + ' of ' : '',
        options.length));
}
//# sourceMappingURL=MultiSelectCounter.js.map