import { FunctionComponent } from 'react';
import { Props } from './types';
export { Props, propTypes } from './types';
/**
 * A wrapper component that renders either a loading spinner, an error message, or if neither of those apply,
 * the specified children.  The children may optionally be specified as a function in order to compute their VDOM
 * lazily
 * @param error A message that represents an error that occurred.  If defined, will be rendered via NxLoadError
 * @param loading If true, and error is unset, a loading spinner will be rendered via NxLoadingSpinner
 * @param children VDOM to render if loading is false and error is not set
 * @param retryHandler If this is defined, a Retry button will be rendered in the NxLoadError which executes this
 * function when clicked
 */
declare const NxLoadWrapper: FunctionComponent<Props>;
export default NxLoadWrapper;
//# sourceMappingURL=NxLoadWrapper.d.ts.map