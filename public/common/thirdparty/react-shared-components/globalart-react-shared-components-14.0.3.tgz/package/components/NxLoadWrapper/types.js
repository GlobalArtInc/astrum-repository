import * as PropTypes from 'prop-types';
export var propTypes = {
    error: PropTypes.node,
    loading: PropTypes.bool,
    children: PropTypes.oneOfType([
        PropTypes.arrayOf(PropTypes.node),
        PropTypes.node,
        PropTypes.func
    ]),
    retryHandler: PropTypes.func.isRequired
};
//# sourceMappingURL=types.js.map