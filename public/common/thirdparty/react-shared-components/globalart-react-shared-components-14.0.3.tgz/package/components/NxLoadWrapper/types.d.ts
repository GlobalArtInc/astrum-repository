import { ReactNode } from 'react';
import * as PropTypes from 'prop-types';
export interface Props {
    error?: ReactNode | null;
    loading?: boolean | null;
    children: ReactNode | (() => ReactNode) | null;
    retryHandler: (() => void);
}
export declare const propTypes: PropTypes.ValidationMap<Props>;
//# sourceMappingURL=types.d.ts.map